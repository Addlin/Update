checkNetworkPath={
	s_bg = "LoginUI/BG.jpg",
	s_loginquan = "HotUpdate/update.png",
	s_logintiao = "LoginUI/login_02.png"
}
checkNetworkUI={}
----------------------------------------------------------
checkNetworkUI.checkStatus = true		--	检测联网标志
checkNetworkUI.cur_status = nil 		--	联网状态, nil 未知， false 失败， true 成功

local width 	= SmartRes:getInstance():getRight()
local height	= SmartRes:getInstance():getTop()
local LPosition = SmartRes:getInstance():getLeft()
local TPosition = SmartRes:getInstance():getTop()
local RPosition = SmartRes:getInstance():getRight()


function checkNetworkUI.CreateMainlayer()
	
	checkNetworkUI.mainlayer = cc.Layer:create()
	--背景
	local bg = cc.Sprite:create(checkNetworkPath.s_bg)
	bg:setPosition(width/2,height/2)
	checkNetworkUI.mainlayer:addChild(bg)
	checkNetworkUI.quan = cc.Sprite:create(checkNetworkPath.s_loginquan)
	checkNetworkUI.quan:setPosition(width/2,height/2+20)
	checkNetworkUI.mainlayer:addChild(checkNetworkUI.quan)
	local action = cc.RotateBy:create(0.8,-360)
	checkNetworkUI.quan:runAction(cc.RepeatForever:create(action))
	checkNetworkUI.quan:setVisible(false);

	checkNetworkUI.tiao = cc.Sprite:create(checkNetworkPath.s_logintiao)
	checkNetworkUI.tiao:setPosition(width/2+50,height/2-80)
	checkNetworkUI.mainlayer:addChild(checkNetworkUI.tiao)
	checkNetworkUI.tiao:setVisible(false)
	--提示信息
	checkNetworkUI.info_checkOK = cc.LabelTTF:create("Logining...","Microsoft YaHei",24)
	checkNetworkUI.info_checkOK:setPosition(width/2+50,height/2-80+10)
	checkNetworkUI.mainlayer:addChild(checkNetworkUI.info_checkOK,1)
	checkNetworkUI.info_checkOK:setVisible(false)
	checkNetworkUI.info_checkFail = cc.LabelTTF:create("请检查您的网络是否连接!","YouYuan",24)	checkNetworkUI.info_checkFail:setColor(cc.c3b(0, 0, 255));
	checkNetworkUI.info_checkFail:setPosition(width/2+50,height/2-80+10)
	checkNetworkUI.mainlayer:addChild(checkNetworkUI.info_checkFail,1)
	checkNetworkUI.info_checkFail:setVisible(false)

	--[[
	local 	particalSnow 	= cc.ParticleSnow:create();
	particalSnow:setGravity(cc.p(0, -100));
	particalSnow:setTexture(cc.TextureCache:getInstance():addImage("LoginUI/huaban2.png"));
	checkNetworkUI.mainlayer:addChild(particalSnow, 100);
	--]]
	-------------------------------------------------------------------------------------------------
	--	线路选择
	--[[
	checkNetworkUI.tip 		= 	cc.LabelTTF:create("请选择网络线路", "Microsoft YaHei", 32);
	checkNetworkUI.tip 		:setColor(cc.c3b(0, 128, 128));
	checkNetworkUI.tip 		:setPosition(width/2, height/2 + 30);
	checkNetworkUI.mainlayer:addChild(checkNetworkUI.tip);
	--]]

	checkNetworkUI.tip 		= 	cc.Sprite:create("commonResource/lianBiaoti.png");
	checkNetworkUI.tip 		:setPosition(width/2, height/2 + 100);
	checkNetworkUI.mainlayer:addChild(checkNetworkUI.tip);


	local 	function networkTypeCallBack( tag, sender )
		-- body

		sender:getChildByTag(1):setVisible(true);

		if 		tag 	== 1 	then
				print("电信线路");

				NetworkModule.NetworkType 	= eNetworkModule_DianXin;
		elseif 	tag 	== 2 	then
				print("联通线路");

				NetworkModule.NetworkType 	= eNetworkModule_LianTong;
		elseif 	tag 	== 3 	then
				print("移动线路");

				NetworkModule.NetworkType 	= eNetworkModule_YiDong;
		else
				print("测试线路");		

				NetworkModule.NetworkType 	= eNetworkModule_CeShi;
		end

		--	界面更新
		checkNetworkUI.tip:setVisible(false);
		checkNetworkUI.quan:setVisible(true);

		local 	callFunc 	= 	cc.CallFunc:create ( 
			function ( ... )
				
				--	启动网络连接
				NetworkModule.StartNetworkConnection();

				-----判断网络连接
				local function checkNetwork()

					--	print("判断游戏模式")
					print(tostring(checkNetworkUI.cur_status));
					print(tostring(checkNetworkUI.checkStatus));
					
					if 	(checkNetworkUI.checkStatus == false)  then			-- 	单机模式
						
						--	print("单机模式");

						if 	checkNetworkUI.df ~= nil then
							cc.Director:getInstance():getScheduler():unscheduleScriptEntry(checkNetworkUI.df)
						end

						checkNetworkUI.info_checkOK:setVisible(true);
						checkNetworkUI.info_checkFail:setVisible(false);
						checkNetworkUI.tiao:setVisible(false);
						cc.SpriteFrameCache:getInstance():removeUnusedSpriteFrames()
			    		cc.TextureCache:getInstance():removeUnusedTextures()
			    		print("进入登录界面")
						cc.Director:getInstance():replaceScene(LandingScene.CreateLandingScene())

						return;

					elseif(checkNetworkUI.checkStatus == true) then 		--	联机模式

						print("联机模式模式");

						if 	checkNetworkUI.df ~= nil then
								cc.Director:getInstance():getScheduler():unscheduleScriptEntry(checkNetworkUI.df)
						end

						if 	(checkNetworkUI.cur_status == true) then

							cc.SpriteFrameCache:getInstance():removeUnusedSpriteFrames()
				    		cc.TextureCache:getInstance():removeUnusedTextures()
				    		print("进入登录界面")
							cc.Director:getInstance():replaceScene(LandingScene.CreateLandingScene())

							return;
						end
					end

				end

				----定时器
				checkNetworkUI.df= cc.Director:getInstance():getScheduler():scheduleScriptFunc(checkNetwork,1.0,false)

			end);
		local 	action 		= 	cc.MoveTo:create   ( 0.5, cc.p(0, -500));

		checkNetworkUI.mainlayer:getChildByTag(100):runAction(cc.Sequence:create(action, callFunc));
	end

	local _menu = cc.Menu:create()
	_menu:setPosition(0,0)
 
	local 	networkNumber 	= #NetworkModule.IPList;
	local 	start_x 		= width/2;
	local 	start_y 		= checkNetworkUI.tip:getPositionY();
	local 	margin 			= 2;
	local 	itemWidth 		= 150;
	local 	itemHeight 	 	=  82
	
	--[[
	if 		networkNumber%2 == 0 then
			start_x 	= 	width/2 - ( (math.floor(networkNumber/2) *2 - 1) * (itemWidth + margin)/2) - margin/2;
	else
			start_x 	= 	width/2 - ( (math.floor(networkNumber/2) *2 ) * (itemWidth + margin)/2);
	end
	--]]

	if 		networkNumber%2 == 0 then
			--	start_y 	= 	checkNetworkUI.tip:getPositionY()  - ( (math.floor(networkNumber/2) *2 - 1) * (itemHeight + margin)/2) - margin/2;
	else
			--	start_y 	= 	checkNetworkUI.tip:getPositionY()  - ( (math.floor(networkNumber/2) *2 ) * (itemHeight + margin)/2);
	end

	for v 	in pairs(NetworkModule.IPList) do
		local _item = cc.MenuItemImage:create(NetworkModule.NetworkTypeButton[v][1],NetworkModule.NetworkTypeButton[v][2])
		_item:registerScriptTapHandler(networkTypeCallBack);

		print(tostring(v)..tostring(start_x));

		--	_item:setPosition(start_x + (v -1) *(itemWidth + margin), start_y);
		_item:setPosition(start_x, start_y - 60 - (v - 1) * (itemHeight + margin));

		print("位置设定");

		_menu:addChild(_item,0,v)

		print("Check1");
		local 	sprite 	= 	cc.Sprite:create("commonResource/selectIcon.png");
		sprite:setPosition(_item:getContentSize().width-20,_item:getContentSize().height/2)
		sprite:setVisible(false);

		print("Check2");

		_item:addChild(sprite,0,1)
		print("Check");
	end

	checkNetworkUI.mainlayer:addChild(_menu, 0, 100);

	return checkNetworkUI.mainlayer
end

function checkNetworkUI.CreatecheckNetWork_Callback()
	local  scene = cc.Scene:create()

	--	单机/联机控制标志
	checkNetworkUI.checkStatus = not NetworkModule.Native;

	--[[
	--	启动联网通信
	if 	checkNetworkUI.checkStatus == true then
		NetworkModule.StartNetworkConnection();
	end
	--]]

	local bgMusicPath = cc.FileUtils:getInstance():fullPathForFilename("Music/kaiChang.mp3")
    cc.SimpleAudioEngine:getInstance():playMusic(bgMusicPath, true)
	scene:addChild(checkNetworkUI.CreateMainlayer())
	return scene
end

------------------------------------------------------------------------------------
--									网络通信模块
------------------------------------------------------------------------------------

NetworkModule 					= {};
NetworkModule.Native 	 		= false;
NetworkModule.LoginScene 		= nil;
NetworkModule.ActiveConnecting 	= false;

eNetworkModule_Unknown 	= 	0; 	--	初始状态
eNetworkModule_DianXin	= 	1; 	--	电信线路
eNetworkModule_LianTong = 	2; 	--	联通线路
eNetworkModule_YiDong 	= 	3; 	--	移动线路
eNetworkModule_CeShi 	= 	4; 	--	内部测试

NetworkModule.NetworkType 	= 	eNetworkModule_Unknown;		--	初始状态未知

NetworkModule.IPList 	= 	{
	{"119.167.153.169", 10080},  			--	电信服
	--	{"219.146.94.41",	10080},			--	联通服
	--	{"192.168.1.155",	10080},
	--	发布时去掉
	{"219.146.94.1", 	10080}, 	--	移动服,  	测试连接失败用
	{"192.168.1.155", 	10080}, 	--	内部测试服, 发布版本禁用
}

NetworkModule.NetworkTypeButton 	= {
	{"commonResource/dianxin_01.png",	"commonResource/dianxin_01.png"	},
	{"commonResource/liantong_01.png",	"commonResource/liantong_01.png"},

	--	发布时去掉
	{"commonResource/dianxin_01.png",	"commonResource/dianxin_01.png"	}, 	
	{"commonResource/liantong_01.png",	"commonResource/liantong_01.png"},
}

NetworkModule.ConnectSuccessedHandler 	= nil;
NetworkModule.ConnectFailedHandler 		= nil;

function NetworkModule.CheckIfNative( ... )
	-- body

	return 	NetworkModule.Native == true;
end

function NetworkModule.StartNetworkConnection( ... )
	-- body

	local 	networkMgr 	= TCPSocketManager:getInstance(); 		print("网络类型"..tostring(NetworkModule.NetworkType));
	networkMgr :createSocket(NetworkModule.IPList[NetworkModule.NetworkType][1], NetworkModule.IPList[NetworkModule.NetworkType][2], 1);		--	一个网络连接
	networkMgr :register_connectScriptHandler 	(NetworkModule.ConnectCallBack);
	networkMgr :register_disconnectScriptHandler(NetworkModule.DisconnectCallBack);
end

function NetworkModule.StartNetworkConnectionWithSucessedHandler( handler )
	-- body

	NetworkModule.ConnectSuccessedHandler 	= handler;
	NetworkModule.StartNetworkConnection();
end

function NetworkModule.StartNetworkConnectionWithFailedHandler( handler )
	-- body

	NetworkModule.ConnectFailedHandler 		= handler;
	NetworkModule.StartNetworkConnection();
end

function NetworkModule.ConnectCallBack( eventType, tag, state, packet, sender )
	-- body
	print("Connect CallBack!");
	print(tostring(eventType)..tostring(tag)..tostring(state)..tostring(packet)..tostring(sender))
	if 	eventType 	== "Connect" 	then
		if 	state 	== true then
			print("NetworkModule: 	联网成功!");

			NetworkModule.ActiveConnecting 	= true;
			checkNetworkUI.cur_status 	= true;

			if 	NetworkModule.ConnectSuccessedHandler 	~= nil then
				print("执行成功连接的回调函数");
				NetworkModule.ConnectSuccessedHandler();

				NetworkModule.ConnectSuccessedHandler = nil;
			end
		else
			print("NetworkModule: 	联网失败!");

			NetworkModule.ActiveConnecting 	= false;
			checkNetworkUI.cur_status 	= false;

			local 	MaxPopTipZoder 	= 1000000;
			local 	MaxPopTipTag 	= 1000000;
			local 	font 			= "Microsoft YaHei";
			local 	size 			= 23;

			local 	runnningScene 	= cc.Director:getInstance():getRunningScene();
			local 	function DisconnectPopOkCallBack( ... )
				-- body
				if 	runnningScene:getChildByTag(MaxPopTipTag) ~= nil then
					runnningScene:removeChildByTag(MaxPopTipTag);
				end


				--	local 	socketMgr 	= TCPSocketManager:getInstance();
				--	socketMgr:removeSocket(1);

				--	重新连接
				cc.Director:getInstance():replaceScene(checkNetworkUI.CreatecheckNetWork_Callback());
			end
			
			if 	runnningScene:getChildByTag(MaxPopTipTag) ~= nil then
					runnningScene:removeChildByTag(MaxPopTipTag);
			end

			runnningScene:addChild(
				CommonDialog.DoModal("连接服务器失败，请检查网络连接", font, size, 
									CommonDialog.DARKGRAY, CommonDialog.DB_OK,
									nil, DisconnectPopOkCallBack),
				MaxPopTipZoder,
				MaxPopTipTag);

		end
	end
end

function NetworkModule.DisconnectCallBack( eventType, tag, state, packet, sender )
	-- body
	print("Disconnect Callback!");
	print(tostring(eventType)..tostring(tag)..tostring(state)..tostring(packet)..tostring(sender))
	if 	eventType == "Disconnect" then

		print("NetworkModule: 	失去连接!");
		
		NetworkModule.ActiveConnecting 	= false;
		checkNetworkUI.cur_status 		= false; 		--	连接失败

		print(tostring(NetworkModule.LoginScene));
		if 	NetworkModule.LoginScene == false then

			local 	MaxPopTipZoder 	= 1000000;
			local 	MaxPopTipTag 	= 1000000;
			local 	font 			= "Microsoft YaHei";
			local 	size 			= 23;

			local 	runnningScene 	= cc.Director:getInstance():getRunningScene();
			local 	function DisconnectPopOkCallBack( ... )
				-- body
				if 	runnningScene:getChildByTag(MaxPopTipTag) ~= nil then
					runnningScene:removeChildByTag(MaxPopTipTag);
				end

				--	GoBack To Login Scene
				cc.Director:getInstance():replaceScene(checkNetworkUI.CreatecheckNetWork_Callback());
			end
			
			runnningScene:addChild(
				CommonDialog.DoModal("您已断开网络连接， 请重新登陆已以继续游戏！", 
									font, size, CommonDialog.DARKGRAY, CommonDialog.DB_OK, 
									nil, DisconnectPopOkCallBack), 
				MaxPopTipZoder, 
				MaxPopTipTag)

			print("您已断开网络连接， 请重新登陆已以继续游戏！");
		end
	end	
end