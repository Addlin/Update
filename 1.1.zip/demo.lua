function __G__TRACKBACK__(msg)
    print("----------------------------------------")
    print("LUA ERROR: " .. tostring(msg) .. "\n")
    print(debug.traceback())
    print("----------------------------------------")
end

function OnClicked( ... )
	-- body

	print("OnClicked!");
end

function main()
	-- body

	local 	scene = cc.Scene:create();
	local 	mainLayer = cc.Layer:create();

	scene:addChild(mainLayer);
	
	local 	scrollView 	= cc.ScrollView:create(cc.size(1136, 960));	
	local 	menuItem 	= cc.MenuItemImage:create("battle/army/generals/D_01.png", "battle/army/generals/D_01.png");
	menuItem:setScale()
	local 	node 		= cc.Sprite:create();		node:setContentSize(menuItem:getContentSize());		node:setPosition(0, 0);
	local 	menu 		= cc.Menu:create();														menu:setPosition(cc.p(0, 0));
	node:addChild(menu);
--	scrollView:addChild(node);

	local 	layer 		= cc.Layer:create();
	layer:addChild(node);
	scrollView:setContainer(layer);

	
	menuItem:setPosition(cc.p(1136/2 - 200, menuItem:getContentSize().height/2));		menuItem:registerScriptTapHandler(OnClicked);
	menu:addChild(menuItem);


	local 	menu_2 		= cc.Menu:create();		menu_2:setPosition(cc.p(0, 0));
	local 	menuItem_2 	= cc.MenuItemImage:create("battle/army/generals/D_01.png", "battle/army/generals/D_01.png");
	local 	node_2 		= cc.Sprite:create();	node_2:setContentSize(menuItem_2:getContentSize());
	menuItem_2:setPosition(cc.p(1136/2 + 100, menuItem:getContentSize().height/2)); 	menuItem_2:registerScriptTapHandler(OnClicked);
	menu_2:addChild(menuItem_2);
	node_2:addChild(menu_2);
	layer:addChild(node_2);

	local 	particalSnow 	= cc.ParticleSnow:create();
	particalSnow:setGravity(cc.p(0, -10));
	particalSnow:setTexture(cc.TextureCache:getInstance():addImage("Interface/leaf2.png"));

	mainLayer:addChild(particalSnow);

	mainLayer:addChild(scrollView);

	cc.Director:getInstance():runWithScene(scene);


end

xpcall(main, __G__TRACKBACK__)