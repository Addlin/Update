--	Single Module Demo Framework


--	1) Require Destinition Module
--	2) Create Correponding Module


--	Module Dantiao Demo
--	require	"ModuleDantiao"

--	Module Bianlun Demo
	require "ModuleBianlun"

	require "lua/ModuleResult"

----------------------------------------------------------------------------------------------------------------------

-- for CCLuaEngine traceback
function __G__TRACKBACK__(msg)
    print("----------------------------------------")
    print("LUA ERROR: " .. tostring(msg) .. "\n")
    print(debug.traceback())
    print("----------------------------------------")
end


SceneMap = {
	["MainScene"]		= nil;
	["DemoScene"]		= nil;
};


---------------------------------------------------------------------------------------------------------------------

function 	MainLayer_CallBack(tag)
--	print(tostring(tag));
	if tag == 100 then
		print("--------------------------------------------------------------------------------------");
		print("Main Scene Change to DemoScene...");
		print("--------------------------------------------------------------------------------------");

		--	Create Module Dantiao		
--		SceneMap["DemoScene"]	= CreateModuleDantiao();

		--	Create Module Bianlun
		SceneMap["DemoScene"] 	= ModuleBianlun.CreateModuleBianlun();		

		--	中途遭遇
		ModuleBianlun.SetEncounterFlag(true);
		
		cc.Director:getInstance():pushScene(SceneMap["DemoScene"]);
		
--		local 	playerList 	= {"董卓", "刘备", "赵云", "张飞", "孙策"};		
--		cc.Director:getInstance():pushScene(ModuleResult.ShowSingleResult( false, false, playerList))
	end
end

--	Dantiao Module Main Function
function	Module_Main()
	
	SceneMap["MainScene"] = cc.Scene:create();
	
	local	viewOrigin		= cc.Director:getInstance():getVisibleOrigin();
	local	viewSize 		= cc.Director:getInstance():getVisibleSize();
	
	local	mainSceneLayer	= CCLayer:create();
	local	mainSceneMenu	= CCMenu:create();	
--	local	widget 	= CCMenuItemImage:create("caocao.png", "liubei.png", "sunquan.png");

	local 	label 	= cc.LabelTTF:create("点击开始", "YouYuan", 60);
	local 	widget  = cc.MenuItemLabel:create(label);
	
	mainSceneMenu:setPosition(0, 0);
	widget:setPosition(viewOrigin.x + viewSize.width/2, viewOrigin.y + viewSize.height/2);
	widget:registerScriptTapHandler(MainLayer_CallBack);
	
	mainSceneMenu:addChild	(widget, 0, 100);
	mainSceneLayer:addChild	(mainSceneMenu);

	SceneMap["MainScene"]:addChild(mainSceneLayer);	
	
	--	Running 
	cc.Director:getInstance():runWithScene(SceneMap["MainScene"]);
end


---------------------------------------------------------------------------------------------------------------------
xpcall(Module_Main, __G__TRACKBACK__);