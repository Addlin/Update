--	Date	:	2013/10/31
--	Author	:	zhaozl
--	Brief	:   Module Bianlun's Client Script

require "ModuleBianlunConfig"
require "ModuleBianlunServer"
require "ModuleBianlunSound"




--	Bianlun Module
ModuleBianlun = {
	--------------------------------------------------
	--	UI

	--	mainLayer
	mainLayer = nil;
	--	background
	background = nil;
	--	playerwidgets
	playerWidgets = {
		create    = nil;
		["Self"]  = {};
		["Other"] = {};
	};
	--	Operation
	operationWidgets = {
		create    	= nil;
		["隐藏"] 	= nil;
		["逃跑"]	= nil;
		["加速"]	= nil;
		["显示"]	= nil;
	};

	--	Skill
	skillWidgets 	 = {
		create 		= nil;
		["Self"]	=	{
			firstSkill	= {};
			secondSkill	= {};
		};
		["Other"]	= 	{
			firstSkill	= {};
			secondSkill	= {};		
		};
	}; 
	--	隐藏
	outputCardWidget = {
		create 		= nil;
		["Self"]	= nil;
		["Other"]	= nil;
	};

	--	论、驳
	lunboWidget = {
		create 		= nil;
		["LunBack"] = nil;
		["BoBack"]  = nil;
		["Lun"]		= nil;
		["Bo"]		= nil;
		["LunAnimation"]	= nil;
		["BoAnimation"]		= nil;
	};


	--	Final Resolution
	
	--	手中牌位置
	handCardBackWidget = {
		["Self"]	= {};
		["Other"]	= {};
	};

	--	手中牌序列
	handCardListWidget = {
		create 		= nil;
		["Self"]	= nil;
		["Other"]	= nil;
	};

	--	卷轴控件
	handCardListWidgetContainer 	={
		["Self"] 	= nil;
		["Other"]	= nil;
	};

	--	隐藏序列
	outputCardListWidget = {
		create 		= nil;
		["Self"]	= nil;
		["Other"]	= nil;
	};


	--	Tip Message
	tipMessageWidget = nil;
	tipMessageHandle = nil;
	tipMessageWaitTime = 2;

	--------------------------------------------------
	--	Animation Control
	xianhouWidgets = {
		create 			= nil;
		["Animation"]	= nil;
		["Self"]		= nil;
		["Other"]		= nil;
	};

	centerAnimationWidgets = nil;

	--------------------------------------------------
	--	Logic
	logic_bxianshou			= nil;
	logic_selfPlayerId		= nil;
	logic_selfPlayerName 	= nil;
	logic_otherPlayerId		= nil;
	logic_otherPlayerName	= nil;

	--------------------------------------------------
	--	Notification Center 
	notificationEventRegistry 	= {};


	--------------------------------------------------
	logic_displayHandCards 	= true;


	--------------------------------------------------
	--	结算配置信息
	playerList 		= {};
	award_exp 		= nil;
	award_gongxun 	= nil;
	award_bingli 	= nil;
	award_liang 	= nil;
	award_tili 		= nil;
	award_daoju 	= {};

	bEncounter 		= false;
};

-------------------------------------------------------------------------------------------------------------------------------------------------------------
--	分辨率自适应调整函数接口

--	Designed Resolution: 960 x 640
--	Pos is original designed Resolution
--	Return Adjusted Position with radio kepted
local function AutoAdjustPosition( pos , bVertical)
	-- body

	local 	viewOrigin = cc.Director:getInstance():getVisibleOrigin();
	local 	viewSize   = cc.Director:getInstance():getWinSize();

	if 		bVertical 	== true then
			return viewOrigin.y + pos / ModuleBianlunConfiguration.sceneHeight * viewSize.height; 
	else
			return viewOrigin.x + pos / ModuleBianlunConfiguration.sceneWidth * viewSize.width;
	end
end

local 	function AAP_X( pos )
	-- body

	local 	viewOrigin = cc.Director:getInstance():getVisibleOrigin();
	local 	viewSize   = cc.Director:getInstance():getWinSize();

	return  viewOrigin.x + pos / ModuleBianlunConfiguration.sceneWidth * viewSize.width;

end

local 	function AAP_Y( pos )
	-- body

	local 	viewOrigin = cc.Director:getInstance():getVisibleOrigin();
	local 	viewSize   = cc.Director:getInstance():getWinSize();	

	return viewOrigin.y + pos / ModuleBianlunConfiguration.sceneHeight * viewSize.height;
end

local 	function AAP_W( width )
	-- body

	local 	viewOrigin = cc.Director:getInstance():getVisibleOrigin();
	local 	viewSize   = cc.Director:getInstance():getWinSize();	

	return  width / ModuleBianlunConfiguration.sceneWidth * viewSize.width;	
end

local 	function AAP_H( height )
	-- body

	local 	viewOrigin = cc.Director:getInstance():getVisibleOrigin();
	local 	viewSize   = cc.Director:getInstance():getWinSize();		

	return height /ModuleBianlunConfiguration.sceneHeight * viewSize.height;
end



-------------------------------------------------------------------------------------------------------------------------------------------------------------
--	Common
function ModuleBianlun.Log( msg )
	-- body

	local 	preFix = "++ ModuleBianlun ++\n";
	local 	newMsg = tostring(preFix)..tostring(msg);

	print(msg);
end

function ModuleBianlun.GetSpriteFrame( name )
	-- body

--	ModuleBianlun.Log(tostring(name));

	local  	spriteFrameCache = cc.SpriteFrameCache:getInstance();
	return  spriteFrameCache:getSpriteFrame(name);
end




function ModuleBianlun.NotificationHandler( event, object, param)

	ModuleBianlun.Log("Module Bianlun : Notification Event Coming ...")
	print("辩论模块 --通知中心对象："..tostring(object));

	-- body
	if  event == "ActionFinishedEvent"	then	

		----------------------------------------------------------------------------------------
		--	先后手动画
		if 		tolua.cast(object, "CCSprite") == ModuleBianlun.xianhouWidgets["Animation"]	then

				ModuleBianlun.Log("先后手动画结束");

				tolua.cast(object, "CCNode"):setVisible(false);

				ModuleBianlun.xianhouWidgets["Self"]:setVisible(true);
				ModuleBianlun.xianhouWidgets["Other"]:setVisible(true);

				--	Just The Xian Hou Animation Finished
				if  	ModuleBianlun.logic_bxianshou == true then
						ModuleBianlun.xianhouWidgets["Self"]:setDisplayFrame(ModuleBianlun.GetSpriteFrame("xianshou.png"));
						ModuleBianlun.xianhouWidgets["Other"]:setDisplayFrame(ModuleBianlun.GetSpriteFrame("houshou.png"));
				elseif  ModuleBianlun.logic_bxianshou == false then
						ModuleBianlun.xianhouWidgets["Self"]:setDisplayFrame(ModuleBianlun.GetSpriteFrame("houshou.png"));
						ModuleBianlun.xianhouWidgets["Other"]:setDisplayFrame(ModuleBianlun.GetSpriteFrame("xianshou.png"));
				end
		
		------------------------------------------------------------------------------------------
		--	出牌动画	
		elseif	tolua.cast(object, "Node"):getParent() == tolua.cast(ModuleBianlun.handCardListWidget["Self"], "Node")	then
				
				ModuleBianlun.Log("己方出牌动画结束");

				tolua.cast(object, "Node"):setVisible(false);
				tolua.cast(object, "Node"):removeChildByTag(100);	--	出牌效果
--				ModuleBianlun.UpdatePlayerOutputCards(true);
				
				local 	clientLogic = CModuleBianlunClientLogic:sharedClientLogic();
--				local 	card 		= clientLogic:getPlayerOutputCard(clientLogic:getServerPosition(), 0);
				local 	card 		= tolua.cast(object, "CModuleBianlunCardWidget"):getCard();

--				tolua.cast(ModuleBianlun.outputCardWidget["Self"], "Node"):setVisible(true);
--				ModuleBianlun.UpdateOutCardWidget(ModuleBianlun.outputCardWidget["Self"], card:getType(), card:getValue());

				ModuleBianlun.outputCardListWidget["Self"]:addCard(card);

				ModuleBianlun.outputCardListWidget["Self"]:updateCardListWidget(true);

		elseif	tolua.cast(object, "Node"):getParent() == tolua.cast(ModuleBianlun.handCardListWidget["Other"], "Node")	then		
				
				ModuleBianlun.Log("对方出牌动画结束");

				tolua.cast(object, "Node"):setVisible(false);
				tolua.cast(object, "Node"):removeChildByTag(100);		--	出牌效果
--				ModuleBianlun.UpdatePlayerOutputCards(false);

				local 	clientLogic = CModuleBianlunClientLogic:sharedClientLogic();
--				local 	card 		= clientLogic:getPlayerOutputCard(1 - clientLogic:getServerPosition(), 0);
				local 	card 		= tolua.cast(object, "CModuleBianlunCardWidget"):getCard();

--				tolua.cast(ModuleBianlun.outputCardWidget["Other"], "Node"):setVisible(true);
--				ModuleBianlun.UpdateOutCardWidget(ModuleBianlun.outputCardWidget["Other"], card:getType(), card:getValue());

				ModuleBianlun.outputCardListWidget["Other"]:addCard(card);

				ModuleBianlun.outputCardListWidget["Other"]:updateCardListWidget(false);


		
		--------------------------------------------------------------------------------------------
		--	决胜动画	
		elseif 	tolua.cast(object, "Sprite") == ModuleBianlun.centerAnimationWidgets 		then
			ModuleBianlun.centerAnimationWidgets:setVisible(false);

		--------------------------------------------------------------------------------------------
		-- 	隐藏卷轴动画处理
		elseif 	tolua.cast(object:getParent(), "Node") 	== tolua.cast(ModuleBianlun.handCardListWidgetContainer["Self"], "Node")	then
			local 	bShow = true;
			for v 	in pairs(ModuleBianlun.handCardBackWidget["Self"]) do 
				ModuleBianlun.handCardBackWidget["Self"][v]:setVisible(bShow);
			end
			tolua.cast(ModuleBianlun.handCardListWidget["Self"], "Node"):setVisible(bShow);
		
		--	ModuleBianlun.UnregisterNotificationEvent(object, "ActionFinishedEvent");

		elseif 	tolua.cast(object:getParent(), "Node")  == tolua.cast(ModuleBianlun.handCardListWidgetContainer["Other"], "Node") 	then
			local 	bShow = true;
			for v 	in pairs(ModuleBianlun.handCardBackWidget["Other"])do
				ModuleBianlun.handCardBackWidget["Other"][v]:setVisible(bShow);
			end
			tolua.cast(ModuleBianlun.handCardListWidget["Other"],"Node"):setVisible(bShow);		

		--	ModuleBianlun.UnregisterNotificationEvent(object, "ActionFinishedEvent");

		-----------------------------------------------------------------------------------------------------------------------
		--	技能发动动画
		elseif  tolua.cast(object, "Node") == tolua.cast(ModuleBianlun.skillWidgets["Self"].firstSkill["back"], "Node")	 	then
				object:removeChildByTag(100);
		elseif 	tolua.cast(object, "Node") == tolua.cast(ModuleBianlun.skillWidgets["Self"].secondSkill["back"], "Node") 		then
				object:removeChildByTag(100);
		elseif 	tolua.cast(object, "Node") == tolua.cast(ModuleBianlun.skillWidgets["Other"].firstSkill["back"], "Node")	 	then
				object:removeChildByTag(100);
		elseif  tolua.cast(object, "Node") == tolua.cast(ModuleBianlun.skillWidgets["Other"].secondSkill["back"], "Node") 		then
				object:removeChildByTag(100);	

		---------------------------------------------------------------------------------------------
		--	技能发动闪光处理	
		elseif 	object:getParent() 		== 	ModuleBianlun.playerWidgets["Self"]["Head"] 	then
			print("己方技能闪光完成");

			ModuleBianlun.playerWidgets["Self"]["Head"]:removeChildByTag(100);

			ModuleBianlun.UnregisterNotificationEvent(object, "ActionFinishedEvent");
		elseif 	object:getParent() 		== 	ModuleBianlun.playerWidgets["Other"]["Head"] 	then
			print("对方技能闪光完成");

			ModuleBianlun.playerWidgets["Other"]["Head"]:removeChildByTag(100);

			ModuleBianlun.UnregisterNotificationEvent(object, "ActionFinishedEvent");
		end

	else
	end

end

------------------------------------------------------------------------------------------------------------------------------------------------------------
--	UI Widget Creating Helper Function

function ModuleBianlun.CreateSceneFrame( ... )
	-- body
--[[
	local  viewOrigin = cc.Director:getInstance():getVisibleOrigin();
	local  viewSize   = cc.Director:getInstance():getWinSize();

	--	Create BackGround Frame Corner
	local 	topleft 	= cc.Sprite:create();
	local 	topright 	= cc.Sprite:create();
	local 	bottomleft 	= cc.Sprite:create();
	local 	bottomright = cc.Sprite:create();

	topleft   	:setDisplayFrame( ModuleBianlun.GetSpriteFrame(ModuleBianlunConfiguration.frame["TopLeft"]     ));
	topright  	:setDisplayFrame( ModuleBianlun.GetSpriteFrame(ModuleBianlunConfiguration.frame["TopRight"]    ));
	bottomleft 	:setDisplayFrame( ModuleBianlun.GetSpriteFrame(ModuleBianlunConfiguration.frame["BottomLeft"]  ));
	bottomright :setDisplayFrame( ModuleBianlun.GetSpriteFrame(ModuleBianlunConfiguration.frame["BottomRight"] ));

	topleft 	:setPosition( viewOrigin.x  + topleft:getContentSize().width /2 					, viewOrigin.y + viewSize.height - topleft:getContentSize().height/2 );
	topright 	:setPosition( viewOrigin.x  + viewSize.width - topright:getContentSize().width/2 	, viewOrigin.y + viewSize.height - topright:getContentSize().height/2);
	bottomleft 	:setPosition( viewOrigin.x 	+ bottomleft:getContentSize().width/2				 	, viewOrigin.y + bottomleft:getContentSize().height/2 				 );
	bottomright :setPosition( viewOrigin.x  + viewSize.width - bottomright:getContentSize().width/2 , viewOrigin.y + bottomright:getContentSize().height/2				 );	

	ModuleBianlun.mainLayer:addChild(topleft, 		2);
	ModuleBianlun.mainLayer:addChild(topright, 		2);
	ModuleBianlun.mainLayer:addChild(bottomleft, 	2);
	ModuleBianlun.mainLayer:addChild(bottomright, 	2);	


	local 	temp_Shang = cc.Sprite:create();
	temp_Shang:setDisplayFrame(ModuleBianlun.GetSpriteFrame(ModuleBianlunConfiguration.frameSide["Shang"]));
	local 	temp_Zuo   = cc.Sprite:create();
	temp_Zuo:setDisplayFrame(ModuleBianlun.GetSpriteFrame(ModuleBianlunConfiguration.frameSide["Zuo"]));

	local 	width = temp_Shang:getContentSize().width

	--	Create BackGround Frame Side
	local 	horizontalNum 	= viewSize.width / temp_Shang:getContentSize().width    + 1;
	local 	verticalNum 	= viewSize.height/ temp_Zuo  :getContentSize().height   + 2;

	--	上
	local 	texture_shang 	= ModuleBianlun.GetSpriteFrame(ModuleBianlunConfiguration.frameSide["Shang"]):getTexture();
	local 	batchNode_shang = cc.SpriteBatchNode:createWithTexture(texture_shang);
	local 	sideShang 	 	= {};
	for 	i  = 1, horizontalNum do 
			sideShang[i]  	= cc.Sprite:create();
			sideShang[i]:setDisplayFrame(ModuleBianlun.GetSpriteFrame(ModuleBianlunConfiguration.frameSide["Shang"]));
			sideShang[i]:setPosition( (i - 1) * (sideShang[i]:getContentSize().width )  , viewOrigin.y + viewSize.height - sideShang[i]:getContentSize().height/2 );			
			batchNode_shang:addChild(sideShang[i]);

--			ModuleBianlun.Log(tostring(sideShang[i]:getPositionX()));
	end


	ModuleBianlun.mainLayer:addChild(batchNode_shang);

	--	下
	local 	texture_xia 	= ModuleBianlun.GetSpriteFrame(ModuleBianlunConfiguration.frameSide["Xia"]):getTexture();
	local 	batchNode_xia = cc.SpriteBatchNode:createWithTexture(texture_xia);
	local 	sideXia 	 	= {};
	for 	i  = 1, horizontalNum do 
			sideXia[i]  	= cc.Sprite:create();
			sideXia[i]:setDisplayFrame(ModuleBianlun.GetSpriteFrame(ModuleBianlunConfiguration.frameSide["Xia"]));
			sideXia[i]:setPosition((i - 1) * (sideXia[i]:getContentSize().width ) , viewOrigin.y + sideXia[i]:getContentSize().height/2 );			
			batchNode_xia:addChild(sideXia[i]);
	end

	ModuleBianlun.mainLayer:addChild(batchNode_xia);


	--	左
	local 	texture_zuo 	= ModuleBianlun.GetSpriteFrame(ModuleBianlunConfiguration.frameSide["Zuo"]):getTexture();
	local 	batchNode_zuo 	= cc.SpriteBatchNode:createWithTexture(texture_zuo);
	local 	sideZuo 	 	= {};
	for 	i  = 1, verticalNum do 
			sideZuo[i]  	= cc.Sprite:create();
			sideZuo[i]:setDisplayFrame(ModuleBianlun.GetSpriteFrame(ModuleBianlunConfiguration.frameSide["Zuo"]));
			sideZuo[i]:setPosition( viewOrigin.x + sideZuo[i]:getContentSize().width /2, viewOrigin.y +  (i - 1) * ( sideZuo[i]:getContentSize().height ) );			
			batchNode_zuo:addChild(sideZuo[i]);
	end

	ModuleBianlun.mainLayer:addChild(batchNode_zuo);


	--	右
	local 	texture_you 	= ModuleBianlun.GetSpriteFrame(ModuleBianlunConfiguration.frameSide["You"]):getTexture();
	local 	batchNode_you 	= cc.SpriteBatchNode:createWithTexture(texture_shang);
	local 	sideYou 	 	= {};
	for 	i  = 1, verticalNum do 
			sideYou[i]  	= cc.Sprite:create();
			sideYou[i]:setDisplayFrame(ModuleBianlun.GetSpriteFrame(ModuleBianlunConfiguration.frameSide["You"]));
			sideYou[i]:setPosition(viewOrigin.x + viewSize.width - sideYou[i]:getContentSize().width /2, viewOrigin.y + (i - 1) * ( sideYou[i]:getContentSize().height ));			
			batchNode_you:addChild(sideYou[i]);
	end

	ModuleBianlun.mainLayer:addChild(batchNode_you);	
--]]
	
	local  viewOrigin = cc.Director:getInstance():getVisibleOrigin();
	local  viewSize   = cc.Director:getInstance():getWinSize();
	
	local 	sprite9 	= cc.Scale9Sprite:createWithSpriteFrame(ModuleBianlun.GetSpriteFrame(ModuleBianlunConfiguration.backgroundframe));
	sprite9:setContentSize(viewSize);
	sprite9:setPosition(viewOrigin.x + viewSize.width/2, viewOrigin.y + viewSize.height/2);

	ModuleBianlun.mainLayer:addChild(sprite9);

end


function ModuleBianlun.CreateBackground( ... )
	-- body
	if  ModuleBianlun.mainLayer == nil	 then
		ModuleBianlun.Log("@Error: mainLayer Not Availiable while in ModuleBianlun.CreateBackground()");
		return;
	end

	local  viewOrigin = cc.Director:getInstance():getVisibleOrigin();
	local  viewSize   = cc.Director:getInstance():getWinSize();

	ModuleBianlun.background = cc.Sprite:create();

	ModuleBianlun.background:setDisplayFrame( ModuleBianlun.GetSpriteFrame( ModuleBianlunConfiguration.background) );

	ModuleBianlun.background:setPosition(viewOrigin.x + viewSize.width /2, viewOrigin.y + viewSize.height/2);

	ModuleBianlun.mainLayer:addChild(ModuleBianlun.background);

	--	Scene Frame
	ModuleBianlun.CreateSceneFrame();
end


function ModuleBianlun.CreatePlayerWidgets( ... )
	-- body
	if  ModuleBianlun.mainLayer == nil	 then
		ModuleBianlun.Log("@Error: mainLayer Not Availiable While in ModuleBianlun.CreatePlayerWidgets()");
		return;
	end

	if  ModuleBianlun.playerWidgets.create == nil	 then
		ModuleBianlun.playerWidgets.create = true;

		ModuleBianlun.playerWidgets["Self"]["Back"] 	= cc.Sprite:create();	ModuleBianlun.playerWidgets["Self"]["Back"]:setDisplayFrame(ModuleBianlun.GetSpriteFrame(ModuleBianlunConfiguration.headback));
		ModuleBianlun.playerWidgets["Other"]["Back"]	= cc.Sprite:create();	ModuleBianlun.playerWidgets["Other"]["Back"]:setDisplayFrame(ModuleBianlun.GetSpriteFrame(ModuleBianlunConfiguration.headback));

		ModuleBianlun.playerWidgets["Self"]["Back"]:setPosition(	AAP_X( ModuleBianlunConfiguration.position_self_head_x ), AAP_Y( ModuleBianlunConfiguration.position_self_head_y ) );
		ModuleBianlun.playerWidgets["Other"]["Back"]:setPosition(	AAP_X( ModuleBianlunConfiguration.position_other_head_x), AAP_Y( ModuleBianlunConfiguration.position_other_head_y) )

		ModuleBianlun.mainLayer:addChild(ModuleBianlun.playerWidgets["Self"]["Back"] );
		ModuleBianlun.mainLayer:addChild(ModuleBianlun.playerWidgets["Other"]["Back"]);


		ModuleBianlun.playerWidgets["Self"]["Head"] 	= cc.Sprite:create();
		ModuleBianlun.playerWidgets["Other"]["Head"] 	= cc.Sprite:create();

		ModuleBianlun.playerWidgets["Self"]["Head"]	:setPosition( AAP_X( ModuleBianlunConfiguration.position_self_head_x ), AAP_Y( ModuleBianlunConfiguration.position_self_head_y )  );
		ModuleBianlun.playerWidgets["Other"]["Head"]:setPosition( AAP_X( ModuleBianlunConfiguration.position_other_head_x), AAP_Y( ModuleBianlunConfiguration.position_other_head_y)  );

		local 	action_scale1 	= cc.ScaleBy:create(0, 0.37);
		local 	action_scale2 	= cc.ScaleBy:create(0, 0.37);

		ModuleBianlun.playerWidgets["Self"]["Head"]:runAction(action_scale1);
		ModuleBianlun.playerWidgets["Other"]["Head"]:runAction(action_scale2);

		ModuleBianlun.mainLayer:addChild(ModuleBianlun.playerWidgets["Self"]["Head"]);
		ModuleBianlun.mainLayer:addChild(ModuleBianlun.playerWidgets["Other"]["Head"]);
	end
end

function ModuleBianlun.GetPlayerHeadFrame( player )
	-- body

	local 	relativePath 	= "battle/army/generals/";
	local 	icon 			= nil;
	print(tostring(player));

	if 		player 	== 	"袁绍" 	then
			icon 	= 	"Y_01.png";
	elseif 	player 	== 	"袁尚"	then
			icon 	= 	"Y_02.png";
	elseif 	player 	==  "颜良" 	then
			icon 	= 	"Y_03.png";
	elseif 	player 	== 	"文丑"	then
			icon 	= 	"Y_04.png";
	elseif 	player 	== 	"高览"	then
			icon	= 	"Y_05.png";
	elseif 	player 	== 	"田丰"	then
			icon 	= 	"Y_06.png";
	elseif 	player 	== 	"甄宓(1)"	then
			icon 	= 	"Y_07.png";
	elseif 	player 	== 	"董卓"		then
			icon 	= 	"D_01.png";
	elseif 	player 	== "吕布" 	then
			icon 	= "D_02.png";
	elseif 	player 	== "高顺"	then
			icon 	= "D_03.png"
	elseif 	player 	== "贾诩"	then
			icon 	= "D_04.png"
	elseif 	player 	== "徐荣"	then
			icon 	= "D_05.png"
	elseif 	player 	== "华雄"	then
			icon 	= "D_06.png"
	elseif 	player 	== "貂蝉"	then
			icon 	= "D_07.png"
	elseif 	player 	== "孙策"	then
			icon 	= "S_01.png"
	elseif 	player 	== "孙权"	then
			icon 	= "S_02.png"
	elseif 	player 	== "孙尚香"	then
			icon 	= "S_03.png"
	elseif 	player 	== "周瑜"	then
			icon 	= "S_04.png"
	elseif 	player  == "陆逊"	then
			icon 	= "S_05.png"
	elseif 	player 	== "吕蒙"	then
			icon 	= "S_06.png"
	elseif 	player 	== "鲁肃"	then
			icon 	= "S_07.png"
	elseif 	player 	== "曹操"	then
			icon 	= "W_01.png"
	elseif 	player 	== "夏侯惇" then
			icon 	= "W_02.png"
	elseif 	player 	== 	"夏侯渊"	then
			icon 	= "W_03.png"
	elseif 	player 	== "司马懿"	then
			icon 	= "W_04.png"
	elseif 	player 	== "郭嘉"	then
			icon 	= "W_05.png"
	elseif 	player 	== "张颌"	then
			icon 	= "W_06.png"
	elseif 	player 	== "甄宓（2）"	then
			icon 	= "W_07.png"
	elseif 	player 	== "刘备"	then
			icon 	= "L_01.png";
	elseif 	player 	== "诸葛亮"	then
			icon 	= "L_02.png"
	elseif 	player 	== "关羽"	then
			icon 	= "L_03.png"
	elseif 	player 	== "张飞" 	then
			icon 	= "L_04.png"
	elseif 	player 	== "赵云"	then
			icon 	= "L_05.png"
	elseif 	player 	== "马超"	then
			icon 	= "L_06.png"
	elseif 	player 	== "黄忠"	then
			icon 	= "L_07.png";
	end

	print(tostring(icon));

	print(relativePath..icon);

	local 	sprite 	= cc.Sprite:create(relativePath..icon);
	return 	sprite:getDisplayFrame();
end

function ModuleBianlun.UpdatePlayerHead( pos, player )
	-- body

	local  	selfPos = CModuleBianlunClientLogic:sharedClientLogic():getServerPosition();

	local   spriteFrameCache = cc.SpriteFrameCache:getInstance();

	if  	pos == selfPos then
			ModuleBianlun.playerWidgets["Self"]["Head"]	:setDisplayFrame( ModuleBianlun.GetPlayerHeadFrame(player) );
	else
			ModuleBianlun.playerWidgets["Other"]["Head"]:setDisplayFrame( ModuleBianlun.GetPlayerHeadFrame(player) );
	end
end


--[[
--	Single Style
	
function ModuleBianlun.CreateOutputWidgets( ... )
	-- body
	if 		ModuleBianlun.mainLayer == nil	 then
			ModuleBianlun.Log("Error: mainLayer Not Availiable while in ModuleBianlun.CreateOutputWidgets()");
			return ;
	end

	if  	ModuleBianlun.outputCardWidget.create == nil	 then
			--	创建隐藏							
			ModuleBianlun.outputCardWidget["Self"] = CModuleBianlunOutCardWidget:create();
			ModuleBianlun.outputCardWidget["Other"]= CModuleBianlunOutCardWidget:create();

			tolua.cast( ModuleBianlun.outputCardWidget["Self"],  "Node"):setPosition(ModuleBianlunConfiguration.position_output_self_x,  ModuleBianlunConfiguration.position_output_self_y);
			tolua.cast( ModuleBianlun.outputCardWidget["Other"], "Node"):setPosition(ModuleBianlunConfiguration.position_output_other_x, ModuleBianlunConfiguration.position_output_other_y);

			ModuleBianlun.mainLayer:addChild(tolua.cast( ModuleBianlun.outputCardWidget["Self"],  "Node") );
			ModuleBianlun.mainLayer:addChild(tolua.cast( ModuleBianlun.outputCardWidget["Other"], "Node") );
	end

--	ModuleBianlun.UpdateOutCardWidget(ModuleBianlun.outputCardWidget["Self"], ModuleBianlunCardType_Unknown, ModuleBianlunCardValue_Unknown);
--	ModuleBianlun.UpdateOutCardWidget(ModuleBianlun.outputCardWidget["Other"], ModuleBianlunCardType_Unknown, ModuleBianlunCardValue_Unknown);
end

--]]

function ModuleBianlun.CreateLunboWidgets( ... )
	-- body
	if 	ModuleBianlun.mainLayer == nil	 then
		ModuleBianlun.Log("Error: mainLayer Not  Availiable while in ModuleBianlun.CreateLunboWidgets()");
		return;
	end

	if 	ModuleBianlun.lunboWidget.create == nil	 then
		ModuleBianlun.lunboWidget.create = true;

		ModuleBianlun.lunboWidget["LunBack"] = cc.Sprite:create();
		ModuleBianlun.lunboWidget["BoBack"]  = cc.Sprite:create();

		ModuleBianlun.lunboWidget["LunBack"]:setDisplayFrame(ModuleBianlun.GetSpriteFrame(ModuleBianlunConfiguration.lunBack));
		ModuleBianlun.lunboWidget["BoBack"] :setDisplayFrame(ModuleBianlun.GetSpriteFrame(ModuleBianlunConfiguration.boBack));

		ModuleBianlun.lunboWidget["LunBack"]:setPosition( AAP_X( ModuleBianlunConfiguration.position_lun_x ), AAP_Y( ModuleBianlunConfiguration.position_lunbo_y ) );
		ModuleBianlun.lunboWidget["BoBack"] :setPosition( AAP_X( ModuleBianlunConfiguration.position_bo_x  ), AAP_Y( ModuleBianlunConfiguration.position_lunbo_y ) );

		ModuleBianlun.mainLayer:addChild(ModuleBianlun.lunboWidget["LunBack"] , 1);
		ModuleBianlun.mainLayer:addChild(ModuleBianlun.lunboWidget["BoBack"]  , 1);

		ModuleBianlun.lunboWidget["Lun"] = CModuleBianlunCardWidget:create();
		ModuleBianlun.lunboWidget["Bo"]	 = CModuleBianlunCardWidget:create();

		tolua.cast(ModuleBianlun.lunboWidget["Lun"], "Node"):setPosition( AAP_X( ModuleBianlunConfiguration.position_lun_x  ) , AAP_Y( ModuleBianlunConfiguration.position_lunbo_y ) - 5 );
		tolua.cast(ModuleBianlun.lunboWidget["Bo"],  "Node"):setPosition( AAP_X( ModuleBianlunConfiguration.position_bo_x   ) + 5, AAP_Y( ModuleBianlunConfiguration.position_lunbo_y ) - 5 );

		--	Scale Big
		local 	scale_lun 	= cc.ScaleBy:create(0, 1.38);
		local 	scale_bo 	= cc.ScaleBy:create(0, 1.38);

		tolua.cast(ModuleBianlun.lunboWidget["Lun"], "Node"):runAction(scale_lun);
		tolua.cast(ModuleBianlun.lunboWidget["Bo"],  "Node"):runAction(scale_bo	);

		ModuleBianlun.mainLayer:addChild(tolua.cast(ModuleBianlun.lunboWidget["Lun"], "Node"), 10);
		ModuleBianlun.mainLayer:addChild(tolua.cast(ModuleBianlun.lunboWidget["Bo"],  "Node"), 10);

		ModuleBianlun.lunboWidget["LunAnimation"] = cc.Sprite:create();
		ModuleBianlun.lunboWidget["BoAnimation"]  = cc.Sprite:create();

		ModuleBianlun.lunboWidget["LunAnimation"]:setPosition(	AAP_X( ModuleBianlunConfiguration.position_lun_x + 15 ), AAP_Y( ModuleBianlunConfiguration.position_lunbo_y  - 15));
		ModuleBianlun.lunboWidget["BoAnimation"]:setPosition(	AAP_X( ModuleBianlunConfiguration.position_bo_x  + 15 ), AAP_Y( ModuleBianlunConfiguration.position_lunbo_y  - 15));

		local 	animationCache 	= cc.AnimationCache:getInstance();
		local 	animation_lun 	= animationCache:getAnimation("animation_lunbo");
		local 	animation_bo 	= animationCache:getAnimation("animation_lunbo");

		local 	animation_lun 	= cc.Animate:create(animation_lun);
		local   repeat_lun 	 	= cc.RepeatForever:create(animation_lun);
		local 	animtion_bo 	= cc.Animate:create(animation_bo);
		local 	repeat_bo 		= cc.RepeatForever:create(animtion_bo);

		ModuleBianlun.lunboWidget["LunAnimation"]:runAction(repeat_lun);
		ModuleBianlun.lunboWidget["BoAnimation"]:runAction(repeat_bo);

		ModuleBianlun.mainLayer:addChild(ModuleBianlun.lunboWidget["LunAnimation"], 0);
		ModuleBianlun.mainLayer:addChild(ModuleBianlun.lunboWidget["BoAnimation"],  0);
		

	end

--	ModuleBianlun.UpdateCardWidget(ModuleBianlun.lunboWidget["Lun"], ModuleBianlunCardType_Black, ModuleBianlunCardValue_Tian);
--	ModuleBianlun.UpdateCardWidget(ModuleBianlun.lunboWidget["Bo"],  ModuleBianlunCardType_White, ModuleBianlunCardValue_Di);
end




------------------------------------------------------------------------------------------------------------------------------------
--	Card Widget Update

function ModuleBianlun.UpdateOutCardWidget( sender, nType, nValue )
	-- body
	local 	widget = tolua.cast(sender, "CModuleBianlunOutCardWidget");

--	ModuleBianlun.Log(tostring(sender));
--	ModuleBianlun.Log(tostring(nType)..'vs.'..tostring(nValue));

	local  	cardType = nil;
	local   cardValue= nil;

	if  	nType >= ModuleBianlunCardType_Unknown  or  nValue >= ModuleBianlunCardValue_Unknown then
			tolua.cast(widget, "Sprite"):setDisplayFrame		(ModuleBianlun.GetSpriteFrame(ModuleBianlunConfiguration.cardBack["output"]));
	else
			if  	nType == ModuleBianlunCardType_Black then
					cardType = "black";
			elseif	nType == ModuleBianlunCardType_White then
					cardType = "white";
			end

			if  	nValue == ModuleBianlunCardValue_Tian	then
					cardValue = "天";
			elseif	nValue == ModuleBianlunCardValue_Di	then
					cardValue = "地";
			elseif  nValue	== ModuleBianlunCardValue_Ren	then
					cardValue = "人";
			elseif	nValue	== ModuleBianlunCardValue_Li	then
					cardValue = "理";
			end

			if  	cardType and cardValue then
					cardType = cardType.."out";
					tolua.cast(widget, "Sprite"):setDisplayFrame( ModuleBianlun.GetSpriteFrame(ModuleBianlunConfiguration.card[cardType][cardValue]) );
			end
	end
end

function ModuleBianlun.UpdateCardWidget( sender, nType, nValue)
	-- body
	local  widget = tolua.cast(sender, "CModuleBianlunCardWidget");

--	ModuleBianlun.Log("更新手中牌"..tostring(nType)..tostring(nValue));

	local  	cardType = nil;
	local   cardValue= nil;

	if  	nType >= ModuleBianlunCardType_Unknown  or  nValue >= ModuleBianlunCardValue_Unknown then
			tolua.cast(widget, "MenuItemImage"):setNormalSpriteFrame	(ModuleBianlun.GetSpriteFrame(ModuleBianlunConfiguration.cardBack["normal"]));
			tolua.cast(widget, "MenuItemImage"):setSelectedSpriteFrame	(ModuleBianlun.GetSpriteFrame(ModuleBianlunConfiguration.cardBack["normal"]));
	else
			if  	nType == ModuleBianlunCardType_Black then
					cardType = "black";
			elseif	nType == ModuleBianlunCardType_White then
					cardType = "white";
			end

			if  	nValue == ModuleBianlunCardValue_Tian	then
					cardValue = "天";
			elseif	nValue == ModuleBianlunCardValue_Di	then
					cardValue = "地";
			elseif  nValue	== ModuleBianlunCardValue_Ren	then
					cardValue = "人";
			elseif	nValue	== ModuleBianlunCardValue_Li	then
					cardValue = "理";
			end

--			ModuleBianlun.Log(cardType);
--			ModuleBianlun.Log(cardValue);

			if  	cardType and cardValue then
					tolua.cast(widget, "MenuItemImage"):setNormalSpriteFrame(ModuleBianlun.GetSpriteFrame(ModuleBianlunConfiguration.card[cardType][cardValue]));
					tolua.cast(widget, "MenuItemImage"):setNormalSpriteFrame(ModuleBianlun.GetSpriteFrame(ModuleBianlunConfiguration.card[cardType][cardValue]));
			end
	end

end

function ModuleBianlun.UpdateLunCard( nType, nValue )
	-- body

--	ModuleBianlun.Log(tostring(nType).."vs."..tostring(nValue));

	if 	ModuleBianlun.mainLayer == nil	 then
		ModuleBianlun.Log("Error@Lua, mainLayer Not  Availiable while in ModuleBianlun.UpdateLunCard()");
		return;
	end

	if 	ModuleBianlun.lunboWidget.create == nil then
		ModuleBianlun.Log("Error@Lua, LunBo Widget Not Availiable while in ModuleBianlun.UpdateLunCard()");
		return;
	end

	ModuleBianlun.UpdateCardWidget(ModuleBianlun.lunboWidget["Lun"], nType, nValue);
end

function ModuleBianlun.UpdateBoCard( nType, nValue )

--	ModuleBianlun.Log(tostring(nType).."vs."..tostring(nValue));
	-- body
	if 	ModuleBianlun.mainLayer == nil	 then
		ModuleBianlun.Log("Error@Lua, mainLayer Not  Availiable while in ModuleBianlun.UpdateLunCard()");
		return;
	end

	if 	ModuleBianlun.lunboWidget.create == nil then
		ModuleBianlun.Log("Error@Lua, LunBo Widget Not Availiable while in ModuleBianlun.UpdateLunCard()");
		return;
	end	

	ModuleBianlun.UpdateCardWidget(ModuleBianlun.lunboWidget["Bo"], nType, nValue);
end



----------------------------------------------------------------------------------------------------------------------------------------------
--	CardList Widget Creating 

function ModuleBianlun.CreatePlayerHandCardListWidgetUnion( ... )
	-- body

	local 	juanzhou 	= cc.Sprite:create(); 		juanzhou:setDisplayFrame(ModuleBianlun.GetSpriteFrame(ModuleBianlunConfiguration.juanzhou));

	ModuleBianlun.handCardListWidgetContainer["Self"]  = nil;
	ModuleBianlun.handCardListWidgetContainer["Self"]  = cc.Layer:create();
	local 	selfJuanzhou = 	cc.Sprite:create(); 	selfJuanzhou:setDisplayFrame(ModuleBianlun.GetSpriteFrame(ModuleBianlunConfiguration.juanzhou));
	selfJuanzhou:setPosition(AAP_X( ModuleBianlunConfiguration.position_hand_self_x ) - 42,  AAP_Y( ModuleBianlunConfiguration.position_hand_self_y));
	ModuleBianlun.handCardListWidgetContainer["Self"]:addChild(selfJuanzhou, 0, 100);
	ModuleBianlun.mainLayer:addChild( ModuleBianlun.handCardListWidgetContainer["Self"],  100);


	ModuleBianlun.handCardListWidgetContainer["Other"] = nil;
	ModuleBianlun.handCardListWidgetContainer["Other"] = cc.Layer:create();
	local 	otherJuanzhou = cc.Sprite:create(); 	otherJuanzhou:setDisplayFrame(ModuleBianlun.GetSpriteFrame(ModuleBianlunConfiguration.juanzhou));
	otherJuanzhou:setPosition(AAP_X( ModuleBianlunConfiguration.position_hand_other_x) - 42, AAP_Y( ModuleBianlunConfiguration.position_hand_other_y));
	ModuleBianlun.handCardListWidgetContainer["Other"]:addChild(otherJuanzhou, 0, 100);
	ModuleBianlun.mainLayer:addChild( ModuleBianlun.handCardListWidgetContainer["Other"], 100);

end


function ModuleBianlun.CreateHandCardListWidget( ... )
	-- body
	if 	ModuleBianlun.mainLayer == nil	 then
		ModuleBianlun.Log("Error: mainLayer Not  Availiable while in ModuleBianlun.CreatehandCardListWidget()");
		return;
	end

	if  ModuleBianlun.handCardListWidget.create == nil	 then
		ModuleBianlun.handCardListWidget.create = true;
		ModuleBianlun.handCardListWidget["Self"] 	= CModuleBianlunCardListWidget:create();
		ModuleBianlun.handCardListWidget["Other"] 	= CModuleBianlunCardListWidget:create();

		local 	cardSprite = cc.Sprite:create();
		cardSprite:setDisplayFrame(ModuleBianlun.GetSpriteFrame(ModuleBianlunConfiguration.card["black"]["天"]));

		local 	cardWidth = cardSprite:getContentSize().width;
		local 	cardHeight= cardSprite:getContentSize().height; 
		local 	margin    = cardWidth / 9;

		ModuleBianlun.handCardListWidget["Self"] :setCardSize(cardWidth, cardHeight);
		ModuleBianlun.handCardListWidget["Other"]:setCardSize(cardWidth, cardHeight);

		ModuleBianlun.handCardListWidget["Self"] :setCardMargin(margin);
		ModuleBianlun.handCardListWidget["Other"]:setCardMargin(margin);

		ModuleBianlun.handCardListWidget["Self"] :setWidgetPosition( AAP_X( ModuleBianlunConfiguration.position_hand_self_x ),  AAP_Y( ModuleBianlunConfiguration.position_hand_self_y ) );
		ModuleBianlun.handCardListWidget["Other"]:setWidgetPosition( AAP_X( ModuleBianlunConfiguration.position_hand_other_x ), AAP_Y( ModuleBianlunConfiguration.position_hand_other_y) );

		ModuleBianlun.handCardListWidget["Self"]:allowOperation();
--		ModuleBianlun.handCardListWidget["Other"]:allowOperation();

		----------------------------------------------------------------------
		--	玩家手牌控件集合处理
		
		ModuleBianlun.handCardListWidgetContainer["Self"]	:addChild(tolua.cast( 	ModuleBianlun.handCardListWidget["Self"],  "Node"), 100);
		ModuleBianlun.handCardListWidgetContainer["Other"]	:addChild(tolua.cast(	ModuleBianlun.handCardListWidget["Other"], "Node"), 100);
	end
end


function ModuleBianlun.CreateOutputCardListWidget( ... )
	-- body

	if 	ModuleBianlun.mainLayer == nil then
		ModuleBianlun.Log("Error@Lua, mainLayer Not Availiable while in ModuleBianlun.CreateOutputCardListWidget()");
		return;
	end	

	if 	ModuleBianlun.outputCardListWidget.create == nil then
		ModuleBianlun.outputCardListWidget.create = true;

		ModuleBianlun.outputCardListWidget["Self"] = CModuleBianlunOutCardListWidget:create();
		ModuleBianlun.outputCardListWidget["Other"]= CModuleBianlunOutCardListWidget:create();

		local 	cardSprite = cc.Sprite:create();
		cardSprite:setDisplayFrame(ModuleBianlun.GetSpriteFrame(ModuleBianlunConfiguration.card["blackout"]["天"]));

		local 	cardWidth = cardSprite:getContentSize().width;
		local 	cardHeight= cardSprite:getContentSize().height; 
		local 	margin    = - cardWidth / 3;

		ModuleBianlun.outputCardListWidget["Self"] :setCardSize(cardWidth, cardHeight);
		ModuleBianlun.outputCardListWidget["Other"]:setCardSize(cardWidth, cardHeight);

		ModuleBianlun.outputCardListWidget["Self"] :setCardMargin(margin);
		ModuleBianlun.outputCardListWidget["Other"]:setCardMargin(margin);

		ModuleBianlun.outputCardListWidget["Self"] :setWidgetPosition( AAP_X( ModuleBianlunConfiguration.position_output_self_x ), AAP_Y( ModuleBianlunConfiguration.position_output_self_y ) );
		ModuleBianlun.outputCardListWidget["Other"]:setWidgetPosition( AAP_X( ModuleBianlunConfiguration.position_output_other_x), AAP_Y( ModuleBianlunConfiguration.position_output_other_y) );	
	
		ModuleBianlun.mainLayer:addChild(tolua.cast( ModuleBianlun.outputCardListWidget["Self"], "Node")  );
		ModuleBianlun.mainLayer:addChild(tolua.cast( ModuleBianlun.outputCardListWidget["Other"], "Node") );	

	end
end


function ModuleBianlun.CreateTipMessage(  )
	-- body

	if 	ModuleBianlun.mainLayer == nil then
		ModuleBianlun.Log("Error@Lua, MainLayer Not Availiable while in ModuleBianlun.CreateTipMessage()");
		return ;
	end

	if 	ModuleBianlun.tipMessageWidget	== nil then

		ModuleBianlun.tipMessageBackWidget 	= cc.Sprite:create();
		ModuleBianlun.tipMessageBackWidget 	:setDisplayFrame(ModuleBianlun.GetSpriteFrame( ModuleBianlunConfiguration.tipMessageBack));

		local 	viewSize 	= cc.Director:getInstance():getVisibleSize();

		ModuleBianlun.tipMessageBackWidget:setPosition(viewSize.width/2, viewSize.height - 60);
		
		ModuleBianlun.tipMessageBackWidget:setVisible(false);
		ModuleBianlun.mainLayer:addChild(ModuleBianlun.tipMessageBackWidget, 10000);

		ModuleBianlun.tipMessageWidget 	= cc.LabelTTF:create("", ModuleBianlunConfiguration.tipFontName, ModuleBianlunConfiguration.tipFontSize);
		ModuleBianlun.tipMessageWidget:setColor(cc.c3b(38, 94, 1));
		ModuleBianlun.tipMessageWidget:setPosition( viewSize.width/2, viewSize.height - 60 );

		ModuleBianlun.tipMessageWidget:setVisible(false);
		ModuleBianlun.mainLayer:addChild(ModuleBianlun.tipMessageWidget, 10001);
	end
end

function ModuleBianlun.TipMessageCallback( ... )
	-- body

	if 	ModuleBianlun.tipMessageHandle ~= nil then
		cc.Director:getInstance():getScheduler():unscheduleScriptEntry(ModuleBianlun.tipMessageHandle);
		ModuleBianlun.tipMessageHandle = nil;

		ModuleBianlun.tipMessageWidget:setVisible(false);
		ModuleBianlun.tipMessageBackWidget:setVisible(false);
	end
end

function ModuleBianlun.ShowTipMessage( msg )
	-- body

	if 	ModuleBianlun.mainLayer == nil then
		ModuleBianlun.Log("Error@Lua, MainLayer Not Availiable while in ModuleBianlun.ShowTipMessage()");
		return;
	end

	if 	ModuleBianlun.tipMessageWidget 	== nil then
		ModuleBianlun.Log("Error@Lua, TipMessageWidget Not Availiable while in ModuleBianlun.ShowTipMessage()");
		return;
	end

	if 	ModuleBianlun.tipMessageHandle ~= nil then
		cc.Director:getInstance():getScheduler():unscheduleScriptEntry(ModuleBianlun.tipMessageHandle);
		ModuleBianlun.tipMessageHandle = nil;
	end

	ModuleBianlun.tipMessageWidget:setString(msg);
	ModuleBianlun.tipMessageWidget:setVisible(true);
	ModuleBianlun.tipMessageBackWidget:setVisible(true);

	ModuleBianlun.tipMessageHandle = cc.Director:getInstance():getScheduler():scheduleScriptFunc(ModuleBianlun.TipMessageCallback, ModuleBianlun.tipMessageWaitTime, false);
end


-------------------------------------------------------------------------------------------------------------------------------------
--	Client Script Function For C++
function ModuleBianlun.UpdatePlayerInfo( pos, id,  name )
	-- body

	local 		clientLogic = CModuleBianlunClientLogic:sharedClientLogic();
	local 		serverPos	= clientLogic:getServerPosition();

	if  	serverPos == pos 	then
			ModuleBianlun.logic_selfPlayerId 	= id;
			ModuleBianlun.logic_selfPlayerName 	= name;

			ModuleBianlun.UpdatePlayerHead(pos, name);
	else
			ModuleBianlun.logic_otherPlayerId	= id;
			ModuleBianlun.logic_otherPlayerName = name;

			ModuleBianlun.UpdatePlayerHead(pos, name);
	end
end

function ModuleBianlun.AlignHandCardBackWidgets( bSelf )
	-- body

	ModuleBianlun.Log("\n@@@\nDEBUG :AlignHandCardBackWidgets!\n@@@\n");

	local 	backNumSelf 	= table.getn(ModuleBianlun.handCardBackWidget["Self"]);
	local  	backNumOther	= table.getn(ModuleBianlun.handCardBackWidget["Other"]);

	local 	self_position_x 	=  	AAP_X(ModuleBianlunConfiguration.position_hand_self_x );
	local 	self_position_y 	=  	AAP_Y(ModuleBianlunConfiguration.position_hand_self_y );
	local 	other_position_x 	= 	AAP_X(ModuleBianlunConfiguration.position_hand_other_x);
	local 	other_position_y 	= 	AAP_Y(ModuleBianlunConfiguration.position_hand_other_y );
	
	local 	width 			= ModuleBianlun.handCardBackWidget["Self"][1]:getContentSize().width;
	local 	height 			= ModuleBianlun.handCardBackWidget["Self"][1]:getContentSize().height;
	local 	margin 			= width / 9;

	if 		bSelf == true then
			local 	self_start_x	= 0;
			if  	backNumSelf%2 == 0 then
					self_start_x =  ( self_position_x ) - backNumSelf/2 * (width + margin);
			else
					self_start_x =  ( self_position_x ) - backNumSelf/2 * (width + margin) - width/2;
			end

			for 	i = 1, backNumSelf do 
					ModuleBianlun.handCardBackWidget["Self"][i]:setPosition( ( self_start_x + (i - 1) *(width + margin) ), ( self_position_y ) );
			end
	else
			local   other_start_x 	= 0;
			if 		backNumOther%2 == 0 then
					other_start_x 	= ( other_position_x ) - backNumOther/2 *(width + margin);
			else
					other_start_x 	= ( other_position_x ) - backNumOther/2 *(width + margin) - width/2;
			end 

			for 	i = 1, backNumOther do 
					ModuleBianlun.handCardBackWidget["Other"][i]:setPosition( ( other_start_x + (i - 1) *(width + margin) ), ( other_position_y ) );
			end
	end
end

function ModuleBianlun.CreateHandCardBackWidgets( ... )		--	Create Hand Card Back Widget
	-- body

	if 	ModuleBianlun.mainLayer == nil then
		ModuleBianlun.Log("Error@Lua, mainLayer Not Availiable while in ModuleBianlun.CreateHandCardBackWidget()");
		return;
	end

	ModuleBianlun.Log("创建手牌背景");

	do
		local  	clientLogic 	= CModuleBianlunClientLogic:sharedClientLogic();
		local 	selfPos 		= clientLogic:getServerPosition();
		local 	otherPos 		= 1 - selfPos;
		local 	selfSize		= clientLogic:getPlayerHandCardSize(selfPos);
		local 	otherSize		= clientLogic:getPlayerHandCardSize(otherPos);
		local  	bChanged 		= false;

--		ModuleBianlun.Log(tostring(selfSize));
--		ModuleBianlun.Log( tostring( table.getn( ModuleBianlun.handCardBackWidget["Self"] ) ) );
--		ModuleBianlun.Log(tostring(otherSize));
--		ModuleBianlun.Log( tostring( table.getn( ModuleBianlun.handCardBackWidget["Other"] ) ) );

		for 	v in pairs(ModuleBianlun.handCardBackWidget["Self"]) do 
			--	ModuleBianlun.mainLayer:removeChild(ModuleBianlun.handCardBackWidget["Self"][v]);
				ModuleBianlun.handCardListWidgetContainer["Self"]:removeChild(ModuleBianlun.handCardBackWidget["Self"][v]);
		end
		ModuleBianlun.handCardBackWidget["Self"] = {};		--	Clear Previous

		for 	v in pairs(ModuleBianlun.handCardBackWidget["Other"]) do 
			--	ModuleBianlun.mainLayer:removeChild(ModuleBianlun.handCardBackWidget["Other"][v]);
				ModuleBianlun.handCardListWidgetContainer["Other"]:removeChild(ModuleBianlun.handCardBackWidget["Other"][v]);
		end
		ModuleBianlun.handCardBackWidget["Other"] = {};		--	Clear Previous		

		if  	selfSize > table.getn(ModuleBianlun.handCardBackWidget["Self"]) 	then
				ModuleBianlun.Log("自己手牌总数增加");


				bChanged  		= true;

				--	Clean Up Previous Back Widgets
				for 	v in pairs(ModuleBianlun.handCardBackWidget["Self"]) do 
						ModuleBianlun.handCardListWidgetContainer["Self"]:removeChild(ModuleBianlun.handCardBackWidget["Self"][v]);
				end
				ModuleBianlun.handCardBackWidget["Self"] = {};		--	Clear Previous
				
				for 	i = 1, selfSize do 
					ModuleBianlun.handCardBackWidget["Self"][i] = cc.Sprite:create();
					ModuleBianlun.handCardBackWidget["Self"][i]:setDisplayFrame(ModuleBianlun.GetSpriteFrame(ModuleBianlunConfiguration.cardPosition))
				--	ModuleBianlun.mainLayer:addChild(ModuleBianlun.handCardBackWidget["Self"][i]);

					ModuleBianlun.handCardListWidgetContainer["Self"]:addChild(ModuleBianlun.handCardBackWidget["Self"][i]);
				end

				ModuleBianlun.Log( tostring( table.getn( ModuleBianlun.handCardBackWidget["Self"] ) ) );

				ModuleBianlun.AlignHandCardBackWidgets(true);
		end

		if 		otherSize > table.getn(ModuleBianlun.handCardBackWidget["Other"])	then
				ModuleBianlun.Log("对方手牌总数增加");
				bChanged 		= true;

				for 	v in pairs(ModuleBianlun.handCardBackWidget["Other"]) do 
						ModuleBianlun.handCardListWidgetContainer["Other"]:removeChild(ModuleBianlun.handCardBackWidget["Other"][v]);
				end
				ModuleBianlun.handCardBackWidget["Other"] = {};		--	Clear Previous

				for 	i = 1, otherSize do 
						ModuleBianlun.handCardBackWidget["Other"][i] = cc.Sprite:create();
						ModuleBianlun.handCardBackWidget["Other"][i]:setDisplayFrame(ModuleBianlun.GetSpriteFrame(ModuleBianlunConfiguration.cardPosition))
				--		ModuleBianlun.mainLayer:addChild(ModuleBianlun.handCardBackWidget["Other"][i]);

						ModuleBianlun.handCardListWidgetContainer["Other"]:addChild(ModuleBianlun.handCardBackWidget["Other"][i]);
				end

				ModuleBianlun.Log( tostring( table.getn( ModuleBianlun.handCardBackWidget["Other"] ) ) );

				ModuleBianlun.AlignHandCardBackWidgets(false);
		end
	end
end


function ModuleBianlun.AlignHandCardListWidgets( bSelf )

	ModuleBianlun.Log("\n@@@\nDebug: AlignHandCardListWidgets!\n@@@\n");
	-- body
	local 	backNumSelf 	= table.getn(ModuleBianlun.handCardBackWidget["Self"]);
	local  	backNumOther	= table.getn(ModuleBianlun.handCardBackWidget["Other"]);

	local 	self_position_x = AAP_X(ModuleBianlunConfiguration.position_hand_self_x );
	local 	self_position_y = AAP_Y(ModuleBianlunConfiguration.position_hand_self_y );
	local 	other_position_x = AAP_X(ModuleBianlunConfiguration.position_hand_other_x);
	local 	other_position_y = AAP_Y(ModuleBianlunConfiguration.position_hand_other_y);

--[[
	local 	width 			=  AAP_W( ModuleBianlunConfiguration.handcard_width  );
	local 	margin 			=  AAP_W( ModuleBianlunConfiguration.handcard_margin );
--]]
	
--	local 	tempHandCard = cc.Sprite:create();
--	tempHandCard:setDisplayFrame(ModuleBianlun.GetSpriteFrame(ModuleBianlunConfiguration.card["black"]["天"]));

	local 	width 			= ModuleBianlun.handCardBackWidget["Self"][1]:getContentSize().width;
	local 	height 			= ModuleBianlun.handCardBackWidget["Self"][1]:getContentSize().height;
	local 	margin 			= width/ 9;

	if 		bSelf == true then
			local 	self_start_x	= 0;
			if  	backNumSelf%2 == 0 then
					self_start_x =  self_position_x - backNumSelf/2 * (width + margin);
			else
					self_start_x =  self_position_x - backNumSelf/2 * (width + margin) - width/2;
			end

			for 	i = 1, backNumSelf do 
					local 	child = tolua.cast(ModuleBianlun.handCardListWidget["Self"], "Node"):getChildByTag(i);
					if 		child ~= nil then
							if 	child:isVisible() == true and tolua.cast(child, "CModuleBianlunCardWidget"):isClicked() == true then
								ModuleBianlun.BianlunCardCallback(0, child);
							end						
							child:setPosition( ( self_start_x + (i - 1) *(width + margin) ), (self_position_y ) );

					end
			end
	else
			local   other_start_x 	= 0;
			if 		backNumOther%2 == 0 then
					other_start_x 	= other_position_x - backNumOther/2 *(width + margin);
			else
					other_start_x 	= other_position_x - backNumOther/2 *(width + margin) - width/2;
			end 

			for 	i = 1, backNumOther do 
					local 	child = tolua.cast(ModuleBianlun.handCardListWidget["Other"], "Node"):getChildByTag(i);
					if 		child ~= nil then
							if 	tolua.cast(child, "CModuleBianlunCardWidget"):isClicked() == true then
								ModuleBianlun.BianlunCardCallback(0, child);
							end						
							child:setPosition( ( other_start_x + (i - 1) *(width + margin) ), ( other_position_y ) );
					end
			end
	end
end

function ModuleBianlun.CreateHandCardWidgets( bSelf )		--	Create Hand Card Widgets
	-- body
	if 	ModuleBianlun.mainLayer == nil then
		ModuleBianlun.Log("Error@Lua, MainLayer Not Availiable while in ModuleBianlun.CreatehandCardListWidget()");
		return;
	end

	ModuleBianlun.Log("创建手牌");

	local  	clientLogic 	= CModuleBianlunClientLogic:sharedClientLogic();
	local 	selfPos 		= clientLogic:getServerPosition();
	local 	otherPos 		= 1 - selfPos;
	local 	selfSize		= clientLogic:getPlayerHandCardSize(selfPos);
	local 	otherSize		= clientLogic:getPlayerHandCardSize(otherPos);

	if 		bSelf == true then
			ModuleBianlun.Log("创建手牌 --Self");
			tolua.cast(ModuleBianlun.handCardListWidget["Self"], "Node"):removeAllChildren();
			for 	i = 1, selfSize do 
					local 	widget = CModuleBianlunCardWidget:create();
					widget:setCard(clientLogic:getPlayerHandCard(selfPos, i -1));
					widget:registerScriptHandler();

					tolua.cast(ModuleBianlun.handCardListWidget["Self"], "Node"):addChild(tolua.cast(widget, "Node"), 0, i);
			end

			ModuleBianlun.AlignHandCardListWidgets(true);
	else
			ModuleBianlun.Log("创建手牌--Other");
			tolua.cast(ModuleBianlun.handCardListWidget["Other"], "Node"):removeAllChildren();
			for 	i = 1, otherSize do 
					local 	widget = CModuleBianlunCardWidget:create();
					widget:setCard(clientLogic:getPlayerHandCard(otherPos, i -1));
					widget:registerScriptHandler();

					tolua.cast(ModuleBianlun.handCardListWidget["Other"], "Node"):addChild(tolua.cast(widget, "Node"), 0, i);
			end
			ModuleBianlun.AlignHandCardListWidgets(false);
	end

end

function ModuleBianlun.AlignOutputCardWigets( bSelf )
	-- body

	ModuleBianlun.Log("\n@@@\nDEBUG:	AlignOutputCardWigets!\n@@@\n");

	local  	clientLogic 	= CModuleBianlunClientLogic:sharedClientLogic();
	local 	selfPos 		= clientLogic:getServerPosition();
	local 	otherPos 		= 1 - selfPos;
	local 	selfSize		= clientLogic:getPlayerOutputCardSize(selfPos);
	local 	otherSize		= clientLogic:getPlayerOutputCardSize(otherPos);

	local 	self_position_x 	= AAP_X( ModuleBianlunConfiguration.position_output_self_x );
	local 	self_position_y 	= AAP_Y( ModuleBianlunConfiguration.position_output_self_y );
	local 	other_position_x 	= AAP_X( ModuleBianlunConfiguration.position_output_other_x);
	local 	other_position_y 	= AAP_Y( ModuleBianlunConfiguration.position_output_other_y);

	local 	tempOutout = cc.Sprite:create();
	tempOutout:setDisplayFrame(ModuleBianlun.GetSpriteFrame(ModuleBianlunConfiguration.card["blackout"]["天"]));

	local 	width 	= tempOutout:getContentSize().width;
	local 	height  = tempOutout:getContentSize().height;
	local 	margin  = - width / 3;
--[[
	local 	width 	= AAP_W( ModuleBianlunConfiguration.outputcard_width );
	local   margin  = AAP_W( ModuleBianlunConfiguration.outputcard_margin);
--]]
	ModuleBianlun.Log("Self Size: "..tostring(selfSize).."	Other Size: "..tostring(otherSize));

	local 	cardSprite = cc.Sprite:create();
	cardSprite:setDisplayFrame(ModuleBianlun.GetSpriteFrame(ModuleBianlunConfiguration.card["blackout"]["天"]));

	local 	offset = cardSprite:getContentSize().height /3;

	if 		bSelf == true 	then

			local 	self_start_x = self_position_x;



			for 	i = 1, selfSize do 
					local 	widget 	= tolua.cast( ModuleBianlun.outputCardListWidget["Self"], "Node"):getChildByTag(i);
					if 		widget ~= nil then
							tolua.cast(widget, "Node"):setPosition( ( self_start_x + ( (i - 1) * (width + margin) ) ), ( self_position_y -( (i - 1)* ( offset ) ) ) );
					else
							ModuleBianlun.Log("Error@Lua, OutputCardListWidget get Child Failed!");
					end
			end
	else
			local 	other_start_x = other_position_x;

			for 	i = 1, otherSize do 
					local 	widget 	= tolua.cast( ModuleBianlun.outputCardListWidget["Other"], "Node"):getChildByTag(i);
					if 		widget ~= nil then
							tolua.cast(widget, "Node"):setPosition( ( other_start_x - ( (i - 1) * (width + margin) ) ), ( other_position_y + ( (i - 1)*( offset ) ) ) );
					else
							ModuleBianlun.Log("Error@Lua, OutputCardListWidget get Child Failed!");
					end
			end
	end
end

function ModuleBianlun.CreateOutputCardWidgets( bSelf )
	-- body

	if 	ModuleBianlun.mainLayer == nil then
		ModuleBianlun.Log("Error@Lua, MainLayer Not Availiable while in ModuleBianlun.CreateOutputCardWidgets()");
		return;
	end	

	ModuleBianlun.Log("创建隐藏");

	local  	clientLogic 	= CModuleBianlunClientLogic:sharedClientLogic();
	local 	selfPos 		= clientLogic:getServerPosition();
	local 	otherPos 		= 1 - selfPos;
	local 	selfSize		= clientLogic:getPlayerOutputCardSize(selfPos);
	local 	otherSize		= clientLogic:getPlayerOutputCardSize(otherPos);

	if 		bSelf 	== 	true 	then
			ModuleBianlun.Log("创建隐藏 --Self");
			tolua.cast(ModuleBianlun.outputCardListWidget["Self"], "Node"):removeAllChildren();

			tolua.cast( ModuleBianlun.outputCardListWidget["Self"], "Node"):setVisible(true);
			for 	i = 1, selfSize do 
					local 	widget = CModuleBianlunOutCardWidget:create();
					widget:setCard(clientLogic:getPlayerOutputCard(selfPos, i -1));

					tolua.cast(ModuleBianlun.outputCardListWidget["Self"], "Node"):addChild(tolua.cast(widget, "Node"), 0, i);
			end

			ModuleBianlun.AlignOutputCardWigets(true);	
	else
			ModuleBianlun.Log("创建隐藏 --Other");
			tolua.cast(ModuleBianlun.outputCardListWidget["Other"], "Node"):removeAllChildren();

			tolua.cast( ModuleBianlun.outputCardListWidget["Other"], "Node"):setVisible(true);
			for 	i = 1, otherSize do 
					local 	widget = CModuleBianlunOutCardWidget:create();
					widget:setCard(clientLogic:getPlayerOutputCard(otherPos, i -1));

					tolua.cast(ModuleBianlun.outputCardListWidget["Other"], "Node"):addChild(tolua.cast(widget, "Node"), 0, i);
			end

			ModuleBianlun.AlignOutputCardWigets(false);			
	end
end



function ModuleBianlun.BianlunCardCallback( tag, sender )
	-- body

--	ModuleBianlun.Log("Card CallBack !");
--	ModuleBianlun.Log(tostring(tag));
--	ModuleBianlun.Log(tostring(sender));
	
	local 	clientLogic = CModuleBianlunClientLogic:sharedClientLogic();
	local 	position_x = tolua.cast(sender, "Node"):getPositionX();
	local 	position_y = tolua.cast(sender, "Node"):getPositionY();
	local 	parent 	   = tolua.cast( tolua.cast(sender, "Node"):getParent(), "CModuleBianlunCardListWidget");

	if 		parent:isAllowOperation() == true	then

			if 		parent == ModuleBianlun.handCardListWidget["Self"] 	then
					--	己方手牌
					tolua.cast(sender, "CModuleBianlunCardWidget"):clicked();

					local 	cardSprite = cc.Sprite:create();
					cardSprite:setDisplayFrame(ModuleBianlun.GetSpriteFrame(ModuleBianlunConfiguration.card["black"]["天"]));

					local 	offset_height  = cardSprite:getContentSize().height / 2;
				
					if 		tolua.cast(sender, "CModuleBianlunCardWidget"):isClicked() == false then
							tolua.cast(sender, "Node"):setPosition(cc.p( ( position_x ), ( position_y - ( offset_height ) ) ));
					else 
							tolua.cast(sender, "Node"):setPosition(cc.p( ( position_x ), ( position_y + ( offset_height ) ) ));
					end			
			elseif	parent == ModuleBianlun.handCardListWidget["Other"]	then
					--	对方手牌

--					ModuleBianlun.Log("对方手牌");
--					ModuleBianlun.Log("Sender: "..tostring(sender).." Tag: "..tostring(tag));

					local 	widget = tolua.cast( sender, "CModuleBianlunCardWidget");
					local 	card   = widget:getCard();
					clientLogic:network_client_notifyPlayerCheckCard(card);

			end


	end
end

function ModuleBianlun.RegisterBianlunCardHandler( object )
	-- body
	--	Object is CModuleBianlunCardWidget

	local 	menuItem 	= tolua.cast(object, "MenuItemImage");
	menuItem:registerScriptTapHandler(ModuleBianlun.BianlunCardCallback);
end

function ModuleBianlun.AllowCheckOtherHandCard( num )
	-- body

	if 	num ~= 0 then
		ModuleBianlun.handCardListWidget["Other"]:allowOperation();
	else
		ModuleBianlun.handCardListWidget["Other"]:disAllowOperation();
	end
end

function ModuleBianlun.RoundUpdatePlayerHandCards( bSelf )
	-- body
	local 	clientLogic = CModuleBianlunClientLogic:sharedClientLogic();
	local 	selfPos 	= clientLogic:getServerPosition();
	local 	otherPos	= 1 - selfPos;

	if 	 	bSelf == true then
			ModuleBianlun.handCardListWidget["Self"]:clearCard();
			tolua.cast(ModuleBianlun.handCardListWidget["Self"], "Node"):removeAllChildren();

			local 	selfHandCardSize = clientLogic:getPlayerHandCardSize(selfPos);
			for 	i = 1, selfHandCardSize do 
					local 	card = clientLogic:getPlayerHandCard(selfPos, i -1);
					if 		ModuleBianlun.handCardListWidget["Self"] ~= nil then
							ModuleBianlun.handCardListWidget["Self"]:addCard(card);
					else
							ModuleBianlun.Log("Error@Lua, Self Hand card Widget Not Availiable while in ModuleBianlun.UpdatePlayerHandCards()");
							do break end
					end
			end
			ModuleBianlun.handCardListWidget["Self"]:updateCardListWidget(true);
	else
			ModuleBianlun.handCardListWidget["Other"]:clearCard();
			tolua.cast(ModuleBianlun.handCardListWidget["Other"], "Node"):removeAllChildren();

			local 	otherHandCardSize = clientLogic:getPlayerHandCardSize(otherPos);
			for 	i = 1, otherHandCardSize do
					local 	card = clientLogic:getPlayerHandCard(otherPos, i -1);
					if 		ModuleBianlun.handCardListWidget["Other"] ~= nil then
							ModuleBianlun.handCardListWidget["Other"]:addCard(card);
					else
							ModuleBianlun.Log("Error@Lua, Other Hand card Widget Not Availiable while in ModuleBianlun.UpdatePlayerHandCards()");
							do  break end
					end
			end
			ModuleBianlun.handCardListWidget["Other"]:updateCardListWidget(false);
	end
end

function ModuleBianlun.UpdatePlayerHandCards( bSelf )
	-- body
	ModuleBianlun.Log("更新手中牌");
	local 	clientLogic = CModuleBianlunClientLogic:sharedClientLogic();
	local 	selfPos 	= clientLogic:getServerPosition();
	local 	otherPos	= 1 - selfPos;

	local 	backNumSelf 	= table.getn(ModuleBianlun.handCardBackWidget["Self"]);
	local  	backNumOther	= table.getn(ModuleBianlun.handCardBackWidget["Other"]);

	if 	 	bSelf == true then
			--	己方隐藏
			ModuleBianlun.AlignHandCardListWidgets(true);

			local 	size = clientLogic:getPlayerHandCardSize(selfPos);

			ModuleBianlun.Log("补牌重现处理.Self."..tostring(size));

			for 	i = 1, size do 
					local 	card   = clientLogic:getPlayerHandCard(selfPos, i - 1);
					ModuleBianlunServerLogic.Log(card:dumpCard());
					local 	widget = tolua.cast( ModuleBianlun.handCardListWidget["Self"], "Node"):getChildByTag(card:getTag());
					if 		widget ~= nil then
						if 		widget:isVisible() == false then
								
								tolua.cast(widget, "CModuleBianlunCardWidget"):setCard(card);
								widget:setVisible(true);
						else
								tolua.cast(widget, "CModuleBianlunCardWidget"):setCard(card);
						end
					else
							ModuleBianlun.Log("Error@Lua, handCardListWidget Not Availiable !");
					end
			end
	else
			--	对方隐藏
			ModuleBianlun.AlignHandCardListWidgets(false);

			local 	size = clientLogic:getPlayerHandCardSize(otherPos);

			ModuleBianlun.Log("补牌重现处理. Other."..tostring(size));

			for 	i = 1, size do 
					local 	card   = clientLogic:getPlayerHandCard(otherPos, i - 1);
					local 	widget = tolua.cast( ModuleBianlun.handCardListWidget["Other"], "Node"):getChildByTag(card:getTag());
					if 		widget ~= nil then
							if 		widget:isVisible() == false then
									tolua.cast(widget, "CModuleBianlunCardWidget"):setCard(card);
									widget:setVisible(true);
							else
									tolua.cast(widget, "CModuleBianlunCardWidget"):setCard(card);
							end
					else
							ModuleBianlun.Log("Error@Lua, handCardListWidget Not Availiable!");
					end
			end
	end
end


function ModuleBianlun.UpdatePlayerOutputCards( bSelf )
	-- body
	ModuleBianlun.Log("通知玩家隐藏"..tostring(bSelf));

	local 	clientLogic = CModuleBianlunClientLogic:sharedClientLogic();
	local 	selfPos 	= clientLogic:getServerPosition();
	local 	otherPos	= 1 - selfPos;

	if 		bSelf == true then
			local 	selfOutputSize = clientLogic:getPlayerOutputCardSize(selfPos);
			if 		selfOutputSize ~= 0 then

					for 	i = 1, selfOutputSize do

						local 	card = clientLogic:getPlayerOutputCard(selfPos, i - 1);

						ModuleBianlun.Log("己方隐藏："..tostring(card:dumpCard()));


						local 	widget = tolua.cast(ModuleBianlun.handCardListWidget["Self"], "Node"):getChildByTag(card:getTag());
						if 		widget ~= nil   then

								if 	widget:isVisible() == true then
								--	CNotificationCenterExporter:getInstance():registerScriptObserver(widget, ModuleBianlun.NotificationHandler, "ActionFinishedEvent" );

									local 	action_moveTo 	= cc.MoveTo:create(0.3, cc.p( AAP_X( ModuleBianlunConfiguration.position_output_self_x ), AAP_Y( ModuleBianlunConfiguration.position_output_self_y ) ));
									tolua.cast(widget, "Node"):runAction(action_moveTo);

									--	出牌动画 
									local 	animationWidget = cc.Sprite:create();
									animationWidget:setPosition(tolua.cast(widget, "Node"):getContentSize().width/2, tolua.cast(widget, "Node"):getContentSize().height/2);
									local 	animate 		= cc.Animate:create(cc.AnimationCache:getInstance():getAnimation("animation_output"));
									animationWidget:runAction(animate);
									tolua.cast(widget, "Node"):addChild(animationWidget, 0, 100);

									print("通知中心-- 注册出牌动画-- "..tostring(widget));
									ModuleBianlun.RegisterNotificationActionFinishedEvent(widget);

									--	头像出牌效果
									local 	shineWidget 	= cc.Sprite:create();	shineWidget:setDisplayFrame(ModuleBianlun.GetSpriteFrame(ModuleBianlunConfiguration.shine));
									shineWidget:setPosition(ModuleBianlun.playerWidgets["Self"]["Head"]:getContentSize().width/2, ModuleBianlun.playerWidgets["Self"]["Head"]:getContentSize().height/2);
									local 	action 			= cc.RotateBy:create(1, 360);
									shineWidget:runAction(action);
									ModuleBianlun.playerWidgets["Self"]["Head"]:addChild(shineWidget, 0, 100);

									print("通知中心-- 注册己方头像出牌闪光-- "..tostring(shineWidget));
									ModuleBianlun.RegisterNotificationActionFinishedEvent(shineWidget);


									ModuleBianlun.Log("己方隐藏播放动画");
								end
						else
								ModuleBianlun.Log("Error@Lua, 己方手中牌控件获取出错!");
						end

					end
--					ModuleBianlun.UpdateOutCardWidget(ModuleBianlun.outputCardWidget["Self"], card:getType(), card:getValue());
			elseif 	selfOutputSize == 0 then
					--	No Output
--					tolua.cast(ModuleBianlun.outputCardWidget["Self"], "Node"):setVisible(false);
					tolua.cast(ModuleBianlun.outputCardListWidget["Self"], "Node"):setVisible(false);
			else
					ModuleBianlun.Log("WARNING, Self Output Card Number Not Correct!");
			end
	else
			local 	otherOutputSize 	= clientLogic:getPlayerOutputCardSize(otherPos);
			if 		otherOutputSize 	~= 0 then

					for 	i = 1, otherOutputSize do

						local 	card 	= clientLogic:getPlayerOutputCard(otherPos, i - 1);

						ModuleBianlun.Log("对方隐藏: "..tostring(card:dumpCard()));

						local 	widget = tolua.cast(ModuleBianlun.handCardListWidget["Other"], "Node"):getChildByTag(card:getTag());
						if 		widget ~= nil then
								if 	widget:isVisible() == true then
								--	CNotificationCenterExporter:getInstance():registerScriptObserver(widget, ModuleBianlun.NotificationHandler, "ActionFinishedEvent" );
									
									local 	action_moveTo 	= cc.MoveTo:create(0.3, cc.p( AAP_X( ModuleBianlunConfiguration.position_output_other_x ), AAP_Y( ModuleBianlunConfiguration.position_output_other_y) ));
									tolua.cast(widget, "Node"):runAction(action_moveTo);	

									--	出牌动画
									local 	animationWidget = cc.Sprite:create();
									animationWidget:setPosition(tolua.cast(widget, "Node"):getContentSize().width/2, tolua.cast(widget, "Node"):getContentSize().height/2);
									local 	animate 		= cc.Animate:create(cc.AnimationCache:getInstance():getAnimation("animation_output"));
									animationWidget:runAction(animate);
									tolua.cast(widget, "Node"):addChild(animationWidget, 0, 100);

									print("通知中心-- 注册对方出牌动画-- "..tostring(widget));
									ModuleBianlun.RegisterNotificationActionFinishedEvent(widget);

									--	头像出牌效果
									local 	shineWidget 	= cc.Sprite:create();	shineWidget:setDisplayFrame(ModuleBianlun.GetSpriteFrame(ModuleBianlunConfiguration.shine));
									shineWidget:setPosition(ModuleBianlun.playerWidgets["Other"]["Head"]:getContentSize().width/2, ModuleBianlun.playerWidgets["Other"]["Head"]:getContentSize().height/2);
									local 	action 			= cc.RotateBy:create(1, 360);
									shineWidget:runAction(action);
									ModuleBianlun.playerWidgets["Other"]["Head"]:addChild(shineWidget, 0, 100);	
									print("通知中心-- 注册对方头像闪光--"..tostring(shineWidget));
									ModuleBianlun.RegisterNotificationActionFinishedEvent(shineWidget);							


									ModuleBianlun.Log("对方隐藏播放动画");	
								end				
						else
								ModuleBianlun.Log("Error@Lua, 对方手中牌控件获取出错!");
						end
					end

--					ModuleBianlun.UpdateOutCardWidget(ModuleBianlun.outputCardWidget["Other"], card:getType(), card:getValue());
			elseif 	otherOutputSize		== 0 then
					--	No Output
--					tolua.cast(ModuleBianlun.outputCardWidget["Other"], "Node"):setVisible(false);
					tolua.cast(ModuleBianlun.outputCardListWidget["Other"], "Node"):setVisible(false);
			else
					ModuleBianlun.Log("WARNING, Other OutputCard Number Not Correct !");
			end
	end
end

function ModuleBianlun.ShowPlayerOutputCards( bSelf )
	-- body
	ModuleBianlun.Log("显示玩家隐藏"..tostring(bSelf));
	local 	clientLogic = CModuleBianlunClientLogic:sharedClientLogic();
	local 	selfPos 	= clientLogic:getServerPosition();
	local 	otherPos	= 1 - selfPos;

	if 		bSelf == true then
			local 	selfOutputSize = clientLogic:getPlayerOutputCardSize(selfPos);
			if 		selfOutputSize ~= 0 then

					for 	i = 1, selfOutputSize do 
							local 	card 	= clientLogic:getPlayerOutputCard(selfPos, i - 1);
							ModuleBianlun.Log("己方隐藏:"..tostring(card:dumpCard()));

							ModuleBianlun.outputCardListWidget["Self"]:addCard(card);
					end
					ModuleBianlun.outputCardListWidget["Self"]:updateCardListWidget(true);


--[[
					local 	card 	= clientLogic:getPlayerOutputCard(selfPos, 0);
					ModuleBianlun.Log("己方隐藏:"..tostring(card:dumpCard()));				
					ModuleBianlun.UpdateOutCardWidget(ModuleBianlun.outputCardWidget["Self"], card:getType(), card:getValue())
--]]					


			elseif 	selfOutputSize == 0 then
					--	No Output
					tolua.cast(ModuleBianlun.outputCardListWidget["Self"], "Node"):setVisible(false);

			else
					ModuleBianlun.Log("WARNING, Self Output Card Number Not Correct!");
			end
	else
			local 	otherOutputSize 	= clientLogic:getPlayerOutputCardSize(otherPos);
			if 		otherOutputSize 	~= 0 then

					for 	i = 1, otherOutputSize do
							local  card  = clientLogic:getPlayerOutputCard(otherPos, i - 1);
							ModuleBianlun.Log("对方隐藏:"..tostring(card:dumpCard()));

							ModuleBianlun.outputCardListWidget["Other"]:addCard(card);
					end
					ModuleBianlun.outputCardListWidget["Other"]:updateCardListWidget(false);

--[[
					local 	card 	= clientLogic:getPlayerOutputCard(otherPos, 0);
					ModuleBianlun.Log("对方隐藏:"..tostring(card:dumpCard()));
					ModuleBianlun.UpdateOutCardWidget(ModuleBianlun.outputCardWidget["Other"], card:getType(), card:getValue());
--]]					
			elseif 	otherOutputSize		== 0 then
					--	No Output
					tolua.cast(ModuleBianlun.outputCardListWidget["Other"], "Node"):setVisible(false);
			else
					ModuleBianlun.Log("WARNING, Other OutputCard Number Not Correct !");
			end
	end	
end


function ModuleBianlun.RecordPlayerGameResultPlayerList( name )
	-- body
	ModuleBianlun.playerList[#ModuleBianlun.playerList + 1] = name;
end

function ModuleBianlun.RecordPlayerGameResultWinnerAward( exp, gongxun, bingli, liang, tili )
	-- body
	ModuleBianlun.award_exp 	= exp;
	ModuleBianlun.award_gongxun = gongxun;
	ModuleBianlun.award_bingli 	= bingli;
	ModuleBianlun.award_liang 	= liang;
	ModuleBianlun.award_tili	= tili;
end

function ModuleBianlun.RecordPlayerGameResultWinnerAwardDaoJu( item )
	-- body
	ModuleBianlun.award_daoju[#ModuleBianlun.award_daoju + 1] = item;
end

function ModuleBianlun.RecordPlayerGameResultLosserAward( exp, bingli, liang, tili )
	-- body
	ModuleBianlun.award_exp 	= exp;
	ModuleBianlun.award_bingli 	= bingli;
	ModuleBianlun.award_liang 	= liang;
	ModuleBianlun.award_tili	= tili;
end

function ModuleBianlun.ForceClientLeave( ... )
	-- body

	ModuleBianlun.Log("Client Leaving !");

	ModuleBianlun.PreLeaveModuleBianlun();


	local  	clientLogic 	= CModuleBianlunClientLogic:sharedClientLogic();
	local  	winnerPosition 	= clientLogic:getWinnerPosition();

	local 	playerList 	=  	ModuleBianlun.playerList;
	local 	exp 		= 	ModuleBianlun.award_exp;
	local 	gongxun 	= 	ModuleBianlun.award_gongxun;
	local 	bingli 		= 	ModuleBianlun.award_bingli;
	local 	liang 		= 	ModuleBianlun.award_liang;
	local 	tili 		= 	ModuleBianlun.award_tili;
	local 	daoju 		= 	{};
	for 	v 	in pairs(ModuleBianlun.award_daoju) do
			daoju[v]	= ModuleBianlun.award_daoju[v];
	end

	--	Clear Recorded First
	ModuleBianlun.playerList 	= {};
	ModuleBianlun.award_daoju 	= {};
	ModuleBianlun.award_exp 	= nil;
	ModuleBianlun.award_gongxun = nil;
	ModuleBianlun.award_bingli  = nil;
	ModuleBianlun.award_liang 	= nil;
	ModuleBianlun.award_tili	= nil;

	print(tostring(exp));
	print(tostring(gongxun));
	print(tostring(liang));
	print(tostring(tili));

	print("是否为遭遇辩论: "..tostring(ModuleBianlun.bEncounter));

	if 	ModuleBianlun.bEncounter == false then
		if 		winnerPosition 	== clientLogic:getServerPosition() then
					
				cc.Director:getInstance():replaceScene(ModuleResult.ShowSingleResult( true, true, playerList, daoju, exp, gongxun, liang, tili))
		else

				cc.Director:getInstance():replaceScene(ModuleResult.ShowSingleResult( true, false,playerList, daoju, exp, gongxun, liang, tili))
		end
	else
		if 		winnerPosition 	== clientLogic:getServerPosition() then
				ModuleBianlun.mainLayer:addChild(ModuleResult.ShowEncounterResult  ( true, true, gongxun, bingli, liang, tili ));
		else
				ModuleBianlun.mainLayer:addChild(ModuleResult.ShowEncounterResult  ( true, false,gongxun, bingli, liang, tili ));
		end
	end
end





function ModuleBianlun.HandleCompareAnimationEffect( ... )
	-- body

	print("决胜动画");

	if 	ModuleBianlun.centerAnimationWidgets ~= nil then
		local 	animation 	= cc.AnimationCache:getInstance():getAnimation("animation_juesheng");
		local 	action 		= cc.Animate:create(animation);
		local 	repeatAction = cc.Repeat:create(action, 2);

		ModuleBianlun.centerAnimationWidgets:setVisible(true);
		ModuleBianlun.centerAnimationWidgets:runAction(repeatAction);

		print("通知中心 -- 注册决胜动画 --"..tostring(ModuleBianlun.centerAnimationWidgets));
		ModuleBianlun.RegisterNotificationActionFinishedEvent(ModuleBianlun.centerAnimationWidgets);
	end

end

function ModuleBianlun.HandleCommonSkillSoundEffect( pos, gender, type )
	-- body

	--	音效
	ModuleBianlunSound.PlayCommonSkillEffect(gender, type);
end


function ModuleBianlun.HandleHeroSkillEffect( pos, hero, skill )
	-- body

	print(tostring(pos)..tostring(hero)..tostring(skill));

	--	Sound Effect
	ModuleBianlunSound.PlayHeroSkillEffect(hero, skill);

	--	Animation Effect
	local 	widget 		= cc.Sprite:create();
	local 	animation 	= cc.AnimationCache:getInstance():getAnimation("animation_fire");
	local 	action 		= cc.Animate:create(animation);

	widget:runAction(action);

	local 	clientLogic 	= CModuleBianlunClientLogic:sharedClientLogic();
	if 	clientLogic:getServerPosition() == pos then
		--	己方

		print(tostring(ModuleBianlun.skillWidgets["Self"].firstSkill["label"]));
		print(tostring(	ModuleBianlun.skillWidgets["Self"].firstSkill["label"]:getLabel()));

		if 	tolua.cast(ModuleBianlun.skillWidgets["Self"].firstSkill["label"]:getLabel(), "LabelTTF"):getString() == skill then
			widget:setPosition(ModuleBianlun.skillWidgets["Self"].firstSkill["back"]:getContentSize().width/2, ModuleBianlun.skillWidgets["Self"].firstSkill["back"]:getContentSize().height/2);
			ModuleBianlun.skillWidgets["Self"].firstSkill["back"]:addChild(widget, 0, 100);

			print("通知中心 -- 注册己方第一技能触发动画 -- "..tostring(ModuleBianlun.skillWidgets["Self"].firstSkill["back"]));
			ModuleBianlun.RegisterNotificationActionFinishedEvent(ModuleBianlun.skillWidgets["Self"].firstSkill["back"]);
		else
			widget:setPosition(ModuleBianlun.skillWidgets["Self"].secondSkill["back"]:getContentSize().width/2, ModuleBianlun.skillWidgets["Self"].secondSkill["back"]:getContentSize().height/2);
			ModuleBianlun.skillWidgets["Self"].secondSkill["back"]:addChild(widget, 0, 100);

			print("通知中心 -- 注册己方第二技能触发动画 -- "..tostring(ModuleBianlun.skillWidgets["Self"].secondSkill["back"]));
			ModuleBianlun.RegisterNotificationActionFinishedEvent(ModuleBianlun.skillWidgets["Self"].secondSkill["back"]);
		end
	else
		--	对方
		if 	tolua.cast( ModuleBianlun.skillWidgets["Other"].firstSkill["label"]:getLabel(), "LabelTTF"):getString() == skill then
			widget:setPosition( tolua.cast( ModuleBianlun.skillWidgets["Other"].firstSkill["back"], "Node"):getContentSize().width/2,  ModuleBianlun.skillWidgets["Other"].firstSkill["back"]:getContentSize().height/2);
			ModuleBianlun.skillWidgets["Other"].firstSkill["back"]:addChild(widget, 0, 100);

			print("通知中心 -- 注册对方第一技能触发动画 --"..tostring(ModuleBianlun.skillWidgets["Other"].firstSkill["back"]));
			ModuleBianlun.RegisterNotificationActionFinishedEvent(ModuleBianlun.skillWidgets["Other"].firstSkill["back"]);
		else
			widget:setPosition(ModuleBianlun.skillWidgets["Other"].secondSkill["back"]:getContentSize().width/2, ModuleBianlun.skillWidgets["Other"].secondSkill["back"]:getContentSize().height/2);
			ModuleBianlun.skillWidgets["Other"].secondSkill["back"]:addChild(widget, 0, 100);

			print("通知中心 --注册对方第二技能触发动画 --"..tostring(ModuleBianlun.skillWidgets["Other"].secondSkill["back"]));
			ModuleBianlun.RegisterNotificationActionFinishedEvent(ModuleBianlun.skillWidgets["Other"].secondSkill["back"]);
		end		
	end 

end

-------------------------------------------------------------------------------------------------------------------------------------
--	Animation Control


function ModuleBianlun.CreateXianhouWidget()
	if 	ModuleBianlun.mainLayer == nil then
		ModuleBianlun.Log("Error: mainLayer Not Avaliable while in ModuleBianlun.CreateXianhouWidget()");
		return;
	end;

	if 	ModuleBianlun.xianhouWidgets.create == nil then
		ModuleBianlun.xianhouWidgets.create = true;
		
		local viewOrigin	= cc.Director:getInstance():getVisibleOrigin();
		local viewSize 		= cc.Director:getInstance():getVisibleSize();

		ModuleBianlun.xianhouWidgets["Animation"] = cc.Sprite:create();
		ModuleBianlun.xianhouWidgets["Self"]	  = cc.Sprite:create(); 
		ModuleBianlun.xianhouWidgets["Other"] 	  = cc.Sprite:create();

		ModuleBianlun.xianhouWidgets["Animation"]:setPosition(viewOrigin.x + viewSize.width/2, viewOrigin.y + viewSize.height/2);

		local 	action 	= cc.FlipX:create(true);
		ModuleBianlun.xianhouWidgets["Animation"]:runAction(action);


		ModuleBianlun.xianhouWidgets["Self"] :setPosition ( AAP_X( 755 - 60 	), 	AAP_Y( 180 + 50  - 10 ) );
		ModuleBianlun.xianhouWidgets["Other"]:setPosition ( AAP_X( 105 + 150   	), 	AAP_Y( 560 - 120 - 15) );

		ModuleBianlun.mainLayer:addChild(ModuleBianlun.xianhouWidgets["Animation"]);
		ModuleBianlun.mainLayer:addChild(ModuleBianlun.xianhouWidgets["Self"] , 10);
		ModuleBianlun.mainLayer:addChild(ModuleBianlun.xianhouWidgets["Other"], 10);

		ModuleBianlun.centerAnimationWidgets 	= cc.Sprite:create();
		ModuleBianlun.centerAnimationWidgets:setPosition(viewOrigin.x + viewSize.width/2, viewOrigin.y + viewSize.height/2 + 100);
		ModuleBianlun.mainLayer:addChild(ModuleBianlun.centerAnimationWidgets, 1000);
	end 

end



function ModuleBianlun.UpdateXianhou( bXianShou )
	-- body
--	ModuleBianlun.Log(tostring(ModuleBianlun.mainLayer).."vs."..tostring(bXianShou));

	if 	ModuleBianlun.mainLayer == nil then	
		ModuleBianlun.Log("Error: mainLayer Not Avaliable while in ModuleBianlun.UpdateXianhou()");
		return
	end

	if  ModuleBianlun.xianhouWidgets.create == nil then
		ModuleBianlun.Log("Error: XianHou Widgets Not Avaliable while in ModuleBianlun.UpdateXianhou()");
		return
	end

	local animationCache 	= cc.AnimationCache:getInstance();
	local xianhouAnimation 	= animationCache:getAnimation("animation_xianhou_round");
	local action 			= cc.Animate:create(xianhouAnimation);

--	CNotificationCenterExporter:getInstance():registerScriptObserver(ModuleBianlun.xianhouWidgets["Animation"], ModuleBianlun.NotificationHandler, "ActionFinishedEvent")
	print("通知中心 -- 注册先后手动画 -- "..tostring(ModuleBianlun.xianhouWidgets["Animation"]));
	ModuleBianlun.RegisterNotificationActionFinishedEvent(ModuleBianlun.xianhouWidgets["Animation"]);

	ModuleBianlun.xianhouWidgets["Self"]:setVisible(false);
	ModuleBianlun.xianhouWidgets["Other"]:setVisible(false);
	
	ModuleBianlun.xianhouWidgets["Animation"]:setVisible(true);
	ModuleBianlun.xianhouWidgets["Animation"]:runAction(action);


	ModuleBianlun.logic_bxianshou = bXianShou;
end

--------------------------------------------------------------------------------------------------------------------------------------------------------------------
--	Operation && Skill

function ModuleBianlun.RetrieveClickedCards( ... )
	-- body

	ModuleBianlun.Log("获取选中隐藏");

	if 	ModuleBianlun.mainLayer == nil then
		ModuleBianlun.Log("Error@Lua, MainLayer Not Availiable while in ModuleBianlun.RetrieveClickedCards()");
		return ;
	end

	if 	ModuleBianlun.handCardListWidget.create == nil then
		ModuleBianlun.Log("Error@Lua, handCardListWidget Not Availiable while in ModuleBianlun.RetrieveClickedCards()");
		return;
	end

	ModuleBianlun.handCardListWidget["Self"]:retrieveClickedCardsList();
	local 	cardList = ModuleBianlun.handCardListWidget["Self"]:getClickedCardsList();

	local 	clientLogic = CModuleBianlunClientLogic:sharedClientLogic();
	clientLogic:updateClickedCardList(cardList);
end


function ModuleBianlun.ShowPlayerWidgets( bShow )
	-- body

	--	操作按钮更新
	if 	bShow == true then
		tolua.cast(ModuleBianlun.operationWidgets["显示"], "Node"):setVisible(false);
		tolua.cast(ModuleBianlun.operationWidgets["隐藏"], "Node"):setVisible(true);
	else
		tolua.cast(ModuleBianlun.operationWidgets["显示"], "Node"):setVisible(true);
		tolua.cast(ModuleBianlun.operationWidgets["隐藏"], "Node"):setVisible(false);		
	end


	--	卷轴动画效果
	local 	animation_self 	= cc.AnimationCache:getInstance():getAnimation("animation_juanzhouself");
	local 	action_self 	= cc.Animate:create(animation_self);

	local 	selfAction 		= nil;
	if 		bShow 			== true then
			selfAction 		= action_self:reverse();
	else
			selfAction 		= action_self;
	end

	tolua.cast(ModuleBianlun.handCardListWidgetContainer["Self"]:getChildByTag(100), "Sprite"):runAction(selfAction);

	local 	animation_oher 	= cc.AnimationCache:getInstance():getAnimation("animation_juanzhouother");
	local 	action_other 	= cc.Animate:create(animation_oher);

	local 	otherAction 	= nil;
	if 		bShow 			== true then
			otherAction 	= action_other:reverse();
	else
			otherAction 	= action_other;
	end

	tolua.cast(ModuleBianlun.handCardListWidgetContainer["Other"]:getChildByTag(100), "Sprite"):runAction(otherAction);	


	--	 控件显示隐藏

	if 	bShow  == false then

		for v 	in pairs(ModuleBianlun.handCardBackWidget["Self"]) do 
			ModuleBianlun.handCardBackWidget["Self"][v]:setVisible(bShow);
		end


		for v 	in pairs(ModuleBianlun.handCardBackWidget["Other"])do
			ModuleBianlun.handCardBackWidget["Other"][v]:setVisible(bShow);
		end

		tolua.cast(ModuleBianlun.handCardListWidget["Self"], "Node"):setVisible(bShow);
		tolua.cast(ModuleBianlun.handCardListWidget["Other"],"Node"):setVisible(bShow);
	else

		print("通知中心 -- 注册己方卷轴动画 -- "..tostring(ModuleBianlun.handCardListWidgetContainer["Self"]:getChildByTag(100)));
		ModuleBianlun.RegisterNotificationActionFinishedEvent(ModuleBianlun.handCardListWidgetContainer["Self"]:getChildByTag(100) );

		print("通知中心 -- 注册对方卷轴动画 -- "..tostring(ModuleBianlun.handCardListWidgetContainer["Other"]:getChildByTag(100)));
		ModuleBianlun.RegisterNotificationActionFinishedEvent(ModuleBianlun.handCardListWidgetContainer["Other"]:getChildByTag(100));
	end


end


function ModuleBianlun.ShowPlayerSkillInfo( bSelf, index )
	-- body

	local 	clientLogic 	= CModuleBianlunClientLogic:sharedClientLogic();
	local 	skill 			= nil;

	if 		bSelf == true	then

			clientLogic:network_client_notifyCheckSkillInfo(true, index);
	else
			clientLogic:network_client_notifyCheckSkillInfo(false, index);
	end
end


function ModuleBianlun.OperationCallback( tag, sender )
	-- body
	local 	clientLogic = CModuleBianlunClientLogic:sharedClientLogic();

	if 		tag == ModuleBianlunConfiguration.tag_module_bianlun_yincang 	then
			
			ModuleBianlun.Log("@Operation 隐藏");
			ModuleBianlun.logic_displayHandCards = false;
			ModuleBianlun.ShowPlayerWidgets(false);
			



	elseif	tag == ModuleBianlunConfiguration.tag_module_bianlun_taopao 	then
			ModuleBianlun.Log("@Operation 逃跑");

			clientLogic:network_client_notifyPlayerLeave();

	elseif 	tag == ModuleBianlunConfiguration.tag_module_bianlun_jiasu 		then
			
			ModuleBianlun.Log("@Operation 加速");

--			clientLogic:network_client_notifyPlayerOutputCard();

			clientLogic:network_client_notifyPlayerAccelerate();

	elseif 	tag == ModuleBianlunConfiguration.tag_module_bianlun_xianshi 	then

			ModuleBianlun.Log("@Operation 显示");
			ModuleBianlun.logic_displayHandCards = true;
			ModuleBianlun.ShowPlayerWidgets(true);
			


	elseif	tag == ModuleBianlunConfiguration.tag_module_bianlun_self_firstskill 	then
			ModuleBianlun.Log("@Operation Self 技能一")

--			clientLogic:network_client_notifyUsingSkill(1);
			
			ModuleBianlun.ShowPlayerSkillInfo(true, 1);
			
	elseif 	tag == ModuleBianlunConfiguration.tag_module_bianlun_self_secondskill 	then
			ModuleBianlun.Log("@Operation Self 技能二")

--			clientLogic:network_client_notifyUsingSkill(2);

			ModuleBianlun.ShowPlayerSkillInfo(true, 2);

	elseif 	tag == ModuleBianlunConfiguration.tag_module_bianlun_other_firstskill 	then
			--	对方第一技能信息查看
			ModuleBianlun.Log("@Operation Other 技能一")

			ModuleBianlun.ShowPlayerSkillInfo(false, 1);

	elseif 	tag == ModuleBianlunConfiguration.tag_module_bianlun_other_secondskill 	then
			--	对方第二技能信息查看
			ModuleBianlun.Log("@Operation Other 技能二")

			ModuleBianlun.ShowPlayerSkillInfo(false, 2);
	end
end

function ModuleBianlun.CreateOperation( ... )
	-- body
	if  	ModuleBianlun.mainLayer == nil	 then
			ModuleBianlun.Log("@Error: mainLayer Not Availiable while in  ModuleBianlun.CreateOperation()");
			return;
	end

	if  	ModuleBianlun.operationWidgets.create == nil	 then
			ModuleBianlun.operationWidgets.create = true;

			local  container = cc.Menu:create();
			container:setPosition( 0, 0);

			local  operation = {"隐藏", "加速", "逃跑", };

			for v in pairs(operation) do 
				ModuleBianlun.operationWidgets[operation[v]] = cc.MenuItemImage:create();
				ModuleBianlun.operationWidgets[operation[v]]:setNormalSpriteFrame	(	ModuleBianlun.GetSpriteFrame(ModuleBianlunConfiguration.button[operation[v]]["Normal"]	));
				ModuleBianlun.operationWidgets[operation[v]]:setSelectedSpriteFrame	(	ModuleBianlun.GetSpriteFrame(ModuleBianlunConfiguration.button[operation[v]]["Clicked"]	));
				ModuleBianlun.operationWidgets[operation[v]]:setPosition			(	AAP_X( ModuleBianlunConfiguration.position_operation_pox_x[operation[v]] ), AAP_Y( ModuleBianlunConfiguration.position_operation_pos_y[operation[v]] ) );
			end

			--	显示按钮
			ModuleBianlun.operationWidgets["显示"] =  cc.MenuItemImage:create();
			ModuleBianlun.operationWidgets["显示"]:setNormalSpriteFrame 	(ModuleBianlun.GetSpriteFrame(ModuleBianlunConfiguration.button["显示"]["Normal"] ));
			ModuleBianlun.operationWidgets["显示"]:setSelectedSpriteFrame 	(ModuleBianlun.GetSpriteFrame(ModuleBianlunConfiguration.button["显示"]["Clicked"]));
			ModuleBianlun.operationWidgets["显示"]:setPosition(	AAP_X( ModuleBianlunConfiguration.position_operation_pox_x["隐藏"] ), AAP_Y( ModuleBianlunConfiguration.position_operation_pos_y["隐藏"] ) );


			tolua.cast( ModuleBianlun.operationWidgets["隐藏"], "Node"):registerScriptTapHandler(ModuleBianlun.OperationCallback);
			tolua.cast( ModuleBianlun.operationWidgets["逃跑"], "Node"):registerScriptTapHandler(ModuleBianlun.OperationCallback);
			tolua.cast( ModuleBianlun.operationWidgets["加速"], "Node"):registerScriptTapHandler(ModuleBianlun.OperationCallback);
			tolua.cast( ModuleBianlun.operationWidgets["显示"], "Node"):registerScriptTapHandler(ModuleBianlun.OperationCallback);

			container:addChild(ModuleBianlun.operationWidgets["隐藏"], 0, ModuleBianlunConfiguration.tag_module_bianlun_yincang);
			container:addChild(ModuleBianlun.operationWidgets["逃跑"], 0, ModuleBianlunConfiguration.tag_module_bianlun_taopao)
			container:addChild(ModuleBianlun.operationWidgets["加速"], 0, ModuleBianlunConfiguration.tag_module_bianlun_jiasu);
			container:addChild(ModuleBianlun.operationWidgets["显示"], 0, ModuleBianlunConfiguration.tag_module_bianlun_xianshi);


			--		Button Display Control
			if 		ModuleBianlun.logic_displayHandCards 	== true then
					ModuleBianlun.operationWidgets["显示"]:setVisible(false);
					ModuleBianlun.operationWidgets["隐藏"]:setVisible(true);
			else
					ModuleBianlun.operationWidgets["显示"]:setVisible(true);
					ModuleBianlun.operationWidgets["隐藏"]:setVisible(false);				
			end


			ModuleBianlun.mainLayer:addChild(container);
	end
end

function ModuleBianlun.CreateSkill( ... )
	-- body

	if 		ModuleBianlun.mainLayer == nil then
			ModuleBianlun.Log("@Error: mainLayer Not Availiable while in ModuleBianlun.CreateSkill()");
			return;
	end

	if 		ModuleBianlun.skillWidgets.create == nil then

			ModuleBianlun.skillWidgets.create = true;

			local   	container = cc.Menu:create();
			container:setPosition(0, 0);

--print("Skill Back!");

			ModuleBianlun.skillWidgets["Self"].firstSkill ["back"] = cc.Sprite:create();
			ModuleBianlun.skillWidgets["Self"].secondSkill["back"] = cc.Sprite:create();
			ModuleBianlun.skillWidgets["Other"].firstSkill ["back"] = cc.Sprite:create();
			ModuleBianlun.skillWidgets["Other"].secondSkill["back"] = cc.Sprite:create();

			ModuleBianlun.skillWidgets["Self"].firstSkill ["back"]:setDisplayFrame(ModuleBianlun.GetSpriteFrame(ModuleBianlunConfiguration.skill[1]));
			ModuleBianlun.skillWidgets["Self"].secondSkill["back"]:setDisplayFrame(ModuleBianlun.GetSpriteFrame(ModuleBianlunConfiguration.skill[2]));
			ModuleBianlun.skillWidgets["Other"].firstSkill ["back"]:setDisplayFrame(ModuleBianlun.GetSpriteFrame(ModuleBianlunConfiguration.skill[1]));
			ModuleBianlun.skillWidgets["Other"].secondSkill["back"]:setDisplayFrame(ModuleBianlun.GetSpriteFrame(ModuleBianlunConfiguration.skill[2]));

			ModuleBianlun.skillWidgets["Self"].firstSkill ["back"]:setPosition( AAP_X( ModuleBianlunConfiguration.position_skill["Self"][1].x ), AAP_Y( ModuleBianlunConfiguration.position_skill["Self"][1].y ) );
			ModuleBianlun.skillWidgets["Self"].secondSkill["back"]:setPosition( AAP_X( ModuleBianlunConfiguration.position_skill["Self"][2].x ), AAP_Y( ModuleBianlunConfiguration.position_skill["Self"][2].y ) );
			ModuleBianlun.skillWidgets["Other"].firstSkill ["back"]:setPosition( AAP_X( ModuleBianlunConfiguration.position_skill["Other"][1].x ), AAP_Y( ModuleBianlunConfiguration.position_skill["Other"][1].y ) );
			ModuleBianlun.skillWidgets["Other"].secondSkill["back"]:setPosition( AAP_X( ModuleBianlunConfiguration.position_skill["Other"][2].x ), AAP_Y( ModuleBianlunConfiguration.position_skill["Other"][2].y ) );

--print("Skill Label!");

			local 	label1 = cc.LabelTTF:create("技能", ModuleBianlunConfiguration.skillFontName, ModuleBianlunConfiguration.skillFontSize);	label1:setColor(cc.c3b(251, 252, 207));
			ModuleBianlun.skillWidgets["Self"].firstSkill["label"] = cc.MenuItemLabel:create(label1);

			local 	label2 = cc.LabelTTF:create("技能", ModuleBianlunConfiguration.skillFontName, ModuleBianlunConfiguration.skillFontSize);	label2:setColor(cc.c3b(251, 252, 207));
			ModuleBianlun.skillWidgets["Self"].secondSkill["label"] = cc.MenuItemLabel:create(label2);

			local 	label3 = cc.LabelTTF:create("技能3", ModuleBianlunConfiguration.skillFontName, ModuleBianlunConfiguration.skillFontSize);	label3:setColor(cc.c3b(251, 252, 207));
			ModuleBianlun.skillWidgets["Other"].firstSkill["label"] = cc.MenuItemLabel:create(label3);

			local 	label4 = cc.LabelTTF:create("技能4", ModuleBianlunConfiguration.skillFontName, ModuleBianlunConfiguration.skillFontSize);	label4:setColor(cc.c3b(251, 252, 207));
			ModuleBianlun.skillWidgets["Other"].secondSkill["label"] = cc.MenuItemLabel:create(label4);

			ModuleBianlun.skillWidgets["Self"].firstSkill ["label"]:setPosition( AAP_X( ModuleBianlunConfiguration.position_skill["Self"][1].x ), AAP_Y( ModuleBianlunConfiguration.position_skill["Self"][1].y ) );
			ModuleBianlun.skillWidgets["Self"].secondSkill["label"]:setPosition( AAP_X( ModuleBianlunConfiguration.position_skill["Self"][2].x ), AAP_Y( ModuleBianlunConfiguration.position_skill["Self"][2].y ) );
			ModuleBianlun.skillWidgets["Other"].firstSkill ["label"]:setPosition( AAP_X( ModuleBianlunConfiguration.position_skill["Other"][1].x ), AAP_Y( ModuleBianlunConfiguration.position_skill["Other"][1].y ) );
			ModuleBianlun.skillWidgets["Other"].secondSkill["label"]:setPosition( AAP_X( ModuleBianlunConfiguration.position_skill["Other"][2].x ), AAP_Y( ModuleBianlunConfiguration.position_skill["Other"][2].y ) );

			--	Hide All Skill Widgets
--			
			ModuleBianlun.skillWidgets["Self"].firstSkill ["back"] :setVisible(false);
			ModuleBianlun.skillWidgets["Self"].secondSkill["back"] :setVisible(false);
			ModuleBianlun.skillWidgets["Self"].firstSkill ["label"]:setVisible(false);
			ModuleBianlun.skillWidgets["Self"].secondSkill["label"]:setVisible(false);

			ModuleBianlun.skillWidgets["Other"].firstSkill ["back"] :setVisible(false);
			ModuleBianlun.skillWidgets["Other"].secondSkill["back"] :setVisible(false);
			ModuleBianlun.skillWidgets["Other"].firstSkill ["label"]:setVisible(false);
			ModuleBianlun.skillWidgets["Other"].secondSkill["label"]:setVisible(false);
--]]

			ModuleBianlun.skillWidgets["Self"].firstSkill ["label"]:registerScriptTapHandler(ModuleBianlun.OperationCallback);
			ModuleBianlun.skillWidgets["Self"].secondSkill["label"]:registerScriptTapHandler(ModuleBianlun.OperationCallback);	
			ModuleBianlun.skillWidgets["Other"].firstSkill ["label"]:registerScriptTapHandler(ModuleBianlun.OperationCallback);
			ModuleBianlun.skillWidgets["Other"].secondSkill["label"]:registerScriptTapHandler(ModuleBianlun.OperationCallback);							

			ModuleBianlun.mainLayer:addChild(ModuleBianlun.skillWidgets["Self"].firstSkill ["back"]);
			ModuleBianlun.mainLayer:addChild(ModuleBianlun.skillWidgets["Self"].secondSkill["back"]);
			ModuleBianlun.mainLayer:addChild(ModuleBianlun.skillWidgets["Other"].firstSkill ["back"]);
			ModuleBianlun.mainLayer:addChild(ModuleBianlun.skillWidgets["Other"].secondSkill["back"]);			

			container:addChild(ModuleBianlun.skillWidgets["Self"].firstSkill ["label"], 0, ModuleBianlunConfiguration.tag_module_bianlun_self_firstskill);
			container:addChild(ModuleBianlun.skillWidgets["Self"].secondSkill["label"], 0, ModuleBianlunConfiguration.tag_module_bianlun_self_secondskill);
			container:addChild(ModuleBianlun.skillWidgets["Other"].firstSkill ["label"], 0, ModuleBianlunConfiguration.tag_module_bianlun_other_firstskill);
			container:addChild(ModuleBianlun.skillWidgets["Other"].secondSkill["label"], 0, ModuleBianlunConfiguration.tag_module_bianlun_other_secondskill);			

--print("Done!");

			ModuleBianlun.mainLayer:addChild(container, 100);
	end
end

function ModuleBianlun.RecordSkillCount( pos, count )
	-- body
	local 	clientLogic = CModuleBianlunClientLogic:sharedClientLogic();
	local 	index 		= nil;
	if 		pos 	== clientLogic:getServerPosition() then
			index 		= "Self";
	else
			index 		= "Other";
	end

	if 		count == 0 then
			ModuleBianlun.skillWidgets[index].firstSkill["back"]	:setVisible(false);
			ModuleBianlun.skillWidgets[index].firstSkill["label"]	:setVisible(false);	

			ModuleBianlun.skillWidgets[index].secondSkill["back"]	:setVisible(false);
			ModuleBianlun.skillWidgets[index].secondSkill["label"]	:setVisible(false);	
	elseif 	count == 1 then	
			ModuleBianlun.skillWidgets[index].firstSkill["back"]	:setVisible(true);
			ModuleBianlun.skillWidgets[index].firstSkill["label"]	:setVisible(true);	

			ModuleBianlun.skillWidgets[index].secondSkill["back"]	:setVisible(false);
			ModuleBianlun.skillWidgets[index].secondSkill["label"]	:setVisible(false);			
	elseif	count == 2 then
			ModuleBianlun.skillWidgets[index].firstSkill["back"]	:setVisible(true);
			ModuleBianlun.skillWidgets[index].firstSkill["label"]	:setVisible(true);	

			ModuleBianlun.skillWidgets[index].secondSkill["back"]	:setVisible(true);
			ModuleBianlun.skillWidgets[index].secondSkill["label"]	:setVisible(true);		
	else
			ModuleBianlun.Log("Error@Lua, Invalid Skill Count!");
	end

--[[
	--	新英雄
	--	清理双发手牌位置控件

	ModuleBianlun.handCardBackWidget["Self"] 	= {};
	ModuleBianlun.handCardBackWidget["Other"] 	= {};
--]]
end

function ModuleBianlun.VerticalString( msg )
	-- body

	local 	length = string.len(msg);

	ModuleBianlun.Log(tostring(length));

	local 	result = "";

	ModuleBianlun.Log(tostring(string.sub(msg, 1, 3)));
	ModuleBianlun.Log(tostring(string.sub(msg, 4, 3)));


	for 	i = 1, length, 3 do
			local  character = string.sub(msg, i, 3);

			ModuleBianlun.Log(tostring(character));

--			result = result..character.."\n"; 

	end

	ModuleBianlun.Log(result);
	return result;

end

function ModuleBianlun.UpdateSkill( pos, index, skillName )
	-- body

	if 	ModuleBianlun.mainLayer == nil then
		ModuleBianlun.Log("Error@Lua, MainLayer Not Availiable while in ModuleBianlun.UpdateSkill()");
		return;
	end

	if 	ModuleBianlun.skillWidgets.create == nil then
		ModuleBianlun.Log("Error@Lua, Skill Widgets Not Availiable while in ModuleBianlun.UpdateSkill()");
		return;
	end

	local 	clientLogic = CModuleBianlunClientLogic:sharedClientLogic();
	ModuleBianlun.Log("更新技能:"..tostring(index)..tostring(skillName));

	local 	type 	= nil;
	if 		pos 	== clientLogic:getServerPosition() then
			type 	= "Self";
	else
			type 	= "Other";
	end


	if 	index <= 1 then
		--	First Skill
		if 	skillName == "" then
			ModuleBianlun.skillWidgets[type].firstSkill["back"]		:setVisible(false);
			ModuleBianlun.skillWidgets[type].firstSkill["label"]	:setVisible(false);			
		else
			ModuleBianlun.skillWidgets[type].firstSkill["back"]		:setVisible(true);
			ModuleBianlun.skillWidgets[type].firstSkill["label"]	:setVisible(true);	

			tolua.cast( ModuleBianlun.skillWidgets[type].firstSkill["label"]:getLabel(), "LabelTTF"):setString(skillName);
		end
	else
		--	Second Skill
		if 	skillName == "" then
			ModuleBianlun.skillWidgets[type].secondSkill["back"]	:setVisible(false);
			ModuleBianlun.skillWidgets[type].secondSkill["label"]	:setVisible(false);			
		else
			ModuleBianlun.skillWidgets[type].secondSkill["back"]	:setVisible(true);
			ModuleBianlun.skillWidgets[type].secondSkill["label"]	:setVisible(true);	

			tolua.cast( ModuleBianlun.skillWidgets[type].secondSkill["label"]:getLabel(), "LabelTTF"):setString(skillName);	--ModuleBianlun.VerticalString(skillName)	
		end
	end
end


function ModuleBianlun.ActiveSkill( index )
	-- body

	if 	ModuleBianlun.mainLayer == nil then
		ModuleBianlun.Log("Error@Lua, MainLayer Not Availiable while in ModuleBianlun.ActiveSkill()");
		return;
	end

	if 	ModuleBianlun.skillWidgets.create == nil then
		ModuleBianlun.Log("Error@Lua, SkillWidget Not Availiable while in ModuleBianlun.ActiveSkill()");
		return;
	end

	local 	action 	= cc.RotateBy:create(0.5, 360);

	if 	index <= 1 then
		ModuleBianlun.skillWidgets["Self"].firstSkill["label"]:runAction(action);
	else
		ModuleBianlun.skillWidgets["Self"].secondSkill["label"]:runAction(action);
	end

end




-------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--	Module Exported Interface

--	Helper Function
function ModuleBianlun.PreCreatemainLayer( ... )
	-- body

	ModuleBianlun.mainLayer 	= nil;
	ModuleBianlun.background 	= nil;

	ModuleBianlun.playerWidgets.create 		= nil;
	ModuleBianlun.operationWidgets.create 	= nil;

	ModuleBianlun.skillWidgets.create 		= nil;
	ModuleBianlun.outputCardWidget.create 	= nil;

	ModuleBianlun.lunboWidget.create  		= nil;

	ModuleBianlun.handCardListWidget.create  	= nil;
	ModuleBianlun.outputCardListWidget.create 	= nil;

	ModuleBianlun.xianhouWidgets.create 	= nil;

	ModuleBianlun.tipMessageWidget = nil;
	ModuleBianlun.tipMessageHandle = nil;

	ModuleBianlun.handCardBackWidget ["Self"]	= {};
	ModuleBianlun.handCardBackWidget ["Other"]	= {};


	ModuleBianlun.logic_bxianshou			= nil;
	ModuleBianlun.logic_selfPlayerId		= nil;
	ModuleBianlun.logic_selfPlayerName 		= nil;
	ModuleBianlun.logic_otherPlayerId		= nil;
	ModuleBianlun.logic_otherPlayerName		= nil;

	ModuleBianlun.centerAnimationWidgets = nil;

	--------------------------------------------------
	--	Notification Center 
	notificationEventRegistry 	= {};


	--------------------------------------------------
	logic_displayHandCards 	= true;


	--------------------------------------------------
	--	结算配置信息
	playerList 		= {};
	award_exp 		= nil;
	award_gongxun 	= nil;
	award_bingli 	= nil;
	award_liang 	= nil;
	award_tili 		= nil;
	award_daoju 	= {};

--	bEncounter 		= false;


	local 	clientLogic = CModuleBianlunClientLogic:sharedClientLogic();
	clientLogic:resetClientLogicContext();

end

function ModuleBianlun.CreatemainLayer( ... )
	-- body
	
	ModuleBianlun.LoadResource();

	--	mainLayer
	if  ModuleBianlun.mainLayer == nil	 then
		ModuleBianlun.mainLayer =  cc.Layer:create();
	end

	--	background
	ModuleBianlun.CreateBackground();

	--	tip message
	ModuleBianlun.CreateTipMessage();

	--	PlayerWidget
	ModuleBianlun.CreatePlayerWidgets();

	--	Operation
	ModuleBianlun.CreateOperation();
	--	Skill
	ModuleBianlun.CreateSkill();	

	--	XianHou 
	ModuleBianlun.CreateXianhouWidget();	

	--	Lunbo
	ModuleBianlun.CreateLunboWidgets();

	--	手中牌及位置集合
	ModuleBianlun.CreatePlayerHandCardListWidgetUnion();

	--	HandcardList
	ModuleBianlun.CreateHandCardListWidget();

	--	OutputCardList
	ModuleBianlun.CreateOutputCardListWidget();
--]]

	return ModuleBianlun.mainLayer;
end


----------------------------------------------------------------------------------------------------------------------------
--	BUG Fix

function ModuleBianlun.RegisterNotificationEvent( object, event )
	-- body

	print("##辩论模块 -- 注册"..tostring(object)..tostring(event));

	ModuleBianlun.notificationEventRegistry [tostring(object)] = {["Object"] = object, ["Event"] = event, };
	CNotificationCenterExporter:getInstance():registerScriptObserver(object, ModuleBianlun.NotificationHandler, event);
end

function ModuleBianlun.RegisterNotificationActionFinishedEvent( object )
	-- body
	ModuleBianlun.RegisterNotificationEvent(object, "ActionFinishedEvent");
end

function ModuleBianlun.UnregisterNotificationEvent( object, event )
	-- body

	print("##辩论模块 -- 解除注册"..tostring(object)..tostring(event));


	CNotificationCenterExporter:getInstance():unregisterScriptObserver( tolua.cast(object, "Object"), event);


end

function ModuleBianlun.UnregisterModuleBianlunNotificationEvent( ... )
	-- body
	for 	v in pairs(ModuleBianlun.notificationEventRegistry) do 
			ModuleBianlun.UnregisterNotificationEvent(ModuleBianlun.notificationEventRegistry[v]["Object"], ModuleBianlun.notificationEventRegistry[v]["Event"]);
	end

	ModuleBianlun.notificationEventRegistry = {};
end


function ModuleBianlun.LoadResource( ... )
	-- body

	local 	spriteFrameCache 	= cc.SpriteFrameCache:getInstance();

--	spriteFrameCache:addSpriteFrames( 	"Bianlun/UI/ui-head.plist");
--	spriteFrameCache:addSpriteFrames(	"Bianlun/UI/ui-modulebianlun.plist");
--	spriteFrameCache:addSpriteFrames(	"Bianlun/UI/ui-result.plist");
	spriteFrameCache:addSpriteFrames(	"Bianlun/UI/ui-modulebianlun-new.plist");

	spriteFrameCache:addSpriteFrames(	"Bianlun/Animation/xianhou.plist");
--	spriteFrameCache:addSpriteFrames(	"Bianlun/Animation/commonskill_shine.plist");
	spriteFrameCache:addSpriteFrames(	"Bianlun/Animation/animation_juanzhouother.plist");
	spriteFrameCache:addSpriteFrames(	"Bianlun/Animation/animation_juanzhouself.plist");
	spriteFrameCache:addSpriteFrames(	"Bianlun/Animation/animation_lunbo.plist");
	spriteFrameCache:addSpriteFrames(	"Bianlun/Animation/animation_juesheng.plist");
	spriteFrameCache:addSpriteFrames(	"Bianlun/Animation/animation_fire.plist");
	spriteFrameCache:addSpriteFrames(	"Bianlun/Animation/animation_output.plist")


	local 	animationCache 		= cc.AnimationCache:getInstance();
	animationCache:addAnimations(	"Bianlun/Animation/animation.plist");


end

function ModuleBianlun.UnloadResource( ... )
	-- body

	local  spriteFrameCache = cc.SpriteFrameCache:getInstance();
--	spriteFrameCache:removeSpriteFramesFromFile(	"Bianlun/UI/ui-head.plist");
--	spriteFrameCache:removeSpriteFramesFromFile(	"Bianlun/UI/ui-modulebianlun.plist");
--	spriteFrameCache:removeSpriteFramesFromFile(	"Bianlun/UI/ui-result.plist");
	spriteFrameCache:removeSpriteFramesFromFile(	"Bianlun/UI/ui-modulebianlun-new.plist");

	spriteFrameCache:removeSpriteFramesFromFile(	"Bianlun/Animation/xianhou.plist");
	spriteFrameCache:removeSpriteFramesFromFile(	"Bianlun/Animation/commonskill_shine.plist");
	spriteFrameCache:removeSpriteFramesFromFile(	"Bianlun/Animation/animation_juanzhouother.plist");
	spriteFrameCache:removeSpriteFramesFromFile(	"Bianlun/Animation/animation_juanzhouself.plist");
	spriteFrameCache:removeSpriteFramesFromFile(	"Bianlun/Animation/animation_lunbo.plist");
	spriteFrameCache:removeSpriteFramesFromFile(	"Bianlun/Animation/animation_juesheng.plist");
	spriteFrameCache:removeSpriteFramesFromFile(	"Bianlun/Animation/animation_fire.plist");
	spriteFrameCache:removeSpriteFramesFromFile(	"Bianlun/Animation/animation_output.plist");

	local 	animationCache 	= cc.AnimationCache:getInstance();
	animationCache:removeAnimation("animation_xianhou_round");
	animationCache:removeAnimation("animation_xianhou_turn");
	animationCache:removeAnimation("animation_juanzhouself");
	animationCache:removeAnimation("animation_juanzhouother");
	animationCache:removeAnimation("animation_lunbo");
	animationCache:removeAnimation("animation_juesheng");
	animationCache:removeAnimation("animation_fire")
	animationCache:removeAnimation("animation_output");


	local 	textureCache 	= cc.TextureCache:getInstance();
	textureCache:removeUnusedTextures();


	ModuleBianlunSound.UnloadAllEffect();

end

----------------------------------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------------------------

--	Intergrate Interface

function ModuleBianlun.PreCreateModuleBianlun( ... )
	-- body

	ModuleBianlunServerLogic.PreStartServerLogic();
end

function ModuleBianlun.SetPlayerInfo( pos, index, name )
	-- body
	local 	id 	= ModuleBianlunSkill.GetHeroInfo(name, "ID");

	ModuleBianlunServerLogic.SetPlayerInfo(pos, id, name);
end

function ModuleBianlun.SetChallenger( pos )
	-- body

	ModuleBianlunServerLogic.SetChallenger(pos);
end

function ModuleBianlun.SetEncounterFlag( bEncounter )
	-- body
	ModuleBianlun.bEncounter = bEncounter;
end

function ModuleBianlun.CreateModuleBianlun(  )
	-- body
	
	ModuleBianlun.PreCreatemainLayer();
	
	local   bianlunLayer = nil;
	bianlunLayer = ModuleBianlun.CreatemainLayer();


	ModuleBianlunSound.PlayBackgroundMusic();

	local   bianlunScene = cc.Scene:create();
	bianlunScene:addChild(bianlunLayer);


	ModuleBianlunServerLogic.StartServerLogic();

	return bianlunScene;
end

function ModuleBianlun.PreLeaveModuleBianlun( ... )
	-- body

--[[

	local  spriteFrameCache = cc.SpriteFrameCache:getInstance();
	spriteFrameCache:removeSpriteFramesFromFile("Bianlun/UI/ui-head.plist");

	spriteFrameCache:removeSpriteFramesFromFile("Bianlun/UI/ui-modulebianlun.plist");
	
	spriteFrameCache:removeSpriteFramesFromFile("Bianlun/Animation/xianhou.plist");

	local 	animationCache 	= cc.AnimationCache:getInstance();
--	animationCache:addAnimations("Bianlun/Animation/animation.plist");
	animationCache:removeAnimation("animation_xianhou_round");

--]]

	ModuleBianlun.UnloadResource();

	--	Notification Module Clean
	ModuleBianlun.UnregisterModuleBianlunNotificationEvent();
end

----------------------------------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------------------------


function ModuleBianlun.CreateModuleBianlunInterface( playerlist1, playerlist2, nChallenger, bEncounter )
	-- body

	if 	type(playerlist1) ~= "table" or type(playerlist2) ~= "table" then
		ModuleBianlun.Log("Error@Script, both side should be table containing PlayerList");
		return;
	end

	bEncounter = bEncounter or false;

	ModuleBianlun.PreCreateModuleBianlun();

	ModuleBianlun.bEncounter 	= bEncounter;

	for 	v in pairs(playerlist1) do 
			ModuleBianlun.SetPlayerInfo(0, 0, playerlist1[v]);
	end

	for 	v in pairs(playerlist2) do 
			ModuleBianlun.SetPlayerInfo(1, 0, playerlist2[v]);
	end

	challenger = challenger or  0;

	ModuleBianlun.SetChallenger(challenger);

	cc.Director:getInstance():pushScene(ModuleBianlun.CreateModuleBianlun());
end