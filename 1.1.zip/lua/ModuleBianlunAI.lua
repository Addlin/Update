ModuleBianlunAI = {};

----------------------------------------------------------------------
--	等级获取接口
function ModuleBianlunAI.GetPlayerLevel( ... )
	-- body
	return 100;
end


----------------------------------------------------------------------
--	概率结果
function ModuleBianlunAI.GetProbabilityType( probabilities )
	-- body

	local 	count 	= #probabilities;
	math.randomseed(os.time());

	for 	v in pairs(probabilities) do

			if 	v > 1 then
				probabilities[v] 	= probabilities[v] + probabilities[v - 1];
			end
	end

	local 	size 	= 10000;

	local 	random 	= math.random(1, size);

	print(random);

	for 	v in pairs(probabilities) do
			if 	random <= size * (probabilities[v]) then
				return 	v;
			end
	end
	return 	#probabilities;
end


function ModuleBianlunAI.HandleSkillTrigger( pos )
	-- body
	print("判定是否发动英雄技能");
	local 	serverLogic 		= CModuleBianlunServerLogic:sharedServerLogic();
	local  	level 				= ModuleBianlunAI.GetPlayerLevel();
	local 	triggerProbability 	= 0.3;
	if 		level > 30 then
			triggerProbability 	= triggerProbability + (level - 30)/100;
	end	
	local 	probabilities 		= {triggerProbability, 1 - triggerProbability};
	local 	type 			= ModuleBianlunAI.GetProbabilityType(probabilities);	print(tostring(type));
	if 		type 	== 1 then
			--	触发英雄主动技能 
			return  true
	else
			return  false;
	end
end

function ModuleBianlunAI.HandlePlayerOutput( pos )
	-- body

	local 	serverLogic 	= CModuleBianlunServerLogic:sharedServerLogic();
	local 	handCardList 	= serverLogic:getPlayerHandCardList(pos);

	local 	lunCard 		= serverLogic:getLunCard();
	local 	boCard 			= serverLogic:getBoCard();

	local 	handCardType 	= algorithm_module_bianlun_gettype(handCardList, lunCard, boCard);

	if 		handCardType 	== 	Type_AllLun 	then
			print("玩家@"..tostring(pos).."手中牌牌型："..tostring("全论牌型"));

			ModuleBianlunAI.HandlePlayerOutput_AllLun(pos);

	elseif 	handCardType 	==	Type_AllBo 		then
			print("玩家@"..tostring(pos).."手中牌牌型："..tostring("全驳牌型"));

			ModuleBianlunAI.HandlePlayerOutput_AllBo(pos);

	elseif 	handCardType 	== 	Type_AllBian 	then
			print("玩家@"..tostring(pos).."手中牌牌型："..tostring("全辩牌型"));

			ModuleBianlunAI.HandlePlayerOutput_AllBian(pos);

	elseif	handCardType 	== 	Type_LunBian 	then
			print("玩家@"..tostring(pos).."手中牌牌型："..tostring("论辩牌型"));

			ModuleBianlunAI.HandlePlayerOutput_LunBian(pos);

	elseif 	handCardType 	== 	Type_LunBo 		then
			print("玩家@"..tostring(pos).."手中牌牌型："..tostring("论驳牌型"));

			ModuleBianlunAI.HandlePlayerOutput_LunBo(pos);

	elseif 	handCardType 	== 	Type_BianBo 	then
			print("玩家@"..tostring(pos).."手中牌牌型："..tostring("辩驳牌型"));

			ModuleBianlunAI.HandlePlayerOutput_BianBo(pos);

	elseif 	handCardType 	== 	Type_LunBoBian	then
			print("玩家@"..tostring(pos).."手中牌牌型："..tostring("论辩驳牌型"));

			ModuleBianlunAI.HandlePlayerOutput_LunBoBian(pos);

	else
			print("Error@ModuleBianlunAI.HandlePlayerOutput, Invalid HandCardType!");
	end
end

function ModuleBianlunAI.Get( ... )
	-- body
end

function ModuleBianlunAI.HandlePlayerOutput_AllLun( pos )
	-- body

	local 	serverLogic 	= CModuleBianlunServerLogic:sharedServerLogic();
	local 	list			= serverLogic:getPlayerHandCardList(pos);
	local 	lunCard 		= serverLogic:getLunCard();
	local 	boCard 			= serverLogic:getBoCard();
	local 	size 			= serverLogic:getPlayerHandCardSize(pos);		

	local 	card 			= nil;
	local 	bFinded 		= false;
	local 	backCard 		= nil;



	if 		size 	== 1 	then
			--	只有一张牌
			card 	= serverLogic:getPlayerHandCard(pos, 0);
			serverLogic:appendPlayerOutputCard(pos, card);
	else

			local 	probabilities 	= {0.6, 0.4};		--	同色 异色

			local 	type 	= ModuleBianlunAI.GetProbabilityType(probabilities);		print(tostring(type));
			if 		type 	== 1 then
					for 	i = 1, size do 
							card = serverLogic:getPlayerHandCard(pos, i - 1);
							backCard = card;
							if 		card:getType() == lunCard:getType() then
									bFinded = true;
									do break end
							end
					end
					if 	bFinded  == true then
						serverLogic:appendPlayerOutputCard(pos, card);
					end
			else
					for 	i = 1, size do
							card = serverLogic:getPlayerHandCard(pos, i - 1);
							backCard 	= card;
							if 		card:getType() == lunCard:getType() then
									bFinded = true;
									do break end
							end
					end
					if 	bFinded == true then
						serverLogic:appendPlayerOutputCard(pos, card);
					end
			end

			print(tostring(bFinded));	print(backCard:dumpCard());

			if 	bFinded == false then
				serverLogic:appendPlayerOutputCard(pos, backCard);
			end
	end
end

function ModuleBianlunAI.HandlePlayerOutput_AllBo( pos )
	-- body

	local 	serverLogic 	= CModuleBianlunServerLogic:sharedServerLogic();
	local 	list			= serverLogic:getPlayerHandCardList(pos);
	local 	lunCard 		= serverLogic:getLunCard();
	local 	boCard 			= serverLogic:getBoCard();
	local 	size 			= serverLogic:getPlayerHandCardSize(pos);

	local 	card 			= nil;
	local 	bFinded 		= false;
	local 	backCard 		= nil;

	if 		size 	== 1 	then
			--	只有一张牌
			card 	= serverLogic:getPlayerHandCard(pos, 0);
			serverLogic:appendPlayerOutputCard(pos, card);
	else

			local 	probabilities 	= {0.4, 0.6};		--	同色 异色

			local 	type 	= ModuleBianlunAI.GetProbabilityType(probabilities);
			if 		type 	== 1 then
					for 	i = 1, size do 
							card = serverLogic:getPlayerHandCard(pos, i - 1);
							backCard = card;
							if 		card:getType() == boCard:getType() then
									bFinded  = true;
									do break end
							end
					end
					if 	bFinded == true then
						serverLogic:appendPlayerOutputCard(pos, card);
					end
			else
					for 	i = 1, size do
							card = serverLogic:getPlayerHandCard(pos, i - 1);
							backCard = card;
							if 		card:getType() == boCard:getType() then
									bFinded = true;
									do break end
							end
					end
					if 	bFinded == true then
						serverLogic:appendPlayerOutputCard(pos, card);
					end
			end
			if 	bFinded == false then
				print("未找到特定颜色的驳牌");
				serverLogic:appendPlayerOutputCard(pos, backCard);
			end
	end	
end

function ModuleBianlunAI.HandlePlayerOutput_AllBian( pos )
	-- body

	local 	serverLogic 	= CModuleBianlunServerLogic:sharedServerLogic();
	local 	list			= serverLogic:getPlayerHandCardList(pos);
	local 	lunCard 		= serverLogic:getLunCard();
	local 	boCard 			= serverLogic:getBoCard();
	local 	size 			= serverLogic:getPlayerHandCardSize(pos);

	local 	card 			= nil;
	local 	bFinded 		= false;
	local 	backCard 		= nil;

	print("手中牌数量:"..tostring(size));

	if 		size 	== 1 	then
			--	只有一张牌
			card 	= serverLogic:getPlayerHandCard(pos, 0);
			serverLogic:appendPlayerOutputCard(pos, card);
	else

			local 	probabilities 	= {0.5, 0.5};		--	同色 异色

			local 	type 	= ModuleBianlunAI.GetProbabilityType(probabilities); 		print(tostring(type));
			if 		type 	== 1 then
					for 	i = 1, size do 
							card = serverLogic:getPlayerHandCard(pos, i - 1);

							backCard 	= card;

							print(card:dumpCard());
							print(lunCard:dumpCard());
							print(boCard:dumpCard());
							if 		card:getValue() ~= lunCard:getValue() and card:getValue() ~= boCard:getValue() then
									bFinded = true;
									do break end
							end
					end
					if 	bFinded == true then
						print("Finded");
						serverLogic:appendPlayerOutputCard(pos, card);
					end
			else
					for 	i = 1, size do
							card = serverLogic:getPlayerHandCard(pos, i - 1);

							backCard 	= card;

							if 		card:getValue() ~= lunCard:getValue() and card:getValue() ~= boCard:getValue() then
									bFinded = true;
									do break end
							end
					end
					if 	bFinded == true then
						print("Finded");
						serverLogic:appendPlayerOutputCard(pos, card);
					end
			end

			if 	bFinded == false then
				print("未找到特定颜色的辩牌");
				serverLogic:appendPlayerOutputCard(pos, backCard);
			end
	end
end

function ModuleBianlunAI.HandlePlayerOutput_LunBo( pos )
	-- body

	local 	serverLogic 	= CModuleBianlunServerLogic:sharedServerLogic();
	local 	list			= serverLogic:getPlayerHandCardList(pos);
	local 	lunCard 		= serverLogic:getLunCard();
	local 	boCard 			= serverLogic:getBoCard();
	local 	size 			= serverLogic:getPlayerHandCardSize(pos);

	local 	card 			= nil;
	local 	bFinded 		= false;
	local 	backCard 		= nil;

	local 	probabilities 	= {0.55, 0.45};		--	论 驳
	local 	type 			= ModuleBianlunAI.GetProbabilityType(probabilities);

	if 		type 	== 1 then
			print("出论牌")
			probabilities 			= {0.6, 0.4}
			local 	type2 			= ModuleBianlunAI.GetProbabilityType(probabilities);
			for 	i = 1, size do 
					card 	= serverLogic:getPlayerHandCard(pos, i -1);
					if 	card:getValue() == lunCard:getValue()	then

						backCard = card;

						if 	type2 == 1 then
							if 	card:getType() == lunCard:getType() then
								bFinded = true
								do break end
							end
						else
							if 	card:getType() ~= lunCard:getType() then
								bFinded = true
								do break end
							end
						end
					end
			end
			if 	bFinded == false 	then
				serverLogic:appendPlayerOutputCard(pos, card);
			else
				print("未找到特定颜色的论牌");
				serverLogic:appendPlayerOutputCard(pos, backCard);
			end
	else
			print("出驳牌");
			probabilities 			= {0.4, 0.6}
			local 	type2 			= ModuleBianlunAI.GetProbabilityType(probabilities);
			for 	i = 1, size do
					card 	= serverLogic:getPlayerHandCard(pos, i - 1);
					if 	card:getValue() == boCard:getValue() then

						backCard = card

						if	type2 == 1 then
							if 	card:getType() == boCard:getType() 	then
								bFinded = true
								do break end
							end	
						else
							if 	card:getType() ~= boCard:getType() 	then
								bFinded = true
								do break end
							end
						end
					end
			end
			if 	bFinded == true then
				serverLogic:appendPlayerOutputCard(pos, card);
			else
				print("未找到特定颜色的驳牌");
				serverLogic:appendPlayerOutputCard(pos, backCard);
			end
	end
end

function ModuleBianlunAI.HandlePlayerOutput_LunBian( pos )
	-- body
	local 	serverLogic 	= CModuleBianlunServerLogic:sharedServerLogic();
	local 	list			= serverLogic:getPlayerHandCardList(pos);
	local 	lunCard 		= serverLogic:getLunCard();
	local 	boCard 			= serverLogic:getBoCard();
	local 	size 			= serverLogic:getPlayerHandCardSize(pos);

	local 	card 			= nil;
	local 	bFinded 		= false;

	local 	probabilities 	= {0.45, 0.55};		--	论 辩
	local 	type 			= ModuleBianlunAI.GetProbabilityType(probabilities);

	if 		type == 1 then		
			--	论
			print("出论牌");
			local 	backCard= nil;

			probabilities 	= {0.6, 0.4};
			local 	type2 	= ModuleBianlunAI.GetProbabilityType(probabilities);

			for 	i = 1, size do 
					card 	= serverLogic:getPlayerHandCard(pos, i - 1);
					if 	card:getValue() ==lunCard:getValue() then

						backCard = card;

						if 	type2 == 1 then
							if 	card:getType() == lunCard:getType() then
								bFinded = true;
								do break end
							end
						else
							if 	card:getType() ~= lunCard:getType() then
								bFinded = true;
								do break end
							end
						end
					end
			end
			if 	bFinded == true then
				serverLogic:appendPlayerOutputCard(pos, card);
			else
				print("未找到特定颜色的论牌");
				serverLogic:appendPlayerOutputCard(pos, backCard);
			end
	else
			--	辩
			print("出辩牌");
			probabilities 	= {0.5, 0.5};
			local 	backCard = nil;
			local  	typ 		= ModuleBianlunAI.GetProbabilityType(probabilities);
			for 	i = 1, size do
					card 	= serverLogic:getPlayerHandCard(pos, i - 1);
					if 	card:getValue() ~= lunCard:getValue() and card:getValue() ~= boCard:getValue() then

						backCard = card;

						if 	type2 == 1 then
							if 	card:getType() == lunCard:getType() then
								bFinded = true;
								do 	break end
							end
						else
							if 	card:getType() ~= lunCard:getType() then
								bFinded = true;
								do break end
							end
						end
					end
			end
			if bFinded == true then
				serverLogic:appendPlayerOutputCard(pos, card);
			else
				print("未找到特定颜色的辩牌");
				serverLogic:appendPlayerOutputCard(pos, backCard);
			end
	end	
end

function ModuleBianlunAI.HandlePlayerOutput_BianBo( pos )
	-- body

	local 	serverLogic 	= CModuleBianlunServerLogic:sharedServerLogic();
	local 	list			= serverLogic:getPlayerHandCardList(pos);
	local 	lunCard 		= serverLogic:getLunCard();
	local 	boCard 			= serverLogic:getBoCard();
	local 	size 			= serverLogic:getPlayerHandCardSize(pos);

	local 	card 			= nil;
	local 	bFinded 		= false;

	local 	probabilities 	= {0.6, 0.4};		--	 辩 驳
	local 	type 			= ModuleBianlunAI.GetProbabilityType(probabilities);	

	if 		type 	== 1 then
			print("出辩牌");
			local 	backCard= nil;

			probabilities 	= {0.5, 0.5}
			local 	type2 	= ModuleBianlunAI.GetProbabilityType(probabilities);
			for 	i = 1, size do 
					card 	= serverLogic:getPlayerHandCard(pos, i - 1);
					if 	card:getValue() ~= lunCard:getValue() and card:getValue() ~= boCard:getValue() then
						
						backCard = card;

						if 	type2 == 1 then
							if 	card:getType() == lunCard:getType() then
								bFinded = true;
								do break end
							end
						else
							if 	card:getType() ~= lunCard:getType() then
								bFinded = true;
								do break end
							end
						end
					end 
			end
			if 	bFinded == true then
				serverLogic:appendPlayerOutputCard(pos, card);
			else
				print("未找到特定颜色的辩牌");
				serverLogic:appendPlayerOutputCard(pos, backCard);
			end
	else
			print("出驳牌");
			probabilities  = {0.4, 0.6};
			local 	type2  = ModuleBianlunAI.GetProbabilityType(probabilities);
			for 	i = 1, size do
					card   = serverLogic:getPlayerHandCard(pos, i - 1);
					if 	card:getValue() == boCard:getValue() then

						backCard = card;

						if	type2 == 1 then
							if 	card:getType() == boCard:getType() then
								bFinded = true;
								do break end
							end
						else
							if 	card:getType() ~= boCard:getType() then
								bFinded = true;
								do break end
							end
						end
					end
			end
			if 	bFinded == true then
				serverLogic:appendPlayerOutputCard(pos, card);
			else
				print("未找到特定颜色的驳牌");
				serverLogic:appendPlayerOutputCard(pos, backCard);
			end
	end

end

function ModuleBianlunAI.HandlePlayerOutput_LunBoBian( pos )
	-- body

	print("处理论辩驳牌型AI出牌");

	local 	serverLogic 	= CModuleBianlunServerLogic:sharedServerLogic();		
	local 	list			= serverLogic:getPlayerHandCardList(pos);				
	local 	lunCard 		= serverLogic:getLunCard();								
	local 	boCard 			= serverLogic:getBoCard();								
	local 	size 			= serverLogic:getPlayerHandCardSize(pos);				

	local 	card 			= nil;
	local 	bFinded 		= false;

	local 	probabilities 	= {0.33, 0.37, 0.3};		--	论 辩 驳
	local 	type 			= ModuleBianlunAI.GetProbabilityType(probabilities);		
	if 		type 	== 1 then
			print("出论牌");
			probabilities 	= {0.6, 0.4};

			local 	backCard 	= nil;

			local   type2 	= ModuleBianlunAI.GetProbabilityType(probabilities);
			for 	i = 1, size do
					card 	= serverLogic:getPlayerHandCard(pos, i - 1);
					if 	card:getValue () == lunCard:getValue() then

						backCard = card;

						print(card:dumpCard());
						print(lunCard:dumpCard());

						if	 type2 == 1 then
							if 	card:getType() == lunCard:getType() then
								bFinded = true;
								do break end
							end
						else
							if 	card:getType() ~= lunCard:getValue() then
								bFinded = true;
								do break end
							end
						end
					end
			end
			if 	bFinded then
				serverLogic:appendPlayerOutputCard(pos, card);
			else
				print("未找到特定颜色的论牌");
				serverLogic:appendPlayerOutputCard(pos, backCard);
			end
	elseif 	type  	== 2 then
			print("出辩牌");

			local 	backCard 	= nil;

			probabilities 	= {0.5, 0.5};
			local 	type2 	= ModuleBianlunAI.GetProbabilityType(probabilities);
			for 	i = 1, size do 
					card 	= serverLogic:getPlayerHandCard(pos, i - 1);
					if 	card:getValue() ~= lunCard:getValue() and card:getValue() ~= boCard:getValue() then

						backCard = card;

						if 	type2 == 1 then
							if 	card:getType() == lunCard:getType() then
								bFinded 	= true;
								do 	break end
							end
						else
							if	card:getType() ~= lunCard:getType() then
								bFinded = true;
								do  break end
							end
						end
					end
			end
			if 	bFinded == true then
				serverLogic:appendPlayerOutputCard(pos, card);
			else
				print("未找到特定颜色的辩牌");
				serverLogic:appendPlayerOutputCard(pos, backCard);
			end
	else
			print("出驳牌");
			probabilities 	= {0.4, 0.6};

			local  backCard 	= nil;

			local 	type2 	= ModuleBianlunAI.GetProbabilityType(probabilities);
			for 	i  =1 , size do
					card 	= serverLogic:getPlayerHandCard(pos, i - 1);
					if 	card:getValue() == boCard:getValue() then

						backCard = card;

						if 	type2 == 1 then
							if 	card:getType() == boCard:getType() then
								bFinded = 	true;
								do break end
							end
						else
							if 	card:getType() ~= boCard:getType() then
								bFinded =	true;
								do break end
							end
						end
					end
			end
			if 	bFinded == true then
				serverLogic:appendPlayerOutputCard(pos, card);
			else
				print("未找到特定颜色的驳牌");
				serverLogic:appendPlayerOutputCard(pos, backCard);
			end
	end
end