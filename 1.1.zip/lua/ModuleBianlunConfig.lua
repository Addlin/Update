--	Date	: 2013/10/31
--	Author	: zhaozl
--	Brief	: Module Bianlun's UI Configuration


local   ModuleBianlunUIImageFileExtension = ".png";
--	Table Module Bianlun Configuration
ModuleBianlunConfiguration = {

	--	Scene Config
	sceneWidth			=	960;
	sceneHeight 		= 	640;

	--	Background
	background  		= 	"ArgumentScene_bg.jpg";
	backgroundframe 	= 	"kuangnew.png";

--[[
	--	Background Frame
	frame 				= {
		["TopLeft"] 	= "J_01"..ModuleBianlunUIImageFileExtension;
		["BottomLeft"]	= "J_02"..ModuleBianlunUIImageFileExtension;
		["TopRight"]	= "J_03"..ModuleBianlunUIImageFileExtension;
		["BottomRight"] = "J_04"..ModuleBianlunUIImageFileExtension;
	};

	frameSide 			= {
		["Shang"]		= "K_shang"..ModuleBianlunUIImageFileExtension;
		["Xia"] 		= "K_xia"..ModuleBianlunUIImageFileExtension;
		["Zuo"]	 		= "K_zuo"..ModuleBianlunUIImageFileExtension;
		["You"] 		= "K_you"..ModuleBianlunUIImageFileExtension;
	};
--]]
	--	Card
	card 				= {
		["black"]   	= {["天"] = "blackCard_01"..ModuleBianlunUIImageFileExtension, ["地"] = "blackCard_03"..ModuleBianlunUIImageFileExtension, ["人"] ="blackCard_02"..ModuleBianlunUIImageFileExtension, ["理"] = "blackCard_04"..ModuleBianlunUIImageFileExtension,};
		["white"]		= {["天"] = "whiteCard_01"..ModuleBianlunUIImageFileExtension, ["地"] = "whiteCard_03"..ModuleBianlunUIImageFileExtension, ["人"] ="whiteCard_02"..ModuleBianlunUIImageFileExtension, ["理"] = "whiteCard_04"..ModuleBianlunUIImageFileExtension,};
		["blackout"]	= {["天"] = "ShowBlack_01"..ModuleBianlunUIImageFileExtension, ["地"] = "ShowBlack_03"..ModuleBianlunUIImageFileExtension, ["人"] ="ShowBlack_02"..ModuleBianlunUIImageFileExtension, ["理"] = "ShowBlack_04"..ModuleBianlunUIImageFileExtension,};
		["whiteout"]	= {["天"] = "ShowWhite_01"..ModuleBianlunUIImageFileExtension, ["地"] = "ShowWhite_03"..ModuleBianlunUIImageFileExtension, ["人"] ="ShowWhite_02"..ModuleBianlunUIImageFileExtension, ["理"] = "ShowWhite_04"..ModuleBianlunUIImageFileExtension,};
	};

	cardBack 			= {
		["normal"]		= "cardBack"..ModuleBianlunUIImageFileExtension;
		["output"]		= "cardBack2"..ModuleBianlunUIImageFileExtension;
	};

	cardPosition 		= "cardPosition"..ModuleBianlunUIImageFileExtension;

	juanzhou 			= "juanzhou2_01"..ModuleBianlunUIImageFileExtension;

	shine 				= "cardShine1.png";

	--	Lun & Bo Back
	lunBack 			= "lunBG"..ModuleBianlunUIImageFileExtension;
	boBack 				= "boBG"..ModuleBianlunUIImageFileExtension;

	--	Btn
	button 				= {
		["隐藏"]		= {	["Normal"] = "yincangBtn_01"..ModuleBianlunUIImageFileExtension	,	["Clicked"] = "yincangBtn_02"..ModuleBianlunUIImageFileExtension	},
		["逃跑"]		= {	["Normal"] = "taopaoBtn_01"..ModuleBianlunUIImageFileExtension	,	["Clicked"]	= "taopaoBtn_02"..ModuleBianlunUIImageFileExtension	},
		["加速"]		= {	["Normal"] = "jiasuBtn_01"..ModuleBianlunUIImageFileExtension	,	["Clicked"]	= "jiasuBtn_02"..ModuleBianlunUIImageFileExtension		},
		["显示"]		= {	["Normal"] = "xianshiBtn_01"..ModuleBianlunUIImageFileExtension	,	["Clicked"]	= "xianshiBtn_02"..ModuleBianlunUIImageFileExtension	},
	};

	--	Tip
	tipFontName 	= "font/STLITI.TTF";
	tipFontSize 	= 23;
	tipMessageBack 	= "tip_help.png";

	--	Skill
	skillFontName 	= "font/STLITI.TTF";
	skillFontSize 	= 36;
	skill   		= {"jinengBG"..ModuleBianlunUIImageFileExtension, "jinengBG"..ModuleBianlunUIImageFileExtension, };

	--	Hero
	headback 		= "wujiangkuang.png";

	-- 	Position
	-- 	Head
	position_self_head_x 	= 700;
	position_self_head_y 	= 100;
	position_other_head_x 	= 220;
	position_other_head_y 	= 540;

	--	Operation
	position_operation_pox_x 	= {["隐藏"] = 880, ["加速"] = 880,["逃跑"] = 880,}; 
	position_operation_pos_y	= {["隐藏"] = 600, ["加速"] = 540,["逃跑"] = 480,};

	--	OutputCard
	position_output_self_x	= 540;
	position_output_self_y	= 310;
	position_output_other_x = 450;
	position_output_other_y = 380;

	--	lun bo
	position_lun_x			= 148;
	position_bo_x			= 824;
	position_lunbo_y		= 320;

	position_hand_self_x  = 410;
	position_hand_self_y  = 100;
	position_hand_other_x = 590;
	position_hand_other_y = 540;

	position_skill_first_x = 210;
	position_skill_first_y = 100;
	position_skill_second_x = 280;
	position_skill_second_y = 100;

	position_skill 	= {
		["Self"] 	= {
			{x 	= 865, 	y = 65};
			{x 	= 865,	y = 140};
		};
		["Other"]	= {
			{x 	= 80, 	y = 640 - 75};
			{x 	= 80, 	y = 640 - 150};
		};
	};

	--	tip
	position_tip_x 		= 480;
	position_tip_y 		= 320;

	--	Tag
	tag_module_bianlun_yincang	= 11000;
	tag_module_bianlun_taopao	= 11001;
	tag_module_bianlun_jiasu	= 11002;
	tag_module_bianlun_xianshi 	= 11003;

	tag_module_bianlun_self_firstskill		= 11010;
	tag_module_bianlun_self_secondskill 	= 11011;
	tag_module_bianlun_other_firstskill		= 11012;
	tag_module_bianlun_other_secondskill 	= 11013;

--------------------------------------------------------------------------------------------------------------------------------------------
--	Module Result
};