--	Date:	2013/11/4
--	Author:	zhaozl
--	Brief:	Native Server Logic

require "ModuleBianlunSkill"

require "lua/itemconfig"
require "ModuleBianlunAI"

ModuleBianlunServerLogic 	= {
	
	--	服务器逻辑状态	
	ServerLogicState_Start		= 	10;
	ServerLogicState_Gameover	=	90;

	ServerLogicState_Init		= 	20;
	ServerLogicState_LunBo		= 	30;
	ServerLogicState_FaPai		= 	40;

	ServerLogicState_GameLoop_Start 		= 	50;
	ServerLogicState_GameLoop_XianHouShou	=	51;
	ServerLogicState_GameLoop_XianShou 		= 	52;
	ServerLogicState_GameLoop_HouShou 		= 	53;
	ServerLogicState_GameLoop_XianShouBupai = 	54;
	ServerLogicState_GameLoop_JueSheng		=  	55;
	ServerLogicState_GameLoop_MoPai 		= 	56;
	ServerLogicState_GameLoop_End 			= 	57;


	ServerLogicState 			= nil;				--	服务器逻辑状态
	ServerLogicHandle			= nil;				--	服务器逻辑流程句柄
	ServerLogic_WaitHandle		= nil;				--	服务器等待句柄


	--	服务器逻辑数据
	ServerLogicWaitTime 			= 2;			--	服务器逻辑等待时间
	ServerLogicTurnWinnerPosition 	= nil;			--  单回合胜者位
	ServerLogicGameover 			= false;		--	服务器逻辑结束标志

	--	Server Logic Data
	ServerLogic_PlayerHandCards 		= {0, 0};	--	对战双方当前手中牌最大数量， Max -- 6 + 1

	--	Hero Skill Data
	HeroSkill_zhenmi_shishi_flag 			= {0, 0};	--	甄宓技能识时, 		Hero Clean
	HeroSkill_zhenmi_lingsheji_flag			= {0, 0};	--	甄宓技能灵蛇髻,  	No   Clean
	HeroSkill_luxun_shuifu_time 			= {0, 0};	--	陆逊技能说服, 		Hero Clean
	HeroSkill_zhugeliang_jijiangfa_time 	= {0, 0};	--	诸葛亮技能激将法, 	Hero Clean
	HeroSkill_zhouyu_guibian_time 			= {0, 0};	--	周瑜诡辩技能次数,   Hero Clean 
	HeroSkill_caocao_nuze_time 				= {0, 0};	--	曹操怒责技能次数, 	Hero Clean


	--	Skill Result Output Ordering Modified
	ServerLogic_CurrentOutputPosition 		= nil;		--	服务器端逻辑出牌位
};

------------------------------------------------------------------------------------------------------------------------------------
--	ModuleBianlunServerLogic Log
function ModuleBianlunServerLogic.Log( msg )
	-- body

	local 	preFix 	= "++ ModuleBianlunServerLogic ++\n";
	local 	newMsg  = tostring(preFix)..tostring(msg);

	print(msg);
end

------------------------------------------------------------------------------------------------------------------------------------
--	ServerLogic Wait Breaker

function ModuleBianlunServerLogic.WaitCallback(  )
	-- body

	print("WaitCallBack!");

	if 	ModuleBianlunServerLogic.ServerLogic_WaitHandle	~= nil then
		cc.Director:getInstance():getScheduler():unscheduleScriptEntry(ModuleBianlunServerLogic.ServerLogic_WaitHandle);
		ModuleBianlunServerLogic.ServerLogic_WaitHandle = nil;
	end

	if 	ModuleBianlunServerLogic.ServerLogicHandle 	~= nil 	then

		coroutine.resume(ModuleBianlunServerLogic.ServerLogicHandle, "Timeout");
	else

		local 	serverLogic = CModuleBianlunServerLogic:sharedServerLogic();
		serverLogic:network_server_forcePlayerLeave(0);

	end
end

function ModuleBianlunServerLogic.LogicStopWait( pos )
	-- body

	if 	ModuleBianlunServerLogic.ServerLogic_WaitHandle	~= nil then
		cc.Director:getInstance():getScheduler():unscheduleScriptEntry(ModuleBianlunServerLogic.ServerLogic_WaitHandle);
		ModuleBianlunServerLogic.ServerLogic_WaitHandle	= nil;
	end

	coroutine.resume(ModuleBianlunServerLogic.ServerLogicHandle, "MessageArrive", pos, "Logic");
end


function ModuleBianlunServerLogic.SkillStopWait( pos, index )
	-- body
	
	if 	ModuleBianlunServerLogic.ServerLogic_WaitHandle	~= nil then
		cc.Director:getInstance():getScheduler():unscheduleScriptEntry(ModuleBianlunServerLogic.ServerLogic_WaitHandle);
		ModuleBianlunServerLogic.ServerLogic_WaitHandle	= nil;
	end

	coroutine.resume(ModuleBianlunServerLogic.ServerLogicHandle, "MessageArrive", pos, "Skill", index);	
end

function ModuleBianlunServerLogic.CheckOtherCardStopWait( pos, tag )
	-- body

	ModuleBianlunServerLogic.Log(tostring(pos).."vs."..tostring(tag));

	if 	ModuleBianlunServerLogic.ServerLogic_WaitHandle	~= nil then
		cc.Director:getInstance():getScheduler():unscheduleScriptEntry(ModuleBianlunServerLogic.ServerLogic_WaitHandle);
		ModuleBianlunServerLogic.ServerLogic_WaitHandle	= nil;
	end

	coroutine.resume(ModuleBianlunServerLogic.ServerLogicHandle, "MessageArrive", pos, "CheckCard", tag);	
end

function ModuleBianlunServerLogic.GameoverStopWait(  )
	-- body

	if 	ModuleBianlunServerLogic.ServerLogic_WaitHandle	~= nil then
		cc.Director:getInstance():getScheduler():unscheduleScriptEntry(ModuleBianlunServerLogic.ServerLogic_WaitHandle);
		ModuleBianlunServerLogic.ServerLogic_WaitHandle	= nil;
	end

	coroutine.resume(ModuleBianlunServerLogic.ServerLogicHandle, "Gameover");	

end

--	Server Logic Wait & WaitTimeout
function ModuleBianlunServerLogic.Wait( second )
	-- body

	if 	ModuleBianlunServerLogic.ServerLogic_WaitHandle	~= nil then
		cc.Director:getInstance():getScheduler():unscheduleScriptEntry(ModuleBianlunServerLogic.ServerLogic_WaitHandle);
		ModuleBianlunServerLogic.ServerLogic_WaitHandle	= nil;
	end

	second = second or 0.5;
	ModuleBianlunServerLogic.ServerLogic_WaitHandle = cc.Director:getInstance():getScheduler():scheduleScriptFunc(ModuleBianlunServerLogic.WaitCallback, second, false);

	return coroutine.yield();
end

function ModuleBianlunServerLogic.WaitTimeout( second )
	-- body
	
	while 	true do 
			local 	_state = ModuleBianlunServerLogic.Wait(second);
			if 		_state == "Timeout"		then
					do break end
			elseif	_state == "Gameover"	then
					do break end
			end
	end
end

------------------------------------------------------------------------------------------------------------------------------------
--	ServerLogic State Set/Get 

function ModuleBianlunServerLogic.SetServerLogicState( state )
	-- body
	
	ModuleBianlunServerLogic.ServerLogicState = state;
end

function ModuleBianlunServerLogic.GetServerLogicState( ... )
	-- body
	
	return ModuleBianlunServerLogic.ServerLogicState;
end

function ModuleBianlunServerLogic.RecordCurrentOutputPosition( pos )
	-- body

	ModuleBianlunServerLogic.ServerLogic_CurrentOutputPosition = pos;
end

function ModuleBianlunServerLogic.GetCurrentOutputPosition( ... )
	-- body

	return ModuleBianlunServerLogic.ServerLogic_CurrentOutputPosition;
end

function ModuleBianlunServerLogic.ClearCurrentOutputPosition( ... )
	-- body

	ModuleBianlunServerLogic.ServerLogic_CurrentOutputPosition = nil;
end

function ModuleBianlunServerLogic.Process_LunBo( ... )
	-- body
	
	local 	serverLogic 	= CModuleBianlunServerLogic:sharedServerLogic();

	serverLogic:handlePreStartLunBoProcess();
end

function ModuleBianlunServerLogic.PreNotifyFaPai( pos )
	-- body

	local 	serverLogic 	= CModuleBianlunServerLogic:sharedServerLogic();
	local   heroName 		= serverLogic:getPlayerName(pos);

	if 		heroName 	== "貂蝉"	then
			serverLogic:setPlayerHandCard(1- pos, 0, CModuleBianlunCard:new(ModuleBianlunCardType_Black, ModuleBianlunCardValue_Tian))
	elseif 	heroName 	== "鲁肃"	then
			serverLogic:setPlayerHandCard(pos, 0, CModuleBianlunCard:new(ModuleBianlunCardType_Black, ModuleBianlunCardValue_Di));
			serverLogic:setPlayerHandCard(pos, 1, CModuleBianlunCard:new(ModuleBianlunCardType_White, ModuleBianlunCardValue_Di));
			serverLogic:setPlayerHandCard(pos, 2, CModuleBianlunCard:new(ModuleBianlunCardType_Black, ModuleBianlunCardValue_Tian));
			serverLogic:setPlayerHandCard(pos, 3, CModuleBianlunCard:new(ModuleBianlunCardType_White, ModuleBianlunCardValue_Tian));

			serverLogic:setPlayerHandCard(1- pos, 0, CModuleBianlunCard:new(ModuleBianlunCardType_Black, ModuleBianlunCardValue_Tian));
			serverLogic:setPlayerHandCard(1- pos, 1, CModuleBianlunCard:new(ModuleBianlunCardType_White, ModuleBianlunCardValue_Tian));
			serverLogic:setPlayerHandCard(1- pos, 2, CModuleBianlunCard:new(ModuleBianlunCardType_Black, ModuleBianlunCardValue_Di));
			serverLogic:setPlayerHandCard(1- pos, 3, CModuleBianlunCard:new(ModuleBianlunCardType_White, ModuleBianlunCardValue_Di));			

	elseif	heroName 	== "吕蒙"	then
			serverLogic:setPlayerHandCard(pos, 0, CModuleBianlunCard:new(ModuleBianlunCardType_Black, ModuleBianlunCardValue_Di));
			serverLogic:setPlayerHandCard(pos, 1, CModuleBianlunCard:new(ModuleBianlunCardType_White, ModuleBianlunCardValue_Di));
			serverLogic:setPlayerHandCard(pos, 2, CModuleBianlunCard:new(ModuleBianlunCardType_Black, ModuleBianlunCardValue_Tian));
			serverLogic:setPlayerHandCard(pos, 3, CModuleBianlunCard:new(ModuleBianlunCardType_White, ModuleBianlunCardValue_Tian))
			serverLogic:setPlayerHandCard(pos, 4, CModuleBianlunCard:new(ModuleBianlunCardType_White, ModuleBianlunCardValue_Tian))

			serverLogic:setPlayerHandCard(1 - pos, 0, CModuleBianlunCard:new(ModuleBianlunCardType_White, ModuleBianlunCardValue_Tian));
			serverLogic:setPlayerHandCard(1 - pos, 1, CModuleBianlunCard:new(ModuleBianlunCardType_White, ModuleBianlunCardValue_Di));
			serverLogic:setPlayerHandCard(1 - pos, 2, CModuleBianlunCard:new(ModuleBianlunCardType_Black, ModuleBianlunCardValue_Tian));
			serverLogic:setPlayerHandCard(1 - pos, 3, CModuleBianlunCard:new(ModuleBianlunCardType_White, ModuleBianlunCardValue_Tian))
			serverLogic:setPlayerHandCard(1 - pos, 4, CModuleBianlunCard:new(ModuleBianlunCardType_White, ModuleBianlunCardValue_Tian))
--
--			serverLogic:setPlayerHandCard(1- pos, 0, CModuleBianlunCard:new(ModuleBianlunCardType_White, ModuleBianlunCardValue_Ren));
--			serverLogic:setPlayerHandCard(1- pos, 1, CModuleBianlunCard:new(ModuleBianlunCardType_White, ModuleBianlunCardValue_Li));
--			serverLogic:setPlayerHandCard(1- pos, 2, CModuleBianlunCard:new(ModuleBianlunCardType_Black, ModuleBianlunCardValue_Tian));
--			serverLogic:setPlayerHandCard(1- pos, 3, CModuleBianlunCard:new(ModuleBianlunCardType_White, ModuleBianlunCardValue_Tian));
			--]]
	elseif	heroName 	== "贾诩"	then
			serverLogic:setPlayerHandCard(1- pos, 0, CModuleBianlunCard:new(ModuleBianlunCardType_White, ModuleBianlunCardValue_Ren));
			serverLogic:setPlayerHandCard(1- pos, 1, CModuleBianlunCard:new(ModuleBianlunCardType_White, ModuleBianlunCardValue_Tian));

			serverLogic:setPlayerHandCard(pos, 0, CModuleBianlunCard:new(ModuleBianlunCardType_White, ModuleBianlunCardValue_Ren));
			serverLogic:setPlayerHandCard(pos, 1, CModuleBianlunCard:new(ModuleBianlunCardType_White, ModuleBianlunCardValue_Ren));
	elseif 	heroName 	== "陆逊"	then
			serverLogic:setPlayerHandCard(pos, 0, CModuleBianlunCard:new(ModuleBianlunCardType_White, ModuleBianlunCardValue_Di));
			serverLogic:setPlayerHandCard(pos, 1, CModuleBianlunCard:new(ModuleBianlunCardType_White, ModuleBianlunCardValue_Di));
			serverLogic:setPlayerHandCard(pos, 2, CModuleBianlunCard:new(ModuleBianlunCardType_White, ModuleBianlunCardValue_Di));

			serverLogic:setPlayerHandCard(1- pos, 0, CModuleBianlunCard:new(ModuleBianlunCardType_White, ModuleBianlunCardValue_Ren));
			serverLogic:setPlayerHandCard(1- pos, 1, CModuleBianlunCard:new(ModuleBianlunCardType_White, ModuleBianlunCardValue_Ren));
			serverLogic:setPlayerHandCard(1- pos, 2, CModuleBianlunCard:new(ModuleBianlunCardType_White, ModuleBianlunCardValue_Ren));
	elseif	heroName 	== "诸葛亮"	then
			serverLogic:setPlayerHandCard(pos, 0, CModuleBianlunCard:new(ModuleBianlunCardType_White, ModuleBianlunCardValue_Ren));
			serverLogic:setPlayerHandCard(pos, 1, CModuleBianlunCard:new(ModuleBianlunCardType_White, ModuleBianlunCardValue_Ren));
			serverLogic:setPlayerHandCard(pos, 2, CModuleBianlunCard:new(ModuleBianlunCardType_White, ModuleBianlunCardValue_Ren));

			serverLogic:setPlayerHandCard(1- pos, 0, CModuleBianlunCard:new(ModuleBianlunCardType_White, ModuleBianlunCardValue_Di));
			serverLogic:setPlayerHandCard(1- pos, 1, CModuleBianlunCard:new(ModuleBianlunCardType_White, ModuleBianlunCardValue_Di));
			serverLogic:setPlayerHandCard(1- pos, 2, CModuleBianlunCard:new(ModuleBianlunCardType_White, ModuleBianlunCardValue_Di));	


	elseif	heroName 	== "孙权"	then
			serverLogic:setPlayerHandCard(pos, 0, CModuleBianlunCard:new(ModuleBianlunCardType_White, ModuleBianlunCardValue_Ren));
			serverLogic:setPlayerHandCard(pos, 1, CModuleBianlunCard:new(ModuleBianlunCardType_White, ModuleBianlunCardValue_Tian));

			serverLogic:setPlayerHandCard(1- pos, 0, CModuleBianlunCard:new(ModuleBianlunCardType_White, ModuleBianlunCardValue_Di));
			serverLogic:setPlayerHandCard(1- pos, 1, CModuleBianlunCard:new(ModuleBianlunCardType_White, ModuleBianlunCardValue_Di));
			serverLogic:setPlayerHandCard(1- pos, 2, CModuleBianlunCard:new(ModuleBianlunCardType_White, ModuleBianlunCardValue_Di));
			serverLogic:setPlayerHandCard(1- pos, 3, CModuleBianlunCard:new(ModuleBianlunCardType_White, ModuleBianlunCardValue_Di));
			serverLogic:setPlayerHandCard(1- pos, 4, CModuleBianlunCard:new(ModuleBianlunCardType_White, ModuleBianlunCardValue_Di));
			serverLogic:setPlayerHandCard(1- pos, 5, CModuleBianlunCard:new(ModuleBianlunCardType_White, ModuleBianlunCardValue_Di));

	elseif	heroName 	== 	"周瑜"	then
			serverLogic:setPlayerHandCard(pos, 0, CModuleBianlunCard:new(ModuleBianlunCardType_White, ModuleBianlunCardValue_Di));
			serverLogic:setPlayerHandCard(pos, 1, CModuleBianlunCard:new(ModuleBianlunCardType_White, ModuleBianlunCardValue_Tian));
			serverLogic:setPlayerHandCard(pos, 2, CModuleBianlunCard:new(ModuleBianlunCardType_White, ModuleBianlunCardValue_Di));
			serverLogic:setPlayerHandCard(pos, 3, CModuleBianlunCard:new(ModuleBianlunCardType_White, ModuleBianlunCardValue_Tian));

			serverLogic:setPlayerHandCard(1- pos, 0, CModuleBianlunCard:new(ModuleBianlunCardType_White, ModuleBianlunCardValue_Tian));
			serverLogic:setPlayerHandCard(1- pos, 1, CModuleBianlunCard:new(ModuleBianlunCardType_White, ModuleBianlunCardValue_Tian));
			serverLogic:setPlayerHandCard(1- pos, 2, CModuleBianlunCard:new(ModuleBianlunCardType_White, ModuleBianlunCardValue_Tian));
			serverLogic:setPlayerHandCard(1- pos, 3, CModuleBianlunCard:new(ModuleBianlunCardType_White, ModuleBianlunCardValue_Tian));
	elseif 	heroName 	== "曹操"	then
			serverLogic:setPlayerHandCard(pos, 0, CModuleBianlunCard:new(ModuleBianlunCardType_White, ModuleBianlunCardValue_Di));
			serverLogic:setPlayerHandCard(pos, 1, CModuleBianlunCard:new(ModuleBianlunCardType_White, ModuleBianlunCardValue_Tian));
			serverLogic:setPlayerHandCard(pos, 2, CModuleBianlunCard:new(ModuleBianlunCardType_White, ModuleBianlunCardValue_Di));
			serverLogic:setPlayerHandCard(pos, 3, CModuleBianlunCard:new(ModuleBianlunCardType_White, ModuleBianlunCardValue_Tian));

			serverLogic:setPlayerHandCard(1- pos, 0, CModuleBianlunCard:new(ModuleBianlunCardType_Black, ModuleBianlunCardValue_Ren));
			serverLogic:setPlayerHandCard(1- pos, 1, CModuleBianlunCard:new(ModuleBianlunCardType_White, ModuleBianlunCardValue_Ren));
			serverLogic:setPlayerHandCard(1- pos, 2, CModuleBianlunCard:new(ModuleBianlunCardType_White, ModuleBianlunCardValue_Ren));
			serverLogic:setPlayerHandCard(1- pos, 3, CModuleBianlunCard:new(ModuleBianlunCardType_White, ModuleBianlunCardValue_Ren));	
	elseif	heroName 	== "郭嘉" 	then
			serverLogic:setPlayerHandCard(pos, 0, CModuleBianlunCard:new(ModuleBianlunCardType_White, ModuleBianlunCardValue_Ren));
			serverLogic:setPlayerHandCard(pos, 1, CModuleBianlunCard:new(ModuleBianlunCardType_Black, ModuleBianlunCardValue_Ren));
			serverLogic:setPlayerHandCard(pos, 2, CModuleBianlunCard:new(ModuleBianlunCardType_White, ModuleBianlunCardValue_Ren));
			serverLogic:setPlayerHandCard(pos, 3, CModuleBianlunCard:new(ModuleBianlunCardType_Black, ModuleBianlunCardValue_Ren));
			serverLogic:setPlayerHandCard(pos, 4, CModuleBianlunCard:new(ModuleBianlunCardType_Black, ModuleBianlunCardValue_Ren));			

			serverLogic:setPlayerHandCard(1 - pos, 0, CModuleBianlunCard:new(ModuleBianlunCardType_Black, ModuleBianlunCardValue_Ren));
			serverLogic:setPlayerHandCard(1 - pos, 1, CModuleBianlunCard:new(ModuleBianlunCardType_White, ModuleBianlunCardValue_Di));
	end
end

function ModuleBianlunServerLogic.Process_FaPai( ... )
	-- body
	
	local 	serverLogic 	= CModuleBianlunServerLogic:sharedServerLogic();
	local 	card 			= nil;

	--	对战双方手中牌数量设定
	ModuleBianlunServerLogic.SetPlayerHandCardSize(1, 3);	--	位置0 玩家手中牌数量
	ModuleBianlunServerLogic.SetPlayerHandCardSize(2, 1);	--	位置1 玩家手中牌数量


	ModuleBianlunServerLogic.PreFaPai();


	for i = 1, ModuleBianlunServerLogic.ServerLogic_PlayerHandCards[1] do
		card 	= serverLogic:getNextCard();
		card:setTag(i);
		serverLogic:appendPlayerHandCard(0, card);
	end

	for i = 1, ModuleBianlunServerLogic.ServerLogic_PlayerHandCards[2] do
		card 	= serverLogic:getNextCard();
		card:setTag(i);
		serverLogic:appendPlayerHandCard(1, card);
	end

	--	DEBUG
	--	测试时开启
--	ModuleBianlunServerLogic.PreNotifyFaPai(0);
	--	DEBUG

	serverLogic:network_server_notifyPlayerHandCards();
end

function ModuleBianlunServerLogic.OutputTimeOut( pos, num )
	-- body
	
--	ModuleBianlunServerLogic.Log("出牌超时处理"..tostring(pos).." vs. "..tostring(num));
	local   serverLogic 	= CModuleBianlunServerLogic:sharedServerLogic();
	local 	size 			= serverLogic:getPlayerHandCardSize(pos);

--	ModuleBianlunServerLogic.Log(tostring(size));

	if 		size >= num		then

--[[		
			--	自动出牌
			for 	i = 1, num	do 
					local 	card 	= serverLogic:getPlayerHandCard(pos, i -1);
					ModuleBianlunServerLogic.Log("\n@Timeout Auto Output: "..card:dumpCard().."\n");
					serverLogic:appendPlayerOutputCard(pos, card);
			end
--]]

			for 	i = 1, num do 
					ModuleBianlunAI.HandlePlayerOutput(pos);
			end

			--	服务器接受出牌
			serverLogic:acceptPlayerOutputEvent(pos);
	else
			ModuleBianlunServerLogic.Log("Error@Lua, 出牌超时目标出牌多于手中剩余牌");
	end
end

------------------------------------------------------------------------------------------------------------------------------------
--	技能处理接口

--	游戏一轮开始之前的处理
function ModuleBianlunServerLogic.BeforeRoundStart( ... )
	-- body

	local 	serverLogic = CModuleBianlunServerLogic:sharedServerLogic();
	local 	player0 	= serverLogic:getPlayerName(0);
	local   player1 	= serverLogic:getPlayerName(1);	

	if 		player0 == "郭嘉" 	and player1 == "郭嘉"	then

			--	双方都为郭嘉，断技能失效
			return;
	elseif 	player0 == "郭嘉" 	then
			ModuleBianlunSkill.BeforeRoundStart(0);
	elseif 	player1 == "郭嘉" 	then
			ModuleBianlunSkill.BeforeRoundStart(1);
	else
	end

	--	恢复出牌正常位置
	serverLogic:fixOutputPositionBeforeRoundStart();
	serverLogic:doTurnClean();
	serverLogic:network_server_notifyPlayerHideOutputCards();
end


--	位置玩家出牌前处理
function ModuleBianlunServerLogic.BeforeOperation( pos )
	-- body

	return 	ModuleBianlunSkill.BeforeOperation(pos);
end


--	回合败者处理
function ModuleBianlunServerLogic.AfterCompareWithLosserBeforeConfirm( pos )
	-- body

	return ModuleBianlunSkill.AfterCompareWithLosserBeforeConfirm(pos);
end


--	回合改变论驳牌处理
function ModuleBianlunServerLogic.BeforeDecideChangeLunBo( pos )
	-- body

	return ModuleBianlunSkill.BeforeDecideChangeLunBo(pos);
end

--	辩牌平手处理
function ModuleBianlunServerLogic.DecideWinnerWithBianDraw(  )
	-- body

	local 	result0 = ModuleBianlunSkill.DecideWinnerWithBianDraw(0);
	local 	result1 = ModuleBianlunSkill.DecideWinnerWithBianDraw(1);

	if 	result0 == 0 and result1 == 1 then
		--	All Draw
		return nil;
	else
		if 		result0 == 0 	then
				return 0;
		elseif 	result1 == 1 	then
				return 1;
		else
				return nil;
		end
	end
end

--	显示牌后处理
function ModuleBianlunServerLogic.AfterShowOutputCard(  )
	-- body

	local 	serverLogic = CModuleBianlunServerLogic:sharedServerLogic();
	local 	player0 	= serverLogic:getPlayerName(0);
	local   player1 	= serverLogic:getPlayerName(1);

	if 		player0 == "田丰" and player1 == "田丰"		then

			return;
	elseif	player0 == "田丰" 	then

			return ModuleBianlunSkill.AfterShowOutputCard(0);
	elseif	player1 == "田丰"	then

			return ModuleBianlunSkill.AfterShowOutputCard(1);
	end

	return;
end

--	回合胜者处理
function ModuleBianlunServerLogic.AfterCompareWithWinner( pos )
	-- body

	return ModuleBianlunSkill.AfterCompareWithWinner(pos);
end

function ModuleBianlunServerLogic.AfterCompareWithLosser( pos )
	-- body

	return ModuleBianlunSkill.AfterCompareWithLosser(pos);
end

function ModuleBianlunServerLogic.PreFaPai(  )
	-- body

	ModuleBianlunSkill.PreFaPai(0);
	ModuleBianlunSkill.PreFaPai(1);
end


function ModuleBianlunServerLogic.CheckCanHandleZhengBian(  )
	-- body

	local 	serverLogic = CModuleBianlunServerLogic:sharedServerLogic();
	local 	player0 	= serverLogic:getPlayerName(0);
	local   player1 	= serverLogic:getPlayerName(1);

	if 		player0 == "曹操" and player1 == "曹操"		then

			--	双方都为曹操，技能失效
			return 	true;
	elseif	player0 == "曹操" 	then

			return ModuleBianlunSkill.CheckCanHandleZhengBian(0);
	elseif	player1 == "曹操"	then

			return ModuleBianlunSkill.CheckCanHandleZhengBian(1);
	else
			--	非曹操英雄
			return true;
	end	
end

------------------------------------------------------------------------------------------------------------------------------------
--	回合胜负判定

function ModuleBianlunServerLogic.DumpResultType( pos, type )
	-- body
	
	local 	typeMsg = nil;
	if 		type == ModuleBianlunResultType_Lun 	then
			typeMsg = "论牌";
	elseif	type == ModuleBianlunResultType_Bian 	then
			typeMsg = "辩牌";
	elseif 	type == ModuleBianlunResultType_Bo 		then
			typeMsg = "驳牌";
	end
	ModuleBianlunServerLogic.Log("位置: "..tostring(pos).." :"..tostring(typeMsg).."vs."..tostring(type));
end

--	Determin victory
function ModuleBianlunServerLogic.DetermineVictory( ... )
	-- body
	
	ModuleBianlunServerLogic.Log("判定回合双方胜负");

	local 	serverLogic 	= CModuleBianlunServerLogic:sharedServerLogic();

	local 	playerOutputCardSize0 = serverLogic:getPlayerPreOutputCardSize(0);
	local 	playerOutputCardSize1 = serverLogic:getPlayerPreOutputCardSize(1);

	ModuleBianlunServerLogic.Log("双方出牌数量： ");
	ModuleBianlunServerLogic.Log("位置 0 数量："..tostring(playerOutputCardSize0));
	ModuleBianlunServerLogic.Log("位置 1 数量: "..tostring(playerOutputCardSize1));

	if 		playerOutputCardSize0 ~= playerOutputCardSize1 then
			ModuleBianlunServerLogic.Log("Error@Lua, 双方出牌不一致");
	else

			if 		playerOutputCardSize0 ==  1 then
					ModuleBianlunServerLogic.Log("双方单牌对决");

					local  	output0 		= serverLogic:getPlayerPreOutputCard(0, 0);
					local 	output1 		= serverLogic:getPlayerPreOutputCard(1, 0);

					--	胜负判定
					local 	type0 	= serverLogic:getBianlunResultType(output0);
					local 	type1 	= serverLogic:getBianlunResultType(output1);

					ModuleBianlunServerLogic.DumpResultType(0, type0);
					ModuleBianlunServerLogic.DumpResultType(1, type1);

					if 		type0 	== type1 	then
							--	同牌型

							--	平手
							if 	type0 == ModuleBianlunResultType_Bian 	then
								if 	output0:getValue()  ~= output1:getValue() 	then
									--	不同类别辩牌
									ModuleBianlunServerLogic.Log("不同类别辩牌， 论驳牌更替");
									if 	serverLogic:getOutputPosition() == 0 	then
										serverLogic:updateLunCard(output0);
										serverLogic:updateBoCard (output1);
									else
										serverLogic:updateLunCard(output1);
										serverLogic:updateBoCard (output0);							
									end
								end


								--	检测英雄技能导致的同位辩牌的胜负之分
								local 	winnerPosition = ModuleBianlunServerLogic.DecideWinnerWithBianDraw();
								if 		winnerPosition ~= nil then

										ModuleBianlunServerLogic.ServerLogicTurnWinnerPosition = winnerPosition;

										return ModuleBianlunServerLogic.ServerLogicState_GameLoop_End;					
								end
							end


							--	双方都不摸牌
							--	结束回合
							ModuleBianlunServerLogic.Log("双方出牌类别相同都不摸牌");

							ModuleBianlunServerLogic.ServerLogicTurnWinnerPosition = nil;

							return 	ModuleBianlunServerLogic.ServerLogicState_GameLoop_End;
					else
							local 	winnerPosition = nil;
							local 	losserPosition = nil;

							--	非同牌型
							if  type0 + type1 == ModuleBianlunResultType_Count then
									if 	type0 < type1 then
										--	论 vs. 驳
										winnerPosition = 1;
										losserPosition = 0;
									else
										--	驳 vs. 论
										winnerPosition = 0;
										losserPosition = 1;
									end

							

							else
								if 	type0 < type1 then
									winnerPosition = 0;
									losserPosition = 1;
								else
									winnerPosition = 1;
									losserPosition = 0;
								end
							end
							
							ModuleBianlunServerLogic.Log("英雄技能影响之前本来的回合结果：");
							ModuleBianlunServerLogic.Log("Winner : "..tostring(winnerPosition));
							ModuleBianlunServerLogic.Log("Losser : "..tostring(losserPosition));

							

							local 	bInvalid = ModuleBianlunServerLogic.AfterCompareWithLosserBeforeConfirm(losserPosition);

							ModuleBianlunServerLogic.Log(tostring(bInvalid));

							if 		bInvalid ~= true then

									if 	type0 + type1 == ModuleBianlunResultType_Count then

										ModuleBianlunServerLogic.Log("论驳牌型");

										--	胜者摸牌
										if 	winnerPosition ~= nil and losserPosition ~= nil then		
													
											--	记录当前局的输赢，在回合结束处处理
											ModuleBianlunServerLogic.ServerLogicTurnWinnerPosition = winnerPosition;
											return ModuleBianlunServerLogic.ServerLogicState_GameLoop_End;
										else
											ModuleBianlunServerLogic.Log("Error@Lua, DetermineVictory() failed while two Side With  different Type");
											return ModuleBianlunServerLogic.ServerLogicState_Gameover;
										end
									end		

									--	论驳牌改变
									-- 	BUG Fixed
									--	只有辩牌才能更新为论或驳牌
									if 		type0 == ModuleBianlunResultType_Lun or type1 == ModuleBianlunResultType_Lun 	then

											local 	bCanHandleZhengBian = ModuleBianlunServerLogic.CheckCanHandleZhengBian();
--											ModuleBianlunServerLogic.Log("If Can Handle ZhengBian： "..tostring(bCanHandleZhengBian));
											if 		bCanHandleZhengBian == true 	then

													local 	bTongSeChanged0 	= ModuleBianlunServerLogic.BeforeDecideChangeLunBo(0) 
													local 	bTongSeChanged1		= ModuleBianlunServerLogic.BeforeDecideChangeLunBo(1);

													local 	bTongSeChanged 		= bTongSeChanged0 or bTongSeChanged1;

													if 	output0:getType() ~= output1:getType() or bTongSeChanged then
														ModuleBianlunServerLogic.Log("双方为论辩牌型，不同色或技能迫使，更新论牌");
														if 		type0 == ModuleBianlunResultType_Lun then
																serverLogic:updateLunCard(output1);
														elseif	type1 == ModuleBianlunResultType_Lun then
																serverLogic:updateLunCard(output0);
														end
													end 
											end 
									elseif  type0 == ModuleBianlunResultType_Bo  or type1 == ModuleBianlunResultType_Bo 	then
											
											local 	bTongSeChanged0 	= ModuleBianlunServerLogic.BeforeDecideChangeLunBo(0) 
											local 	bTongSeChanged1		= ModuleBianlunServerLogic.BeforeDecideChangeLunBo(1);

											local 	bTongSeChanged 		= bTongSeChanged0 or bTongSeChanged1;

											if 	output0:getType() ~= output1:getType() or bTongSeChanged then
												ModuleBianlunServerLogic.Log("双方为辩驳牌型，不同色或技能迫使，更新驳牌");
												if 		type0 == ModuleBianlunResultType_Bo then
														serverLogic:updateBoCard(output1);
												elseif	type1 == ModuleBianlunResultType_Bo then
														serverLogic:updateBoCard(output0);
												end
											end 
									end

									--	胜者摸牌
									if 	winnerPosition ~= nil and losserPosition ~= nil then		
										
										--	记录当前局的输赢，在回合结束处处理
										ModuleBianlunServerLogic.ServerLogicTurnWinnerPosition = winnerPosition;

										print("处理Common Skill");
										--	胜者出牌音效播放
										local 	gender 	= nil;
										local 	type 	= nil;
										local 	card 	= nil;

										if 	winnerPosition == 0 then
												card 	= output0;
										else
												card 	= output1;
										end

										local 	winnerName 	= serverLogic:getPlayerName(winnerPosition);
										gender 	= ModuleBianlunSkill.GetHeroInfo(winnerName, "Gender");

										if 		card:getValue() == ModuleBianlunCardValue_Tian 	then
												type 	= "天"
										elseif 	card:getValue() == ModuleBianlunCardValue_Di 	then
												type 	= "地"
										elseif 	card:getValue() == ModuleBianlunCardValue_Ren 	then
												type 	= "人"
										elseif 	card:getValue() == ModuleBianlunCardValue_Li 	then
												type 	= "理"
										end

										print(tostring(gender)..tostring(type));
										serverLogic:network_server_broadCastPlayerCommonSkillSoundEffect(winnerPosition, gender, type);

										print("Common Sound Effect");

										return ModuleBianlunServerLogic.ServerLogicState_GameLoop_End;
									else
										ModuleBianlunServerLogic.Log("Error@Lua, DetermineVictory() failed while two Side With  different Type");
										return ModuleBianlunServerLogic.ServerLogicState_Gameover;
									end

							else
									--	失败者技能促使回合结果无效
									return ModuleBianlunServerLogic.ServerLogicState_GameLoop_End;
							end
					end					


			else
					ModuleBianlunServerLogic.Log("双方多牌对决");

					--	针对周瑜合论技能判定处理

					local 	winnerPosition 	= nil;
					local 	losserPosition  = nil;

					local 	playerOutput0 = serverLogic:getPlayerPreOutputCardList(0);
					local 	playerOutput1 = serverLogic:getPlayerPreOutputCardList(1);

					local 	bSameCard0 	  = algorithm_module_bianlun_zhenmi_checksametype(playerOutput0);
					local 	bSameCard1 	  = algorithm_module_bianlun_zhenmi_checksametype(playerOutput1);

					if 		bSameCard0 	== true and bSameCard1 == true then
							local  	output0 		= serverLogic:getPlayerPreOutputCard(0, 0);
							local 	output1 		= serverLogic:getPlayerPreOutputCard(1, 0);

							--	胜负判定
							local 	type0 	= serverLogic:getBianlunResultType(output0);
							local 	type1 	= serverLogic:getBianlunResultType(output1);	
							
							if 		type0 	== ModuleBianlunResultType_Lun 	and type1  == ModuleBianlunResultType_Bo 	then
									winnerPosition = 1;
									losserPosition = 0
							elseif 	type1	== ModuleBianlunResultType_Lun	and type0  == ModuleBianlunResultType_Bo 	then
									winnerPosition = 0;
									losserPosition = 1;
							else
									if 		type1 == ModuleBianlunResultType_Lun 	then
											winnerPosition  = 1;
											losserPosition  = 0;
									elseif 	type0 == ModuleBianlunResultType_Lun 	then
											winnerPosition  = 0;
											losserPosition  = 1;
									end
							end
					else
							if 		bSameCard0 == true then
									winnerPosition = 0;
									losserPosition = 1;

							elseif	bSameCard1 == true then
									winnerPosition = 1;
									losserPosition = 0;
							end
					end

--[[
					--	Must Have A Winner or Losser
					if 	winnerPosition == nil and losserPosition == nil then
						ModuleBianlunServerLogic.Log("Error@Lua, Winner/Losser Not Clear!");
						return;
					end
--]]

					ModuleBianlunServerLogic.Log("多牌对决回合判定结果:");
					ModuleBianlunServerLogic.Log("Winner : "..tostring(winnerPosition));
					ModuleBianlunServerLogic.Log("Losser : "..tostring(losserPosition));	

					--	胜者摸牌
					if 	winnerPosition ~= nil and losserPosition ~= nil then		
										
						--	记录当前局的输赢，在回合结束处处理
						ModuleBianlunServerLogic.ServerLogicTurnWinnerPosition = winnerPosition;
						return ModuleBianlunServerLogic.ServerLogicState_GameLoop_End;
					else
						ModuleBianlunServerLogic.Log("Error@Lua, DetermineVictory() failed while two Side With  different Type");
						return ModuleBianlunServerLogic.ServerLogicState_Gameover;
					end


 			end

	end
end

--	Module Bianlun's ServerLogic Process
function ModuleBianlunServerLogic.Coroutine_ServerLogic( ... )
	-- body
	
	local 	serverLogic 	= CModuleBianlunServerLogic:sharedServerLogic();
	local 	logicState 		= ModuleBianlunServerLogic.GetServerLogicState();

	while 	true  do 
			
			if 		ModuleBianlunServerLogic.ServerLogicGameover  == true then
					do  break end
			end

			if  	logicState 	==	ModuleBianlunServerLogic.ServerLogicState_Start 		then
					ModuleBianlunServerLogic.Log("\n##	模块辩论--服务端逻辑开始	##\n");
			
					logicState 	= ModuleBianlunServerLogic.ServerLogicState_Init;
			
			elseif 	logicState 	==	ModuleBianlunServerLogic.ServerLogicState_Init 			then
					ModuleBianlunServerLogic.Log("\n##	模块辩论--服务端初始化	##\n");
					
					--	牌池初始化 
					serverLogic:initialize();

					--	挑战方 、 对战双方设定
					serverLogic:network_server_notifyPlayerPosition();
--
		
					ModuleBianlunServerLogic.SetChallenger(0);

					--	Player 0
--					ModuleBianlunServerLogic.SetPlayerInfo(0, 20, "甄宓(1)");
--					ModuleBianlunServerLogic.SetPlayerInfo(0, 33, "甄宓（2）");
--					ModuleBianlunServerLogic.SetPlayerInfo(0, 24, "貂蝉");			
--					ModuleBianlunServerLogic.SetPlayerInfo(0, 29, "鲁肃");
--					ModuleBianlunServerLogic.SetPlayerInfo(0, 11, "吕蒙");
--					ModuleBianlunServerLogic.SetPlayerInfo(0, 22, "贾诩");

--					ModuleBianlunServerLogic.SetPlayerInfo(0, 19, "田丰");
--					ModuleBianlunServerLogic.SetPlayerInfo(0, 28, "陆逊");
--					ModuleBianlunServerLogic.SetPlayerInfo(0, 35, "诸葛亮");

--					ModuleBianlunServerLogic.SetPlayerInfo(0, 25, "孙权");
--					ModuleBianlunServerLogic.SetPlayerInfo(0, 31, "司马懿");


--					ModuleBianlunServerLogic.SetPlayerInfo(0, 27, "周瑜");
					ModuleBianlunServerLogic.SetPlayerInfo(0, 30, "曹操");
--					ModuleBianlunServerLogic.SetPlayerInfo(0, 32, "郭嘉");

					--	Player 1
--					ModuleBianlunServerLogic.SetPlayerInfo(1, 1, "郭嘉");
					ModuleBianlunServerLogic.SetPlayerInfo(1, 1, "吕布");
--]]
					
					ModuleBianlunServerLogic.SetCurrentPlayer(0, 0);
					ModuleBianlunServerLogic.SetCurrentPlayer(1, 0);

					--	广播通知
					serverLogic:network_server_notifyPlayerInfo();

					ModuleBianlunServerLogic.WaitTimeout();

					logicState 	= ModuleBianlunServerLogic.ServerLogicState_LunBo;

			elseif	logicState  ==	ModuleBianlunServerLogic.ServerLogicState_LunBo 		then		
					ModuleBianlunServerLogic.Log("\n##	模块辩论--论驳牌测定 ##\n");

					--	获取论驳
					ModuleBianlunServerLogic.Process_LunBo();

					ModuleBianlunServerLogic.WaitTimeout();

					logicState 	= ModuleBianlunServerLogic.ServerLogicState_FaPai;

			elseif 	logicState 	== 	ModuleBianlunServerLogic.ServerLogicState_FaPai 		then
					ModuleBianlunServerLogic.Log("\n##	模块辩论--发牌 	##\n");

					--	服务器发牌
					ModuleBianlunServerLogic.Process_FaPai();

					ModuleBianlunServerLogic.WaitTimeout();


					--	游戏一轮次开始之前的处理 

					ModuleBianlunServerLogic.BeforeRoundStart();

					logicState 	=	ModuleBianlunServerLogic.ServerLogicState_GameLoop_Start;

			elseif	logicState  ==  ModuleBianlunServerLogic.ServerLogicState_GameLoop_Start 		then
					ModuleBianlunServerLogic.Log("\n##	模块辩论--回合开始 ##\n");

					logicState 	= 	ModuleBianlunServerLogic.ServerLogicState_GameLoop_XianHouShou;

			elseif 	logicState  ==	ModuleBianlunServerLogic.ServerLogicState_GameLoop_XianHouShou 	then
					ModuleBianlunServerLogic.Log("\n## 	模块辩论--先后手通知 ##\n");

					--	广播通知先后手
					serverLogic:network_server_notifyXianhou();

					ModuleBianlunServerLogic.WaitTimeout()

					logicState 	= 	ModuleBianlunServerLogic.ServerLogicState_GameLoop_XianShou;


			elseif 	logicState 	==	ModuleBianlunServerLogic.ServerLogicState_GameLoop_XianShou 	then
					ModuleBianlunServerLogic.Log("\n##	模块辩论--先手出牌	##\n");

					--	英雄技能操作前处理
					local 	_msg = ModuleBianlunServerLogic.BeforeOperation(serverLogic:getOutputPosition());

					if 		_msg ~= "Outputed" 	then

							ModuleBianlunServerLogic.Log("技能逻辑未导致出牌事件");

							--	逻辑打断技能处理
							local 	selfpos 	= serverLogic:getOutputPosition();
							local 	otherpos 	= 1 - selfpos;
							local   selfOutputSize = serverLogic:getPlayerOutputCardSize(selfpos);

							if 		selfOutputSize ~= 0  then
									--	在技能逻辑期间执行了逻辑操作

									ModuleBianlunServerLogic.Log("在技能逻辑期间执行了逻辑操作");

									if 		selfOutputSize == 1 then
											ModuleBianlunServerLogic.Log("单牌");

											local 	card = serverLogic:getPlayerOutputCard(selfpos, 0);
											ModuleBianlunServerLogic.Log("出牌:"..card:dumpCard());	

											serverLogic:acceptPlayerOutputEvent(selfpos);

											logicState = ModuleBianlunServerLogic.ServerLogicState_GameLoop_HouShou;

									else
											ModuleBianlunServerLogic.Log("非单牌");
											serverLogic:refusePlayerOutputEvent(selfpos, "只能出一张牌");

											local 	waitTime = ModuleBianlunServerLogic.ServerLogicWaitTime;
											while 	true 	do
													local 	_state, _pos, _type = ModuleBianlunServerLogic.Wait(waitTime);
													if 		_state ==	"Timeout" 	then
															ModuleBianlunServerLogic.Log("WARNING@Lua: 超时, 先手");
															ModuleBianlunServerLogic.OutputTimeOut(serverLogic:getOutputPosition(), 1);

															ModuleBianlunServerLogic.WaitTimeout(0.5);

															do  break end
													elseif 	_state == 	"MessageArrive"		then
															if 	_pos == serverLogic:getOutputPosition() then

																if 		_type == "Logic" 	then
																		ModuleBianlunServerLogic.Log("先手出牌消息到来"..tostring(_pos)..tostring(_type));
																		local 	size = serverLogic:getPlayerOutputCardSize(_pos);
																		if 		size ==  1 	then
																				ModuleBianlunServerLogic.Log("单牌");

																				local 	card = serverLogic:getPlayerOutputCard(_pos, 0);
																				ModuleBianlunServerLogic.Log("出牌:"..card:dumpCard());	

																				serverLogic:acceptPlayerOutputEvent(serverLogic:getOutputPosition());

																				ModuleBianlunServerLogic.WaitTimeout(0.5);
																				do break end
																		else
																				ModuleBianlunServerLogic.Log("非单牌");
																				serverLogic:refusePlayerOutputEvent(serverLogic:getOutputPosition(), "只能出一张牌");
																		end
																elseif 	_type == "Skill" 	then

																		--	递减时间
																		waitTime = waitTime - 1;
																end
															end
													elseif 	_state == "Gameover" then
															do break end
													end
											end	
											logicState  = 	ModuleBianlunServerLogic.ServerLogicState_GameLoop_HouShou;
									end
							else
									--	在技能逻辑期间没有执行了逻辑操作

									ModuleBianlunServerLogic.Log("在技能逻辑期间没有执行了逻辑操作");

									local 	waitTime  = ModuleBianlunServerLogic.ServerLogicWaitTime;
									while 	true 	do
											local 	_state, _pos, _type = ModuleBianlunServerLogic.Wait(waitTime);
											if 		_state ==	"Timeout" 	then
													ModuleBianlunServerLogic.Log("WARNING@Lua: 超时, 先手");
													ModuleBianlunServerLogic.OutputTimeOut(serverLogic:getOutputPosition(), 1);

													ModuleBianlunServerLogic.WaitTimeout(0.5);

													do  break end
											elseif 	_state == 	"MessageArrive"		then
													if 	_pos == serverLogic:getOutputPosition() and _type == "Logic" 	then
														ModuleBianlunServerLogic.Log("先手出牌消息到来"..tostring(_pos)..tostring(_type));
														local 	size = serverLogic:getPlayerOutputCardSize(_pos);
														if 		size ==  1 	then
																ModuleBianlunServerLogic.Log("单牌");

																local 	card = serverLogic:getPlayerOutputCard(_pos, 0);
																ModuleBianlunServerLogic.Log("出牌:"..card:dumpCard());	

																serverLogic:acceptPlayerOutputEvent(serverLogic:getOutputPosition());

																ModuleBianlunServerLogic.WaitTimeout(0.5);
																do break end
														else
																ModuleBianlunServerLogic.Log("非单牌");
																serverLogic:refusePlayerOutputEvent(serverLogic:getOutputPosition(), "只能出一张牌");
														end
													end
											elseif 	_state == "Gameover" then
													do break end
											end
									end
									logicState  = 	ModuleBianlunServerLogic.ServerLogicState_GameLoop_HouShou;
							end

					else

						ModuleBianlunServerLogic.Log("技能逻辑导致出牌事件");

						logicState 	= ModuleBianlunServerLogic.ServerLogicState_GameLoop_HouShou;
					end 

			elseif	logicState  ==	ModuleBianlunServerLogic.ServerLogicState_GameLoop_HouShou 		then
					ModuleBianlunServerLogic.Log("\n## 	模块辩论--后手出牌	##\n");

					serverLogic:invertOutputPosition();

					local  	_msg = ModuleBianlunServerLogic.BeforeOperation(serverLogic:getOutputPosition());
					
					if 		_msg ~= "Outputed"	then

							ModuleBianlunServerLogic.Log("技能逻辑未导致出牌事件");

							--	流程逻辑打断技能逻辑的处理

							local 	selfpos  = serverLogic:getOutputPosition();
							local 	otherpos = 1 - selfpos;
							local 	otherOutputSize 		= serverLogic:getPlayerPreOutputCardSize(otherpos);
							local 	selfCurrentOutputSize	= serverLogic:getPlayerOutputCardSize(selfpos);

							if 		selfCurrentOutputSize ~=  0 then
									--	技能逻辑被流程逻辑打断
									ModuleBianlunServerLogic.Log("技能逻辑被流程逻辑打断");

									if 		selfCurrentOutputSize ==  	otherOutputSize 	then

											ModuleBianlunServerLogic.Log("双方出牌量一致");

											serverLogic:acceptPlayerOutputEvent(selfpos); 

											logicState = ModuleBianlunServerLogic.ServerLogicState_GameLoop_JueSheng;

									elseif 	selfCurrentOutputSize ~= 	otherOutputSize 	then
											ModuleBianlunServerLogic.Log("双发出牌量不一致,提醒后手出等量牌");

											serverLogic:refusePlayerOutputEvent(selfpos, "请出与对方等量的牌");

											local 	waitTime = ModuleBianlunServerLogic.ServerLogicWaitTime;
											while 	true 	do
													local 	_state, _pos, _type = ModuleBianlunServerLogic.Wait(waitTime);
													if 		_state == "Timeout"			then
															ModuleBianlunServerLogic.Log("WARNING, 超时, 后手");

															ModuleBianlunServerLogic.OutputTimeOut(selfpos, otherOutputSize);

															logicState = ModuleBianlunServerLogic.ServerLogicState_GameLoop_JueSheng;

															ModuleBianlunServerLogic.WaitTimeout(0.5);

															do break end
													elseif 	_state == "MessageArrive"	then

															if 	_pos == selfpos then

																if 		_type 	== "Logic" 	then

																		local 	selfOutputSize = serverLogic:getPlayerOutputCardSize(selfpos);
																		if 		selfOutputSize == otherOutputSize then

																				serverLogic:acceptPlayerOutputEvent(selfpos);
																				logicState = ModuleBianlunServerLogic.ServerLogicState_GameLoop_JueSheng;

																				ModuleBianlunServerLogic.WaitTimeout(0.5);
																				do break end
																		else
																				serverLogic:refusePlayerOutputEvent(selfpos, "请出与对方等量的牌");
																		end

																elseif 	_state 	== "Skill"	then

																		waitTime = waitTime - 1;
																else
																end
															end
													elseif	_state == "Gameover" 		then
													else
													end

													--	No New State Setting Here
											end
											--	No New State Setting Here
									end
							else
									--	技能逻辑未被流程逻辑打断
									ModuleBianlunServerLogic.Log("技能逻辑未被流程逻辑打断");

									local 	waitTime = ModuleBianlunServerLogic.ServerLogicWaitTime;
									while 	true 	do
											local 	_state, _pos, _type = ModuleBianlunServerLogic.Wait(waitTime);
											if 		_state == "Timeout"			then
													ModuleBianlunServerLogic.Log("WARNING, 超时, 后手");

													ModuleBianlunServerLogic.OutputTimeOut(selfpos, otherOutputSize);

													logicState = ModuleBianlunServerLogic.ServerLogicState_GameLoop_JueSheng;

													ModuleBianlunServerLogic.WaitTimeout(0.5);

													do break end
											elseif 	_state == "MessageArrive"	then

													if 	_pos == selfpos then

														if 		_type 	== "Logic" 	then

																local 	selfOutputSize = serverLogic:getPlayerOutputCardSize(selfpos);
																if 		selfOutputSize == otherOutputSize then

																		serverLogic:acceptPlayerOutputEvent(selfpos);
																		logicState = ModuleBianlunServerLogic.ServerLogicState_GameLoop_JueSheng;

																		ModuleBianlunServerLogic.WaitTimeout(0.5);
																		do break end
																else
																		serverLogic:refusePlayerOutputEvent(selfpos, "请出与对方等量的牌");
																end

														elseif 	_state 	== "Skill"	then

																waitTime = waitTime - 1;
														else
														end
													end
											elseif	_state == "Gameover" 		then
													do break end
											else
											end
									end
							end
					else
							
							ModuleBianlunServerLogic.Log("技能逻辑导致出牌事件");
							
							local 	selfpos  = serverLogic:getOutputPosition();
							local 	otherpos = 1 - selfpos;
							local 	otherOutputSize 	= serverLogic:getPlayerPreOutputCardSize(otherpos);

							local 	selfOutputSize  	= serverLogic:getPlayerOutputCardSize(selfpos);
							local 	selfPreOutputSize	= serverLogic:getPlayerPreOutputCardSize(selfpos);

							ModuleBianlunServerLogic.Log(tostring(selfOutputSize)..' vs. '..tostring(selfPreOutputSize));
							
							if 		selfPreOutputSize  < 	otherOutputSize 	then

									--	补牌
									serverLogic:network_server_notifyPlayerTip(selfpos, "请出与对方等量的牌");
									serverLogic:refusePlayerOutputEvent(selfpos);

									local 	waitTime = ModuleBianlunServerLogic.ServerLogicWaitTime;
									while 	true 	do
											local 	_state, _pos, _type = ModuleBianlunServerLogic.Wait(waitTime);
											if 		_state == "Timeout"			then
													ModuleBianlunServerLogic.Log("WARNING, 超时, 后手");

													ModuleBianlunServerLogic.OutputTimeOut(selfpos, otherOutputSize - selfPreOutputSize );

													logicState = ModuleBianlunServerLogic.ServerLogicState_GameLoop_JueSheng;

													ModuleBianlunServerLogic.WaitTimeout(0.5);

													do break end
											elseif 	_state == "MessageArrive"	then

													if 	_pos == selfpos then

														if 		_type 	== "Logic" 	then

																if 		selfOutputSize + selfPreOutputSize == otherOutputSize then

																		serverLogic:acceptPlayerOutputEvent(selfpos);

																		logicState = ModuleBianlunServerLogic.ServerLogicState_GameLoop_JueSheng;

																		ModuleBianlunServerLogic.WaitTimeout(0.5);
																		do break end
																else
																		serverLogic:refusePlayerOutputEvent(selfpos, "请出与对方等量的牌");
																end

														elseif 	_state 	== "Skill"	then

																waitTime = waitTime - 1;
														else
														end

													end
											elseif	_state == "Gameover" 		then
													do break end
											else
											end
									end

									

							elseif	selfPreOutputSize  == 	otherOutputSize 	then

									--	决胜
									logicState = ModuleBianlunServerLogic.ServerLogicState_GameLoop_JueSheng;

							else
									--	对方补牌
									logicState = ModuleBianlunServerLogic.ServerLogicState_GameLoop_XianShouBupai;

							end
					end

			elseif	logicState 	== ModuleBianlunServerLogic.ServerLogicState_GameLoop_XianShouBupai 	then
					ModuleBianlunServerLogic.Log("\n##	模块辩论--先手补牌\n");

					serverLogic:invertOutputPosition();

					local 	selfpos  = serverLogic:getOutputPosition();
					local 	otherpos = 1 - selfpos;
					local 	otherOutputSize = serverLogic:getPlayerPreOutputCardSize(otherpos);
					

					local 	waitTime = ModuleBianlunServerLogic.ServerLogicWaitTime;
					while 	true do 
							local 	_state, _pos, _type = ModuleBianlunServerLogic.Wait(waitTime);
							if 		_state == "Timeout"			then
									ModuleBianlunServerLogic.Log("先手补牌超时");

									local 	selfPreOutputSize = serverLogic:getPlayerPreOutputCardSize(selfpos);

									ModuleBianlunServerLogic.OutputTimeOut(selfpos, otherOutputSize - selfPreOutputSize);

									logicState = ModuleBianlunServerLogic.ServerLogicState_GameLoop_JueSheng;

									ModuleBianlunServerLogic.WaitTimeout(0.5);

									do break end

							elseif	_state == "MessageArrive"	then
									if 	_pos == selfpos and _type == "Logic"	then
										ModuleBianlunServerLogic.Log("先手补牌消息到来");

										local 	selfOutputSize 		= serverLogic:getPlayerOutputCardSize 	(selfpos);
										local 	selfPreOutputSize	= serverLogic:getPlayerPreOutputCardSize(selfpos);

										if 		selfPreOutputSize + selfOutputSize ~= otherOutputSize then

--												serverLogic:network_server_notifyPlayerTip(selfpos, "请补充适量的出牌，以保证和对方牌量相等");
												serverLogic:refusePlayerOutputEvent(selfpos, "请补充适量的出牌，以保证和对方牌量相等");
										else
												serverLogic:acceptPlayerOutputEvent(selfpos);

												ModuleBianlunServerLogic.WaitTimeout(0.5);

												logicState = ModuleBianlunServerLogic.ServerLogicState_GameLoop_JueSheng;
										end


									end
							elseif	_state == "Gameover"		then
									do break end
							else
							end
					end

			elseif	logicState 	==	ModuleBianlunServerLogic.ServerLogicState_GameLoop_JueSheng 	then
					ModuleBianlunServerLogic.Log("\n## 	模块辩论--回合决胜	###\n");

					serverLogic:network_server_notifyPlayerShowOutputCards();

					ModuleBianlunServerLogic.AfterShowOutputCard();

					--	播放回合对决动画
					serverLogic:network_server_broadCastCompareAnimationEffect(0);

					logicState = ModuleBianlunServerLogic.DetermineVictory();

					ModuleBianlunServerLogic.WaitTimeout(ModuleBianlunServerLogic.ServerLogicWaitTime);

					serverLogic:invertOutputPosition();
			elseif  logicState 	==  ModuleBianlunServerLogic.ServerLogicState_GameLoop_End 	then
					ModuleBianlunServerLogic.Log("\n##	模块辩论--回合结束##\n");
					
					--	回合结束先进行本回合胜负的判定处理
					do
						serverLogic:network_server_notifyPlayerHideOutputCards();
					
						if 		ModuleBianlunServerLogic.ServerLogicTurnWinnerPosition ~= nil then

								local 	winnerPosition 	= ModuleBianlunServerLogic.ServerLogicTurnWinnerPosition;
								local 	losserPosition = 1 - winnerPosition;
								--	胜者处理
								ModuleBianlunServerLogic.Log("胜者处理");
								local 	bWinnerForceLosserFail;
								local 	bLosserForceWinnerFail;

								bWinnerForceLosserFail =  ModuleBianlunServerLogic.AfterCompareWithWinner(winnerPosition);

								if 	  	bWinnerForceLosserFail == true then
									  	--	赢家技能导致对方判负

									  	serverLogic:setBianlunOver(true, winnerPosition);

										if 	serverLogic:switchPlayer(losserPosition) == false then
											logicState =  ModuleBianlunServerLogic.ServerLogicState_Gameover;

											--	通知辩论结束模块的奖惩信息
											ModuleBianlunServerLogic.NotifyPlayerGameResultAward( winnerPosition );


										else
											serverLogic:doRoundClean();
											serverLogic:invertRoundFirstOutputPosition();

											--	Update Player Skill
											ModuleBianlunServerLogic.UpdatePlayerSkill(losserPosition);

											logicState =  ModuleBianlunServerLogic.ServerLogicState_FaPai;
										end								
								end

								ModuleBianlunServerLogic.Log(tostring(bWinnerForceLosserFail));

								ModuleBianlunServerLogic.Log("胜者处理完成");
								
								--	败者处理
								ModuleBianlunServerLogic.Log("败者处理");
								bLosserForceWinnerFail  = ModuleBianlunServerLogic.AfterCompareWithLosser(losserPosition);

								if 		bLosserForceWinnerFail 	== true then
										--	败者技能导致对方判负
--										ModuleBianlunServerLogic.Log("4");
										serverLogic:setBianlunOver(true, losserPosition);

--										ModuleBianlunServerLogic.Log("1");

										if 	serverLogic:switchPlayer(winnerPosition) == false 	then
											ModuleBianlunServerLogic.Log("2");

											logicState =  ModuleBianlunServerLogic.ServerLogicState_Gameover;

											--	通知辩论结束模块的奖惩信息
											ModuleBianlunServerLogic.NotifyPlayerGameResultAward( losserPosition );
										else
											serverLogic:doRoundClean();
											serverLogic:invertRoundFirstOutputPosition();

											--	Update Player Skill
											ModuleBianlunServerLogic.UpdatePlayerSkill(winnerPosition);

											logicState =  ModuleBianlunServerLogic.ServerLogicState_FaPai;
										end
								end

								ModuleBianlunServerLogic.Log(tostring(bLosserForceWinnerFail));

								ModuleBianlunServerLogic.Log("败者处理完成");

								ModuleBianlunServerLogic.Log(tostring(bWinnerForceLosserFail).."vs."..tostring(bLosserForceWinnerFail));

								if 	bWinnerForceLosserFail == false and bLosserForceWinnerFail == false then

									ModuleBianlunServerLogic.Log("回合胜者处理");

									local 	winnerPosition = ModuleBianlunServerLogic.ServerLogicTurnWinnerPosition;

									ModuleBianlunServerLogic.Log("本回合胜利方: "..tostring(winnerPosition).."补牌");
									
									local  	card = serverLogic:getNextCard();

									--	搜索闲置Tag
									local  	tag  = -1;
									tag 	=	serverLogic:getPlayerHandCardFreeTag(winnerPosition);
									card:setTag(tag);

	--								ModuleBianlunServerLogic.Log(tostring(tag));
	--								ModuleBianlunServerLogic.Log(card:dumpCard())
									
									serverLogic:appendPlayerHandCard(winnerPosition, card);
									serverLogic:network_server_notifyRemainPlayerHandCards(winnerPosition);	

									ModuleBianlunServerLogic.ServerLogicTurnWinnerPosition = nil;	
									ModuleBianlunServerLogic.Log("\n########################################################");
									ModuleBianlunServerLogic.Log("赢家补牌："..tostring(card:dumpCard()));
									ModuleBianlunServerLogic.Log("现在双方牌量：");
									ModuleBianlunServerLogic.Log("位置0："..tostring(serverLogic:getPlayerHandCardSize(0)));
									ModuleBianlunServerLogic.Log("位置1："..tostring(serverLogic:getPlayerHandCardSize(1)));
									ModuleBianlunServerLogic.Log("\n########################################################");

								--	serverLogic:doTurnClean();
								--	serverLogic:invertTurnFirstOutputPosition();
								--	logicState = ModuleBianlunServerLogic.ServerLogicState_GameLoop_Start;

								end
						else
							--	serverLogic:doTurnClean();
							--	serverLogic:invertTurnFirstOutputPosition();
							--	logicState = ModuleBianlunServerLogic.ServerLogicState_GameLoop_Start;								
						end
					end

					local 	handCards0 = serverLogic:getPlayerHandCardSize(0);
					local 	handCards1 = serverLogic:getPlayerHandCardSize(1);

					if  	handCards0 == 0 or handCards1 == 0 then
							if 		handCards0 == handCards1 then
									--	双方都无牌可出
									--  开启新一轮
									serverLogic:network_server_notifyPlayerHideOutputCards();

									serverLogic:doRoundClean();
									serverLogic:invertRoundFirstOutputPosition();

									logicState = ModuleBianlunServerLogic.ServerLogicState_FaPai;

							else
									local 	winner = nil;
									local 	losser = nil;
									if 	handCards0 ==  0 then
										ModuleBianlunServerLogic.Log("本局胜者位：1");
										
										winner = 1;
										losser = 0;
									else
										ModuleBianlunServerLogic.Log("本局胜者位: 0");
										
										winner = 0;
										losser = 1;
									end

									serverLogic:setBianlunOver(true, winner);

									if 	serverLogic:switchPlayer(losser) == false then
										
										logicState = ModuleBianlunServerLogic.ServerLogicState_Gameover;

										--	通知辩论结束模块的奖惩信息
										ModuleBianlunServerLogic.NotifyPlayerGameResultAward( winner );
									else

										serverLogic:doRoundClean();
										serverLogic:invertRoundFirstOutputPosition();

										--	Player Skill Update
										ModuleBianlunServerLogic.UpdatePlayerSkill(losser);
										
										logicState = ModuleBianlunServerLogic.ServerLogicState_FaPai;
									end
							end
					else
						serverLogic:network_server_notifyPlayerHideOutputCards();
					
						if 		ModuleBianlunServerLogic.ServerLogicTurnWinnerPosition ~= nil then
							--[[	
								local 	winnerPosition 	= ModuleBianlunServerLogic.ServerLogicTurnWinnerPosition;
								local 	losserPosition = 1 - winnerPosition;
								--	胜者处理
								ModuleBianlunServerLogic.Log("胜者处理");
								local 	bWinnerForceLosserFail;
								local 	bLosserForceWinnerFail;

								bWinnerForceLosserFail =  ModuleBianlunServerLogic.AfterCompareWithWinner(winnerPosition);

								if 	  	bWinnerForceLosserFail == true then
									  	--	赢家技能导致对方判负

									  	serverLogic:setBianlunOver(true, winnerPosition);

										if 	serverLogic:switchPlayer(losserPosition) == false then
											logicState =  ModuleBianlunServerLogic.ServerLogicState_Gameover;
										else
											serverLogic:doRoundClean();
											serverLogic:invertRoundFirstOutputPosition();

											--	Update Player Skill
											ModuleBianlunServerLogic.UpdatePlayerSkill(losserPosition);

											logicState =  ModuleBianlunServerLogic.ServerLogicState_FaPai;
										end								
								end

								ModuleBianlunServerLogic.Log(tostring(bWinnerForceLosserFail));

								ModuleBianlunServerLogic.Log("胜者处理完成");
								
								--	败者处理
								ModuleBianlunServerLogic.Log("败者处理");
								bLosserForceWinnerFail  = ModuleBianlunServerLogic.AfterCompareWithLosser(losserPosition);
							
								if 		bLosserForceWinnerFail 	== true then
										--	败者技能导致对方判负
--										ModuleBianlunServerLogic.Log("4");
										serverLogic:setBianlunOver(true, losserPosition);

--										ModuleBianlunServerLogic.Log("1");

										if 	serverLogic:switchPlayer(winnerPosition) == false 	then
											ModuleBianlunServerLogic.Log("2");

											logicState =  ModuleBianlunServerLogic.ServerLogicState_Gameover;
										else
											serverLogic:doRoundClean();
											serverLogic:invertRoundFirstOutputPosition();

											--	Update Player Skill
											ModuleBianlunServerLogic.UpdatePlayerSkill(winnerPosition);

											logicState =  ModuleBianlunServerLogic.ServerLogicState_FaPai;
										end
								end

								ModuleBianlunServerLogic.Log(tostring(bLosserForceWinnerFail));

								ModuleBianlunServerLogic.Log("败者处理完成");

								ModuleBianlunServerLogic.Log(tostring(bWinnerForceLosserFail).."vs."..tostring(bLosserForceWinnerFail));
							--]]
								if 	bWinnerForceLosserFail == false and bLosserForceWinnerFail == false then
								--[[
									ModuleBianlunServerLogic.Log("回合胜者处理");

									local 	winnerPosition = ModuleBianlunServerLogic.ServerLogicTurnWinnerPosition;

									ModuleBianlunServerLogic.Log("本回合胜利方: "..tostring(winnerPosition).."补牌");
									
									local  	card = serverLogic:getNextCard();

									--	搜索闲置Tag
									local  	tag  = -1;
									tag 	=	serverLogic:getPlayerHandCardFreeTag(winnerPosition);
									card:setTag(tag);

	--								ModuleBianlunServerLogic.Log(tostring(tag));
	--								ModuleBianlunServerLogic.Log(card:dumpCard())
									
									serverLogic:appendPlayerHandCard(winnerPosition, card);
									serverLogic:network_server_notifyRemainPlayerHandCards(winnerPosition);	

									ModuleBianlunServerLogic.ServerLogicTurnWinnerPosition = nil;	
									ModuleBianlunServerLogic.Log("\n########################################################");
									ModuleBianlunServerLogic.Log("赢家补牌："..tostring(card:dumpCard()));
									ModuleBianlunServerLogic.Log("现在双方牌量：");
									ModuleBianlunServerLogic.Log("位置0："..tostring(serverLogic:getPlayerHandCardSize(0)));
									ModuleBianlunServerLogic.Log("位置1："..tostring(serverLogic:getPlayerHandCardSize(1)));
									ModuleBianlunServerLogic.Log("\n########################################################");
								--]]
									serverLogic:doTurnClean();
									serverLogic:invertTurnFirstOutputPosition();
									logicState = ModuleBianlunServerLogic.ServerLogicState_GameLoop_Start;

								end
						else
							
								serverLogic:doTurnClean();
								serverLogic:invertTurnFirstOutputPosition();
								logicState = ModuleBianlunServerLogic.ServerLogicState_GameLoop_Start;								
							
						end


					end

--					serverLogic:Stop();

--					logicState =	ModuleBianlunServerLogic.ServerLogicState_Gameover; 

			elseif 	logicState 	==	ModuleBianlunServerLogic.ServerLogicState_Gameover 		then
					do  	break	end
			else
					do  	break   end
			end

			ModuleBianlunServerLogic.SetServerLogicState(logicState);
	end


	--	Game Over Cleanup
	if 	ModuleBianlunServerLogic.ServerLogic_WaitHandle	 ~= nil	then
		cc.Director:getInstance():getScheduler():unscheduleScriptEntry(ModuleBianlunServerLogic.ServerLogic_WaitHandle);
		ModuleBianlunServerLogic.ServerLogic_WaitHandle  = nil;
	end

	if 	ModuleBianlunServerLogic.ServerLogicHandle 		~= nil then
		ModuleBianlunServerLogic.ServerLogicHandle 		= nil;
	end


	serverLogic:network_server_forcePlayerLeave(0);

	ModuleBianlunServerLogic.Log("ServerLogic Over !");
end





--	Pre Start Server Logic
function ModuleBianlunServerLogic.PreStartServerLogic( ... )
	-- body

	--	Server Script Contex Cleanup
	do
		ModuleBianlunServerLogic.ServerLogicState 			= nil;				--	服务器逻辑状态
		ModuleBianlunServerLogic.ServerLogicHandle			= nil;				--	服务器逻辑流程句柄
		ModuleBianlunServerLogic.ServerLogic_WaitHandle		= nil;				--	服务器等待句柄


		--	服务器逻辑数据
	--	ServerLogicWaitTime 		= 5;				--	服务器逻辑等待时间
		ModuleBianlunServerLogic.ServerLogicTurnWinnerPosition 	= nil;			--  单回合胜者位
		ModuleBianlunServerLogic.ServerLogicGameover 			= false;			--	服务器逻辑结束标志

		--	Server Logic Data
		ModuleBianlunServerLogic.ServerLogic_PlayerHandCards 		= {0, 0};	--	对战双方当前手中牌最大数量， Max -- 6

		--	Hero Skill Data
		ModuleBianlunServerLogic.HeroSkill_zhenmi_shishi_flag 			= {0, 0};	--	甄宓技能识时, 		Hero Clean
		ModuleBianlunServerLogic.HeroSkill_zhenmi_lingsheji_flag			= {0, 0};	--	甄宓技能灵蛇髻,  	No   Clean
		ModuleBianlunServerLogic.HeroSkill_luxun_shuifu_time 			= {0, 0};	--	陆逊技能说服, 		Hero Clean
		ModuleBianlunServerLogic.HeroSkill_zhugeliang_jijiangfa_time 	= {0, 0};	--	诸葛亮技能激将法, 	Hero Clean
		ModuleBianlunServerLogic.HeroSkill_zhouyu_guibian_time 			= {0, 0};	--	周瑜诡辩技能次数,   Hero Clean 
		ModuleBianlunServerLogic.HeroSkill_caocao_nuze_time 				= {0, 0};	--	曹操怒责技能次数, 	Hero Clean


		--	Skill Result Output Ordering Modified
		ModuleBianlunServerLogic.ServerLogic_CurrentOutputPosition 		= nil;		--	服务器端逻辑出牌位
	end

	--	Server C++  Cleanup
	local 	serverLogic = CModuleBianlunServerLogic:sharedServerLogic();
	serverLogic:resetServerLogicContext();
end

------------------------------------------------------------------------------------------------------------------------------------
--	Exported Interface
--	辩论模块接口

function ModuleBianlunServerLogic.SetPlayerInfo( pos, id, name )
	-- body

	local 	serverLogic = CModuleBianlunServerLogic:sharedServerLogic();
	serverLogic:setPlayerInfo(pos, id, name);
end

function ModuleBianlunServerLogic.SetCurrentPlayer( pos, index )
	-- body

	local 	serverLogic  = CModuleBianlunServerLogic:sharedServerLogic();
	serverLogic:setCurrentPlayer(pos, index);

	ModuleBianlunServerLogic.UpdatePlayerSkill(pos);
end

function ModuleBianlunServerLogic.UpdatePlayerSkill( pos )
	-- body
	ModuleBianlunServerLogic.Log("更新位置 "..tostring(pos).." 的技能");
	local 	serverLogic = CModuleBianlunServerLogic:sharedServerLogic();
	local 	skillCount = nil;
	local 	playerName = serverLogic:getPlayerName(pos);

	skillCount = ModuleBianlunSkill.GetHeroInfo(playerName, "SkillCount");

	serverLogic:network_server_notifyPlayerSkillCount(pos, skillCount);

	for 	i = 1, skillCount do
			local 	skill = ModuleBianlunSkill.GetHeroInfo(playerName, "Skill", i);

			ModuleBianlunServerLogic.Log("位置 "..tostring(pos).." 英雄 "..tostring(playerName).." 技能 "..tostring(skill));

			serverLogic:network_server_notifyPlayerSkill(pos, i, skill);
	end
end


function ModuleBianlunServerLogic.CheckPlayerSkill(pos, bSelf, index )
	-- body

	local 	serverLogic = CModuleBianlunServerLogic:sharedServerLogic();
	local 	skillCount = nil;

	local 	playerName = nil;

	if 		bSelf == true then
			playerName =	serverLogic:getPlayerName(pos);
	else
			playerName = 	serverLogic:getPlayerName(1 - pos);
	end

	skillCount = ModuleBianlunSkill.GetHeroInfo(playerName, "SkillCount");

	serverLogic:network_server_notifyPlayerSkillCount(pos, skillCount);

	local 	skill 		= nil;
	local 	skillInfo 	= nil;

	for 	i = 1, skillCount do 
			if 	i  == index then
				skill 	= ModuleBianlunSkill.GetHeroInfo(playerName, "Skill", i);
				do 	break end
			end
	end

	for 	v 	in pairs(itemConfig) do 
			if 	itemConfig[v].name == skill then
				skillInfo = itemConfig[v].intro;
			end
	end

	serverLogic:network_server_notifyPlayerTip(pos, skillInfo);

end

function ModuleBianlunServerLogic.UpdateServerLogicWaitTime( time )
	-- body

	ModuleBianlunServerLogic.ServerLogicWaitTime 	= time;
	if 	ModuleBianlunServerLogic.ServerLogicWaitTime < 1.0 then
		ModuleBianlunServerLogic.ServerLogicWaitTime = 1.0
	end
end


function ModuleBianlunServerLogic.HandlePlayerAccelerate( ... )
	-- body
	ModuleBianlunServerLogic.UpdateServerLogicWaitTime(ModuleBianlunServerLogic.ServerLogicWaitTime * 0.5);

end

function ModuleBianlunServerLogic.SetChallenger( pos )
	-- body

	local 	serverLogic = CModuleBianlunServerLogic:sharedServerLogic();
	serverLogic:setChallenger(pos)
end

function ModuleBianlunServerLogic.SetPlayerHandCardSize( pos, size )
	-- body

--	ModuleBianlunServerLogic.Log("设定位置 "..tostring(pos).." 手中牌数量 "..tostring(size));

	if 		pos <= 1 then
			ModuleBianlunServerLogic.ServerLogic_PlayerHandCards[1] = size;
	else
			ModuleBianlunServerLogic.ServerLogic_PlayerHandCards[2] = size;
	end
end

function ModuleBianlunServerLogic.GetPlayerHandCardSize( pos )
	-- body

	if 		pos <= 1 then
			return ModuleBianlunServerLogic.ServerLogic_PlayerHandCards[1];
	else
			return ModuleBianlunServerLogic.ServerLogic_PlayerHandCards[2];
	end
end

--	Start Server Logic
function ModuleBianlunServerLogic.StartServerLogic( ... )
	-- body

	--	Reset Server Scrpt && C++ Context 
--	ModuleBianlunServerLogic.PreStartServerLogic();

	--	ServerLogic State
	ModuleBianlunServerLogic.SetServerLogicState(ModuleBianlunServerLogic.ServerLogicState_Start);

	--	AI 控制
	ModuleBianlunSkill.SetAIControl(true);

	--	ServerLogic Coroutine
	ModuleBianlunServerLogic.ServerLogicHandle	= coroutine.create(ModuleBianlunServerLogic.Coroutine_ServerLogic);
	coroutine.resume(ModuleBianlunServerLogic.ServerLogicHandle);


end

--	Stop Server Logic
function ModuleBianlunServerLogic.StopServerLogic( ... )
	-- body

	-- 	ServerLogic Gameover State Setting
	ModuleBianlunServerLogic.ServerLogicGameover = true;

	--	If Current ServerLogic State is suspended Resume ServerLogic With Gameover Notification
	if 	ModuleBianlunServerLogic.ServerLogicHandle  ~= nil then
		if 	coroutine.status(ModuleBianlunServerLogic.ServerLogicHandle) == "suspended" then
			ModuleBianlunServerLogic.GameoverStopWait();
		end
	end
end


----------------------------------------------------------------------------------------------------------------
--	辩论胜负确定后续处理 
--	辩论结算处理

function ModuleBianlunServerLogic.NotifyPlayerGameResultAward( nWinner )
	-- body

	print(tostring(nWinner));

	local 	serverLogic 	= CModuleBianlunServerLogic:sharedServerLogic();

	--	通知辩论武将
	serverLogic:network_server_notifyPlayerGameResultPlayerList();
	--	通知胜负
	serverLogic:network_server_notifyPlayerGameResult(nWinner);
	--	通知道具奖惩
	local 	builder 		= GameDaoJuListBuilder:new();
	builder:appendDaoJu(11501);
	builder:appendDaoJu(11502);
	builder:appendDaoJu(11503);

	serverLogic:network_server_notifyPlayerGameResultWinnerAward(nWinner,     100, 100, 100, 100, 100, tolua.cast(builder:getDaoJuList(), "GameDaoJuList"));
	serverLogic:network_server_notifyPlayerGameResultLosserAward(1 - nWinner, 100, 100, 100, 100);
end