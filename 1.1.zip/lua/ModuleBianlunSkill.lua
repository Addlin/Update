--	Date:	2013/11/7
--	Author:	zhaozl
--	Brief:	Module Bianlun Skill

require "ModuleBianlunAI"


local 	icon = ".png";

ModuleBianlunSkill = {
	
	--	Hero Configuration
	Hero 			= {
		--	@	Hero ID
		--	@	Hero Name
		--	@	Hero Icon
		--	@	Hero Skill
		--	@	Hero Intro

		{	
			["ID"] 		= 1, 	
			["Name"] 	= "吕布", 
			["Icon"] 	= "lvbu"..icon,
			["Tong"]	= 5;
			["Ti"]		= 5, 
			["Skill"] 	= {}, 			
			["Comment"] = "", 
			["SkillCount"]	= 0;
			["Gender"] 	= "男";
		},
		{
			["ID"] 		=2,
			["Name"]	="高顺",
			["Icon"]	="gaoshun"..icon,
			["Tong"]	= 5;
			["Ti"]		= 5,			
			["Skill"]	={},
			["Comment"]	="",
			["SkillCount"]	= 0;
			["Gender"] 	= "男";
		},
		{
			["ID"] 		=3,
			["Name"]	="华雄",
			["Icon"]	="huaxiong"..icon,
			["Tong"]	= 4;
			["Ti"]		= 5,			
			["Skill"]	={},
			["Comment"]	="",
			["SkillCount"]	= 0;
			["Gender"] 	= "男";
		},
		{
			["ID"] 		=4,
			["Name"]	="袁尚",
			["Icon"]	="yuanshang"..icon,
			["Tong"]	= 4;
			["Ti"]		= 4,			
			["Skill"]	={},
			["Comment"]	="",
			["SkillCount"]	= 0;
			["Gender"] 	= "男";
		},
		{
			["ID"] 		=5,
			["Name"]	="文丑",
			["Icon"]	="wenchou"..icon,
			["Tong"]	= 5;
			["Ti"]		= 5,			
			["Skill"]	={},
			["Comment"]	="",
			["SkillCount"]	= 0;
			["Gender"] 	= "男";
		},
		{
			["ID"] 		=6,
			["Name"]	="高览",
			["Icon"]	="gaolan"..icon,
			["Tong"]	= 5;
			["Ti"]		= 5,			
			["Skill"]	={},
			["Comment"]	="",
			["SkillCount"]	= 0;
			["Gender"] 	= "男";
		},
		{
			["ID"] 		=7,
			["Name"]	="夏侯惇",
			["Icon"]	="xiahouchun"..icon,
			["Tong"]	= 4;
			["Ti"]		= 5,			
			["Skill"]	={},
			["Comment"]	="",
			["SkillCount"]	= 0;
			["Gender"] 	= "男";
		},
		{
			["ID"] 		=8,
			["Name"]	="夏侯渊",
			["Icon"]	="xiahouyuan"..icon,
			["Tong"]	= 5;
			["Ti"]		= 5,			
			["Skill"]	={},
			["Comment"]	="",
			["SkillCount"]	= 0;
			["Gender"] 	= "男";
		},
		{
			["ID"] 		=9,
			["Name"]	="张颌",
			["Icon"]	="zhanghe"..icon,
			["Tong"]	= 5;
			["Ti"]		= 5,			
			["Skill"]	={},
			["Comment"]	="",
			["SkillCount"]	= 0;
			["Gender"] 	= "男";
		},
		{
			["ID"] 		=10,
			["Name"]	="孙策",
			["Icon"]	="sunce"..icon,
			["Tong"]	= 5;
			["Ti"]		= 5,			
			["Skill"]	={},
			["Comment"]	="",
			["SkillCount"]	= 0;
			["Gender"] 	= "男";
		},
		{
			["ID"] 		=11,
			["Name"]	="吕蒙",
			["Icon"]	="lvmeng"..icon,
			["Tong"]	= 5;
			["Ti"]		= 5,			
			["Skill"]	={"鉴论"},
			["Comment"]	="",
			["SkillCount"]	= 1;
			["Gender"] 	= "男";
		},
		{
			["ID"] 		=12,
			["Name"]	="关羽",
			["Icon"]	="guanyu"..icon,
			["Tong"]	= 5;
			["Ti"]		= 5,			
			["Skill"]	={},
			["Comment"]	="",
			["SkillCount"]	= 0;
			["Gender"] 	= "男";
		},
		{
			["ID"] 		=13,
			["Name"]	="张飞",
			["Icon"]	="zhangfei"..icon,
			["Tong"]	= 5;
			["Ti"]		= 5,			
			["Skill"]	={},
			["Comment"]	="",
			["SkillCount"]	= 0;
			["Gender"] 	= "男";
		},
		{
			["ID"] 		=14,
			["Name"]	="马超",
			["Icon"]	="machao"..icon,
			["Tong"]	= 5;
			["Ti"]		= 5,			
			["Skill"]	={},
			["Comment"]	="",
			["SkillCount"]	= 0;
			["Gender"] 	= "男";
		},
		{
			["ID"] 		=15,
			["Name"]	="黄忠",
			["Icon"]	="huangzhong"..icon,
			["Tong"]	= 4;
			["Ti"]		= 5,			
			["Skill"]	={},
			["Comment"]	="",
			["SkillCount"]	= 0;
			["Gender"] 	= "男";
		},
		{
			["ID"] 		=16,
			["Name"]	="赵云",
			["Icon"]	="zhaoyun"..icon,
			["Tong"]	= 4;
			["Ti"]		= 5,			
			["Skill"]	={},
			["Comment"]	="",
			["SkillCount"]	= 0;
			["Gender"] 	= "男";
		},
		{	
			["ID"]		= 17,
			["Name"]	= "颜良",
			["Icon"]	= "yanliang"..icon,
			["Tong"]	= 5;
			["Ti"]		= 5,			
			["Skill"]	= {},
			["Comment"]	= "",
			["SkillCount"] = 0,
			["Gender"] 	= "男";
		},
		{
			["ID"] 		= 18,
			["Name"]	= "袁绍",
			["Icon"]	= "yuanshao"..icon,
			["Tong"]	= 4;
			["Ti"]		= 3,			
			["Skill"]	= {},
			["Comment"]	= "",
			["SkillCount"] = 0,
			["Gender"] 	= "男";
		},
		{
			["ID"] 		=19,
			["Name"]	="田丰",
			["Icon"]	="tianfeng"..icon,
			["Tong"]	= 3;
			["Ti"]		= 3,			
			["Skill"]	= {"直谏",},
			["Comment"]	="",
			["SkillCount"] = 1,
			["Gender"] 	= "男";
		},		
		{
			["ID"] 		=20,
			["Name"]	="甄宓(1)",
			["Icon"]	="zhenmi"..icon,
			["Tong"]	= 1;
			["Ti"]		= 1,			
			["Skill"]	= {"识时"},
			["Comment"]	="",
			["SkillCount"] =1 ,
			["Gender"] 	= "女";
		},		
		{
			["ID"] 		=21,
			["Name"]	="董卓",
			["Icon"]	="dongzhuo"..icon,
			["Tong"]	= 4;
			["Ti"]		= 4,			
			["Skill"]	={},
			["Comment"]	="",
			["SkillCount"] = 0,
			["Gender"] 	= "男";
		},		
		{
			["ID"] 		=22,
			["Name"]	="贾诩",
			["Icon"]	="jiaxu"..icon,
			["Tong"]	= 4;
			["Ti"]		= 3,			
			["Skill"]	={"诡诈","教唆"},
			["Comment"]	="",
			["SkillCount"] =2,
			["Gender"] 	= "男";
		},
		{
			["ID"] 		=23,
			["Name"]	="徐荣",
			["Icon"]	="xurong"..icon,
			["Tong"]	= 5;
			["Ti"]		= 4,			
			["Skill"]	= {},
			["Comment"]	="",
			["SkillCount"] =0 ,
			["Gender"] 	= "男";
		},
		{
			["ID"] 		=24,
			["Name"]	="貂蝉",
			["Icon"]	="diaochan"..icon,
			["Tong"]	= 0;
			["Ti"]		= 1,			
			["Skill"]	={"挑唆",},
			["Comment"]	="",
			["SkillCount"] =1,
			["Gender"] 	= "女";
		},
		{
			["ID"] 		=25,
			["Name"]	="孙权",
			["Icon"]	="sunquan"..icon,
			["Tong"]	= 4;
			["Ti"]		= 3,			
			["Skill"]	={"续问",},
			["Comment"]	="",
			["SkillCount"] = 1,
			["Gender"] 	= "男";
		},			
		{
			["ID"] 		=26,
			["Name"]	="孙尚香",
			["Icon"]	="sunshangxiang"..icon,
			["Tong"]	= 3;
			["Ti"]		= 4,			
			["Skill"]	={},
			["Comment"]	="",
			["SkillCount"] =0 ,
			["Gender"] 	= "女";
		},			
		{
			["ID"] 		=27,
			["Name"]	="周瑜",
			["Icon"]	="zhouyu"..icon,
			["Tong"]	= 5;
			["Ti"]		= 3,			
			["Skill"]	={"合论","诡辩"},
			["Comment"]	="",
			["SkillCount"] = 2,
			["Gender"] 	= "男";
		},			
		{
			["ID"] 		=28,
			["Name"]	="陆逊",
			["Icon"]	="luxun"..icon,
			["Tong"]	= 5;
			["Ti"]		= 3,			
			["Skill"]	={"说服",},
			["Comment"]	="",
			["SkillCount"] = 1,
			["Gender"] 	= "男";
		},			
		{
			["ID"] 		=29,
			["Name"]	="鲁肃",
			["Icon"]	="lusu"..icon,
			["Tong"]	= 4;
			["Ti"]		= 3,			
			["Skill"]	={"明论",},
			["Comment"]	="",
			["SkillCount"] = 1,
			["Gender"] 	= "男";
		},			
		{
			["ID"] 		=30,
			["Name"]	="曹操",
			["Icon"]	="caocao"..icon,
			["Tong"]	= 6;
			["Ti"]		= 3,			
			["Skill"]	={"威吓","怒责"},
			["Comment"]	="",
			["SkillCount"] =2,
			["Gender"] 	= "男";
		},			
		{
			["ID"] 		=31,
			["Name"]	="司马懿",
			["Icon"]	="simayi"..icon,
			["Tong"]	= 5;
			["Ti"]		= 3,			
			["Skill"]	= {"沉谨",},
			["Comment"]	= "",
			["SkillCount"] =1 ,
			["Gender"] 	= "男";
		},			
		{
			["ID"] 		=32,
			["Name"]	="郭嘉",
			["Icon"]	="guojia"..icon,
			["Tong"]	= 2;
			["Ti"]		= 3,			
			["Skill"]	= {"先断","临断"},
			["Comment"]	= "",
			["SkillCount"] =2,
			["Gender"] 	= "男";
		},			
		{
			["ID"] 		=33,
			["Name"]	="甄宓（2）",
			["Icon"]	="zhenmi2"..icon,
			["Tong"]	= 1;
			["Ti"]		= 1,			
			["Skill"]	= {"灵蛇髻",},
			["Comment"]	= "",
			["SkillCount"] =1 ,
			["Gender"] 	= "女";
		},			
		{
			["ID"] 		=34,
			["Name"]	="刘备",
			["Icon"]	="liubei"..icon,
			["Tong"]	= 4;
			["Ti"]		= 4,			
			["Skill"]	= {},
			["Comment"]	= "",
			["SkillCount"] = 0 ,
			["Gender"] 	= "男";
		},			
		{
			["ID"] 		= 35 ,
			["Name"]	="诸葛亮",
			["Icon"]	="zhugeliang"..icon,
			["Tong"]	= 5;
			["Ti"]		= 3,			
			["Skill"]	= {"巧舌", "激将法"},
			["Comment"]	= "",
			["SkillCount"] = 2,
			["Gender"] 	= "男";
		},	
	};


	--	Skill Wait Time
	HeroSkillRoundWaitTime 		= 2; 		--	回合开始前主动技能发动等待时间
	HeroSkillWaitTime 			= 5;		--	等待技能发动时间
	HeroSkillOperationWaitTime 	= 5;		--	技能发动后续操作等待时间

	HeroSkillAIControl 			= true;
};

------------------------------------------------------------------------------------------------------------------------------------

--	ModuleBianlunSkill Log Function
function ModuleBianlunSkill.Log( msg )
	-- body

	local 	preFix  = "++	ModuleBianlunSkill	++\n";	--..tostring(msg);
	local 	newMsg 	= tostring(preFix)..tostring(msg);
	
	print 	(newMsg);
end

--	ModuleBianlunSkill Hero Info Retriveve Function
function ModuleBianlunSkill.GetHeroInfo(param, target, id)		--	辩论技能可能为三个技能
	
	if target ~= "ID" and target ~= "Name" and target ~= "Icon" and target ~= "Skill" and target ~= "Comment" and target ~="Tong" and target ~= "Ti" and target ~= "SkillCount" and target ~= "Gender" then
		ModuleBianlunSkill.Log("Error:	Invalid Target in ModuleBianlunSkill.GetHeroInfo()"..tostring(target));
		return;
	end 		
	
	if 		type(param) == "number" then							--	ID号获取英雄配置信息	
		for	v in pairs(ModuleBianlunSkill.Hero) do		
			if ModuleBianlunSkill.Hero[v]["ID"] == param then
				if target == "Skill" then
					if  id == 0 then id = 1 end
					return	ModuleBianlunSkill.Hero[v]["Skill"][id];
				else
					return ModuleBianlunSkill.Hero[v][tostring(target)];
				end
			end
		end

		do 
			ModuleBianlunSkill.Log("Error:	Invalid Hero ID in ModuleBianlunSkill.GetHeroInfo()"..tostring(param));
			return;
		end
	elseif 	type(param) == "string" then							--	Name获取英雄配置信息		
		for v in pairs(ModuleBianlunSkill.Hero) do 
			if ModuleBianlunSkill.Hero[v]["Name"] == param then
				if target == "Skill" then
					if  id == 0 then id = 1 end
					return	ModuleBianlunSkill.Hero[v]["Skill"][id];
				else
					return ModuleBianlunSkill.Hero[v][tostring(target)];
				end
			end 
		end	
		
		do 
			ModuleBianlunSkill.Log("Error:	Invalid Hero Name in ModuleBianlunSkill.GetHeroInfo()"..tostring(param));
			return;
		end
		
	else	
		ModuleBianlunSkill.Log("Error:	Invalid Param in ModuleBianlunSkill.GetHeroInfo()"..tostring(param));
		return;
	end
end


function ModuleBianlunSkill.SetAIControl( bAI )
	-- body
	ModuleBianlunSkill.HeroSkillAIControl = bAI;
end

------------------------------------------------------------------------------------------------------------------------------------

--	Hero Special Skill 

function ModuleBianlunSkill.HandleHeroSkill_zhenmi_yuan( pos, state )
	-- body

--[[
	/**
	***		英雄--甄宓-袁
	***		技能--识时
	**/
--]]

	local 	serverLogic = CModuleBianlunServerLogic:sharedServerLogic();
	local 	selfPos 	= pos;
	local   otherPos 	= 1 - pos;

	if 		state == "JustOperation"	then
			
			if 	ModuleBianlunServerLogic.HeroSkill_zhenmi_shishi_flag[selfPos + 1] == 0 then
				ModuleBianlunSkill.Log("英雄--甄宓-袁，提醒使用识时技能");
				--	通知触发使用技能
			--	serverLogic:network_server_notifyPlayerSkillActive(selfPos, 1);

				return ModuleBianlunSkill.HandleHeroSkill_zhenmi_yuan(selfPos, "ActiveSkill");
			end
	elseif 	state == "ActiveSkill"		then
			local 	waitTime = ModuleBianlunSkill.HeroSkillWaitTime;

			--	AI 流程控制
			if 	ModuleBianlunSkill.HeroSkillAIControl == true then
				if 	ModuleBianlunAI.HandleSkillTrigger(selfPos) == true then

					serverLogic:network_server_broadCastPlayerHeroSkillSoundEffect(selfPos, "甄宓", "识时");
					return 	ModuleBianlunSkill.HandleHeroSkill_zhenmi_yuan(selfPos, "SkillTrigger");
				else
					return;
				end
			end

			--	非AI流程
			while 	true 	do
					local 	_state, _pos, _type  = ModuleBianlunServerLogic.Wait(waitTime);
					if 		_state  == "Timeout"		then
							ModuleBianlunSkill.Log("英雄--甄宓-袁， 识时技能发动超时");
							do  break end
					elseif 	_state  == "MessageArrive"	then
							if 	_pos == selfPos then
								if 		_type == "Skill" then
										ModuleBianlunSkill.Log("英雄--甄宓-袁，识时技能发动");
										serverLogic:network_server_broadCastPlayerHeroSkillSoundEffect(selfPos, "甄宓", "识时");
										return ModuleBianlunSkill.HandleHeroSkill_zhenmi_yuan(selfPos, "SkillTrigger");
								elseif	_type == "Logic"	then
										
										--	玩家放弃发动技能转为出牌
										ModuleBianlunSkill.Log("英雄--甄宓-袁,逻辑操作，结束技能逻辑")
										do 	break end
								end
							end
					else
					end
			end
	elseif	state == "SkillTrigger"	then
			local 	waitTime 	= ModuleBianlunSkill.HeroSkillOperationWaitTime;

			--	AI 流程
			if 	ModuleBianlunSkill.HeroSkillAIControl == true then
				if 	ModuleBianlunAI.HandleSkillTrigger(selfPos) == true then
					local 	handCardSize 	= serverLogic:getPlayerHandCardSize(selfPos);
					local 	exchangeNum 	= math.random(1, handCardSize);
					local 	exchangeList 	= {};

					--	Comment:
					--	AI 交换一张牌
					local 	card 	= serverLogic:getPlayerHandCard(selfPos, exchangeNum - 1);
					serverLogic:appendPlayerOutputCard(selfPos, card);



					--	接受弃牌
					serverLogic:acceptPlayerExchangeEvent(selfPos);

					ModuleBianlunServerLogic.HeroSkill_zhenmi_shishi_flag[selfPos + 1] = 1;

				else
					return;
				end
			end

			--	非AI流程
			while 	true 	do
					local 	_state, _pos, _type = ModuleBianlunServerLogic.Wait(waitTime);
					if 		_state == "Timeout" 		then
							ModuleBianlunSkill.Log("英雄--甄宓-袁，识时技能后续操作超时");
							do 	break end
					elseif 	_state == "MessageArrive"	then
							if 	_pos == selfPos and	 _type == "Logic" 	then
								ModuleBianlunSkill.Log("英雄--甄宓-袁，识时技能后续操作消息到来");

								local  output = serverLogic:getPlayerOutputCardList(selfPos);
								local  outputSize = serverLogic:getPlayerOutputCardSize(selfPos);

								if 	outputSize == 0  then
									--	提示放弃至少1张牌
									serverLogic:network_server_notifyPlayerTip(selfPos, "请选择至少一张牌进行放弃")

								else
									if 	algorithm_module_bianlun_zhenmi_checksametype(output) == true then

										--	接受弃牌
										serverLogic:acceptPlayerExchangeEvent(selfPos);

										ModuleBianlunServerLogic.HeroSkill_zhenmi_shishi_flag[selfPos + 1] = 1;
										do break end
									else
										--	提示放弃同类型的牌
										serverLogic:network_server_notifyPlayerTip(selfPos, "请选择同类型的牌放弃");
									end
								end
							end
					end
			end
	else
	end

	
end

function ModuleBianlunSkill.HandleHeroSkill_zhenmi_wei( pos, state )
	-- body

--[[
	/**
	***		英雄--甄宓-魏
	***		技能--灵蛇髻
	**/
--]]

	local 	serverLogic = CModuleBianlunServerLogic:sharedServerLogic();
	local 	selfPos 	= pos;
	local   otherPos 	= 1 - pos;

	if 		state == "JustOperation"	then

			ModuleBianlunSkill.Log("英雄--甄宓（魏）， 提醒使用技能灵蛇髻");
			--	通知技能可以使用
		--	serverLogic:network_server_notifyPlayerSkillActive(selfPos, 1);

			return ModuleBianlunSkill.HandleHeroSkill_zhenmi_wei(selfPos, "ActiveSkill");
	elseif	state == "ActiveSkill"		then
			local 	waitTime = ModuleBianlunSkill.HeroSkillWaitTime;

			--	AI 流程
			if 	ModuleBianlunSkill.HeroSkillAIControl == true then
				if 	ModuleBianlunAI.HandleSkillTrigger(selfPos) == true then

					local 	handCardSize 	= serverLogic:getPlayerHandCardSize(selfPos);
					local 	lunCard 		= serverLogic:getLunCard();
					local 	bAllLun 		= true;
					local 	bFinded 		= false;
					for 	i = 1, handCardSize do
							local 	card 	= serverLogic:getPlayerHandCard(selfPos, i - 1);
							if 	card:getValue() == lunCard:getValue() then
								bFinded 	= true;
							else
								bAllLun 	= false;
							end
					end

					if 	bAllLun  == true or bFinded == false then	--	要求不满足
						return;
					else
						serverLogic:network_server_broadCastPlayerHeroSkillSoundEffect(selfPos, "甄宓", "灵蛇髻");

						return ModuleBianlunSkill.HandleHeroSkill_zhenmi_wei(selfPos, "SkillTrigger"); 							
					end
					

				else
					return;
				end
			end

			--	非AI流程
			while 	true do 
					local 	_state, _pos, _type = ModuleBianlunServerLogic.Wait(waitTime);
					if 		_state == "Timeout"			then
							ModuleBianlunSkill.Log("英雄--甄宓（魏），发动技能灵蛇髻超时");
							do break end
					elseif	_state == "MessageArrive"	then
							if 	_pos == selfPos then
								if 		_type == "Skill"	then
										ModuleBianlunSkill.Log("英雄--甄宓（魏），发动技能灵蛇髻");
										return ModuleBianlunSkill.HandleHeroSkill_zhenmi_wei(selfPos, "SkillTrigger");
								elseif 	_type == "Logic" 	then

										--	玩家放弃发动技能转为出牌
										ModuleBianlunSkill.Log("英雄--甄宓-魏,逻辑操作，结束技能逻辑")
										do 	break end
								end								
							end
					else
					end
			end
	elseif 	state == "SkillTrigger"		then
			local 	waitTime 	= ModuleBianlunSkill.HeroSkillOperationWaitTime;

			--	AI 流程
			if 	ModuleBianlunSkill.HeroSkillAIControl == true then
				local 	handCardSize 	= serverLogic:getPlayerHandCardSize(selfPos);					--print(tostring(handCardSize))
				local 	lunCard 		= serverLogic:getLunCard();										print("论牌"..lunCard:dumpCard());
				local 	bNotLunDone 	= false;
				for 	i = 1, handCardSize do
						local 	card 	= serverLogic:getPlayerHandCard(selfPos, i  - 1);
						if 		card:getValue() ~= lunCard:getValue() and bNotLunDone == false then
								serverLogic:appendPlayerOutputCard(selfPos, card);						--print(card:dumpCard())
								bNotLunDone = true;
						elseif 	card:getValue() == lunCard:getValue() then
								serverLogic:appendPlayerOutputCard(selfPos, card);						--print(card:dumpCard())
						end

						if 	serverLogic:getPlayerOutputCardSize(selfPos) == 2 then
							break;
						end
				end

				local 	output 		= serverLogic:getPlayerOutputCardList(selfPos);
				local  	outputSize 	= serverLogic:getPlayerOutputCardSize(selfPos);	
				local 	notLunCard 	= algorithm_module_bianlun_zhenmi_getnotluncard(output, lunCard);	print(notLunCard:dumpCard())
				local 	card 		= serverLogic:getNextCard();										print(card:dumpCard())

			    --	替换新牌
				card:setTag(notLunCard:getTag());
				serverLogic:removePlayerHandCard(selfPos, notLunCard);
				serverLogic:appendPlayerHandCard(selfPos, card);

				--	清理剩余论牌
				serverLogic:removePlayerOutputCard(selfPos, notLunCard);

				serverLogic:acceptPlayerOutputEvent(selfPos);
												
				--	Output Done
				return "Outputed";							
			end

			--	非 AI 流程
			while 	true do
					local 	_state, _pos, _type = ModuleBianlunServerLogic.Wait(waitTime);
					if 		_state == "Timeout"			then
							ModuleBianlunSkill.Log("英雄--甄宓（魏），发动技能灵蛇髻后续操作超时");
							do break end
					elseif	_state == "MessageArrive"	then
							if 	_pos == selfPos and _type == "Logic"	then
								ModuleBianlunSkill.Log("英雄--甄宓（魏），发动技能灵蛇髻后续操作消息到来");

								local 	output 		= serverLogic:getPlayerOutputCardList(selfPos);
								local  	outputSize 	= serverLogic:getPlayerOutputCardSize(selfPos);

								if 		outputSize ~= 2 then
										serverLogic:refusePlayerOutputEvent(selfPos, "请选择两张牌");
								else
										local 	lunCard = serverLogic:getLunCard();
										if 		algorithm_module_bianlun_zhenmi_checkluncardwithothertype(output, lunCard) == true then

												local 	notLunCard = algorithm_module_bianlun_zhenmi_getnotluncard(output, lunCard);
												local 	card 	= serverLogic:getNextCard();

												--	替换新牌
												card:setTag(notLunCard:getTag());
												serverLogic:removePlayerHandCard(selfPos, notLunCard);
												serverLogic:appendPlayerHandCard(selfPos, card);

												--	清理剩余论牌
												serverLogic:removePlayerOutputCard(selfPos, notLunCard);

												serverLogic:acceptPlayerOutputEvent(selfPos);
												
												--	Output Done
												return "Outputed";

										else
												serverLogic:refusePlayerOutputEvent(selfPos, "请选择一张论牌和一张其他类别的牌");
										end
								end
							end
					else
					end
			end
	else
	end


end

function ModuleBianlunSkill.HandleHeroSkill_diaochan( pos, state )
	-- body

--[[
	/**
	***		英雄--貂蝉
	***		技能--挑唆
	**/
--]]

	local 	serverLogic = CModuleBianlunServerLogic:sharedServerLogic();
	local 	selfPos 	= pos;
	local   otherPos 	= 1 - pos;	

	if 		state == "AfterCompareWithLosserBeforeConfirm"	then
			local 	selfCard 	= serverLogic:getPlayerPreOutputCard(selfPos, 0);
			local   otherCard 	= serverLogic:getPlayerPreOutputCard(otherPos, 0);

			local 	bSelfBoCard 	= false;
			local 	bOtherBianCard 	= false;

		--	ModuleBianlunSkill.Log(selfCard:dumpCard());

			if 		serverLogic:isBoCard(selfCard) 	== true then
					bSelfBoCard	= true;
			end

			if 	bSelfBoCard == true then
				--	貂蝉驳牌辩论失败, 辩论结果失效
				ModuleBianlunSkill.Log("英雄--貂蝉， 挑唆技能效果触发,本回合结果无效");

				serverLogic:network_server_broadCastPlayerHeroSkillSoundEffect(selfPos, "貂蝉", "挑唆");

				return true;
			else
				return false;
			end
	end
end

function ModuleBianlunSkill.HandleHeroSkill_lusu( pos , state )
	-- body

--[[
	/**
	***		英雄--鲁肃
	***		技能--明论
	**/
--]]

	local 	serverLogic = CModuleBianlunServerLogic:sharedServerLogic();
	local 	selfPos 	= pos;
	local   otherPos 	= 1 - pos;		

	if 		state 	== "AfterCompareWithLosserBeforeConfirm"	then
			local  	selfOutputCard 	= serverLogic:getPlayerPreOutputCard(selfPos, 0);
			local  	otherOutputCard 	= serverLogic:getPlayerPreOutputCard(otherPos, 0);

			if 		otherOutputCard:getType() == selfOutputCard:getType() then
					ModuleBianlunSkill.Log("英雄--鲁肃，明论技能触发，本回合比较结果无效");

					serverLogic:network_server_broadCastPlayerHeroSkillSoundEffect(selfPos, "鲁肃", "明论");

					return true;
			else
					return false;
			end
	end

end

function ModuleBianlunSkill.HandleHeroSkill_lvmeng( pos, state )
	-- body

--[[
	/**
	***		英雄--吕蒙
	***		技能--鉴论
	**/
--]]

	local 	serverLogic = CModuleBianlunServerLogic:sharedServerLogic();
	local 	selfPos 	= pos;
	local   otherPos 	= 1 - pos;	

	if 		state 	== "AfterCompareWithLosserBeforeConfirm"	then
			local  	selfOutputCard 	= serverLogic:getPlayerPreOutputCard(selfPos, 0);
			local  	otherOutputCard 	= serverLogic:getPlayerPreOutputCard(otherPos, 0);

			local   bSelfLunCard 	= serverLogic:isLunCard(selfOutputCard);
			local 	bOtherBoCard 	= serverLogic:isBoCard(otherOutputCard);

			if 		otherOutputCard:getType() ~= selfOutputCard:getType()  and bSelfLunCard == true and bOtherBoCard == true then
					ModuleBianlunSkill.Log("英雄--吕蒙，鉴论技能触发，本回合比较结果无效");
						
					serverLogic:network_server_broadCastPlayerHeroSkillSoundEffect(selfPos, "吕蒙", "鉴论");

					return true;
			else
					return false;
			end			
	end
end

function ModuleBianlunSkill.HandleHeroSkill_jiaxu( pos, state )
	-- body

--[[
	/**
	***		英雄--贾诩
	***		技能--诡诈、教唆
	**/
--]]

	local 	serverLogic = CModuleBianlunServerLogic:sharedServerLogic();
	local 	selfPos 	= pos;
	local   otherPos 	= 1 - pos;	

	if 		state == "BeforeDecideChangeLunBo"	then

			local 	selfOutputCard 	= serverLogic:getPlayerOutputCard(selfPos, 0);
			local 	otherOutputCard	= serverLogic:getPlayerOutputCard(otherPos, 0);

			local   bBoCard 	= serverLogic:isBoCard(selfOutputCard);
			local  	bLunCard 	= serverLogic:isLunCard(selfOutputCard);

			--	补充己方必须为辩牌检测
			if 		selfOutputCard:getType() == otherOutputCard:getType() and bBoCard == false and bLunCard == false  then
					ModuleBianlunSkill.Log("英雄--贾诩， 诡诈技能触发，同色论驳对辩改变论驳");

					serverLogic:network_server_broadCastPlayerHeroSkillSoundEffect(selfPos, "贾诩", "诡诈");
					return true;
			end
	elseif	state == "DecideWinnerWithBianDraw"	then

--			local 	selfOutputCard 	= serverLogic:getPlayerOutputCard(selfPos, 0);
--			local 	otherOutputCard	= serverLogic:getPlayerOutputCard(otherPos, 0);

			--	判定己方是否为辩牌
--[[
			local   bBoCard 	= serverLogic:isBoCard(selfOutputCard);
			local  	bLunCard 	= serverLogic:isLunCard(selfOutputCard);

			local 	bSelfBianCard 	= false;
			local  	bOtherBianCard	= false;

			if 		bBoCard  == false and  bLunCard == false then
					bSelfBianCard  = true;
			end
--]]

			local 	otherPlayerName = serverLogic:getPlayerName(otherPos);
			if 		otherPlayerName == "贾诩"	then

					--	双方都为贾诩且因辩牌平手
					return nil;
			else
					--	对方非贾诩

					ModuleBianlunSkill.Log("英雄--贾诩，教唆技能触发");

					serverLogic:network_server_broadCastPlayerHeroSkillSoundEffect(selfPos, "贾诩", "教唆");

					return selfPos;
			end
	end

end


function ModuleBianlunSkill.HandleHeroSkill_tianfeng( pos , state)
	-- body

--[[
	/**
	***		英雄--田丰
	***		技能--直谏
	**/
--]]

	local 	serverLogic = CModuleBianlunServerLogic:sharedServerLogic();
	local 	selfPos 	= pos;
	local   otherPos 	= 1 - pos;


	if 		state == "AfterShowOutputCard"	then
			print("处理田丰技能");
			local 	selfOutputCard 	= serverLogic:getPlayerPreOutputCard(selfPos, 0); 			--print(selfOutputCard:dumpCard())
			local 	otherOutputCard = serverLogic:getPlayerPreOutputCard(otherPos, 0);

			if 		selfOutputCard:getType() ~= otherOutputCard:getType() then
					
					ModuleBianlunSkill.Log("英雄--田丰， 直谏技能触发");

					--	对方出牌变更为田丰同色
					
					serverLogic:accordPlayerOutputCardWithType(otherPos, selfOutputCard:getType());

					serverLogic:network_server_notifyPlayerShowOutputCards();

					serverLogic:network_server_broadCastPlayerHeroSkillSoundEffect(selfPos, "田丰", "直谏");
			end
	end

end

function ModuleBianlunSkill.HandleHeroSkill_luxun( pos, state )
	-- body

--[[
	/**
	***		英雄--陆逊
	***		技能--说服
	**/
--]]

	local 	serverLogic = CModuleBianlunServerLogic:sharedServerLogic();
	local 	selfPos 	= pos;
	local   otherPos 	= 1 - pos;	

	if 		state 	== "AfterCompareWithWinner" 	then
			local   outputCard 	= serverLogic:getPlayerPreOutputCard(selfPos, 0);
			if 		serverLogic:isLunCard(outputCard) 	== true then
					--	以论牌取胜
					--	追加连续标志
					ModuleBianlunServerLogic.HeroSkill_luxun_shuifu_time[selfPos + 1] = ModuleBianlunServerLogic.HeroSkill_luxun_shuifu_time[selfPos + 1] + 1;

					ModuleBianlunServerLogic.Log("陆逊以论牌获胜次数："..tostring(ModuleBianlunServerLogic.HeroSkill_luxun_shuifu_time[selfPos + 1]));

					if 	ModuleBianlunServerLogic.HeroSkill_luxun_shuifu_time[selfPos + 1] == 3 then

						ModuleBianlunSkill.Log("英雄--陆逊, 说服技能触发");

						serverLogic:network_server_broadCastPlayerHeroSkillSoundEffect(selfPos, "陆逊", "说服");
						--	对方直接判负处理
						return true;
					else
						return false;
					end
			else
					--	非论牌取胜
					--	取消连续标志
					ModuleBianlunServerLogic.HeroSkill_luxun_shuifu_time[selfPos + 1] = 0;

					return false;
			end
	elseif	state == "AfterCompareWithLosser"	then

			--	清理连续标志
			ModuleBianlunServerLogic.HeroSkill_luxun_shuifu_time[selfPos + 1] = 0;
	end
end

function ModuleBianlunSkill.HandleHeroSkill_zhugeliang( pos, state )
	-- body

--[[
	/**
	***		英雄--诸葛亮
	***		技能--巧舌、激将法
	**/
--]]

	local 	serverLogic = CModuleBianlunServerLogic:sharedServerLogic();
	local 	selfPos 	= pos;
	local   otherPos 	= 1 - pos;		

	if 		state == "AfterCompareWithLosser"	then

			ModuleBianlunServerLogic.HeroSkill_zhugeliang_jijiangfa_time[selfPos + 1] = ModuleBianlunServerLogic.HeroSkill_zhugeliang_jijiangfa_time[selfPos + 1] + 1;

			ModuleBianlunSkill.Log("诸葛亮连续失败次数："..tostring(ModuleBianlunServerLogic.HeroSkill_zhugeliang_jijiangfa_time[selfPos + 1]));


			if 	ModuleBianlunServerLogic.HeroSkill_zhugeliang_jijiangfa_time[selfPos + 1] ==  5 then
				ModuleBianlunSkill.Log("英雄--诸葛亮, 激将法技能触发");

				serverLogic:network_server_broadCastPlayerHeroSkillSoundEffect(selfPos, "诸葛亮", "激将法");

				--	对方直接判负
				return true;
			else
				return false;
			end

	elseif 	state == "AfterCompareWithWinner"	then

			--	清理辩论失败次数
			ModuleBianlunServerLogic.HeroSkill_zhugeliang_jijiangfa_time[selfPos + 1] = 0;

			ModuleBianlunSkill.Log("诸葛亮连续失败次数："..tostring(ModuleBianlunServerLogic.HeroSkill_zhugeliang_jijiangfa_time[selfPos + 1]));

			--	多模多模一张牌

			local 	handCardSize = serverLogic:getPlayerOutputCardSize(selfPos);
			if 		handCardSize < 5 then
					--	确保总牌数不超过6

					ModuleBianlunSkill.Log("英雄--诸葛亮, 巧舌技能触发");

					serverLogic:network_server_broadCastPlayerHeroSkillSoundEffect(selfPos, "诸葛亮", "巧舌");

					local  	card = serverLogic:getNextCard();

					--	搜索闲置Tag
					local  	tag  = -1;
					tag 	=	serverLogic:getPlayerHandCardFreeTag(selfPos);
					card:setTag(tag);
								
					serverLogic:appendPlayerHandCard(selfPos, card);
--					serverLogic:network_server_notifyRemainPlayerHandCards(winnerPosition);	;

			end
	end
end


function ModuleBianlunSkill.HandleHeroSkill_sunquan( pos, state )
	-- body

--[[
	/**
	***		英雄--孙权
	***		技能--续问
	**/
--]]

	local 	serverLogic = CModuleBianlunServerLogic:sharedServerLogic();
	local 	selfPos 	= pos;
	local   otherPos 	= 1 - pos;	

	if 		state 	== "AfterCompareWithLosser"		then

			ModuleBianlunSkill.Log("提醒使用技能续问");
		--	serverLogic:network_server_notifyPlayerSkillActive(selfPos, 1);

			return ModuleBianlunSkill.HandleHeroSkill_sunquan(selfPos, "ActiveSkill");
	elseif 	state  == "ActiveSkill"		then
			local 	waitTime = ModuleBianlunSkill.HeroSkillWaitTime;

			serverLogic:network_server_notifyPlayerTip(selfPos, "请选择是否发动续问技能");
			serverLogic:network_server_notifyPlayerTip(otherPos, "等待对方发动续问技能");


			--	AI控制流程
			if 	ModuleBianlunSkill.HeroSkillAIControl == true then
				if 	ModuleBianlunAI.HandleSkillTrigger(selfPos) == true then

					local  	handCardSize  	= serverLogic:getPlayerHandCardSize(selfPos);
					local 	boCard 			= serverLogic:getBoCard();
					local 	bCanTrigger 	= false;
					for 	i = 1, handCardSize do 
							local 	card 	= serverLogic:getPlayerHandCard(selfPos, i - 1);
							if 	card:getValue() == boCard:getValue() then
								bCanTrigger = true;
								do break end
							end
					end

					if 	bCanTrigger == true then
						serverLogic:network_server_broadCastPlayerHeroSkillSoundEffect(selfPos, "孙权", "续问");
					
						return ModuleBianlunSkill.HandleHeroSkill_sunquan(selfPos, "SkillTrigger");
					else
						return;
					end
				else
					return;
				end
			end

			--	非AI控制流程
			while 	true 	do
				local 	_state, _pos, _type = ModuleBianlunServerLogic.Wait(waitTime);
				if 		_state == "Timeout"			then
						ModuleBianlunSkill.Log("英雄--孙权, 续问技能发动超时");
						do  break 	end
				elseif	_state == "MessageArrive"	then
						if 	_pos == selfPos and _type == "Skill" 	then
							ModuleBianlunSkill.Log("英雄--孙权, 续问技能发动");

							serverLogic:network_server_broadCastPlayerHeroSkillSoundEffect(selfPos, "孙权", "续问");

							return ModuleBianlunSkill.HandleHeroSkill_sunquan(selfPos, "SkillTrigger");
						end
				end
			end
	elseif	state  == "SkillTrigger"	then

			local 	currentOutputPosition = serverLogic:getOutputPosition();

			--	记录当前出牌位置
			ModuleBianlunServerLogic.RecordCurrentOutputPosition(currentOutputPosition);

			--	Allow the Losser to Operation
			serverLogic:setOutputPosition(selfPos);

			--	Clear Current Turn Contex
			serverLogic:doTurnClean();

			serverLogic:network_server_notifyPlayerTip(selfPos, "请选择一张驳牌打出作为亮牌");
			serverLogic:network_server_notifyPlayerTip(otherPos, "等待对方亮牌");

			--	AI 流程
			if 	ModuleBianlunSkill.HeroSkillAIControl == true then
				local  	handCardSize  	= serverLogic:getPlayerHandCardSize(selfPos);
				local 	boCard 			= serverLogic:getBoCard();
				
				for 	i = 1, handCardSize do 
						local 	card 	= serverLogic:getPlayerHandCard(selfPos, i - 1);
						if 	card:getValue() == boCard:getValue() then
							serverLogic:appendPlayerOutputCard(selfPos, card);
							do break end
						end
				end				

				serverLogic:acceptPlayerOutputEvent(selfPos);
				ModuleBianlunServerLogic.WaitTimeout(0.5);
				serverLogic:network_server_notifyPlayerShowOutputCards();
				--	记录玩家亮牌
				serverLogic:acceptPlayerShowEvent(selfPos);

				return ModuleBianlunSkill.HandleHeroSkill_sunquan(selfPos, "NotifyOtherShowCard");
			end



			--	非AI流程

			local 	waitTime = ModuleBianlunSkill.HeroSkillOperationWaitTime;
			while 	true 	do
				local 	_state, _pos, _type  = ModuleBianlunServerLogic.Wait(waitTime);
				if 		_state == "Timeout"			then
						ModuleBianlunServerLogic.Log("英雄--孙权, 续问技能后续操作超时");

						do  break end
				elseif 	_state == "MessageArrive"	then
						ModuleBianlunSkill.Log("有消息到来");
						if 	_pos == selfPos and _type == "Logic" 	then
							ModuleBianlunSkill.Log("英雄--孙权, 续问技能后续操作消息到来");
							
							if 	serverLogic:getPlayerOutputCardSize(selfPos) == 1 then
								local 	outputCard = serverLogic:getPlayerOutputCard(selfPos, 0);

								if 		serverLogic:isBoCard(outputCard)	== true then

										--	接受出牌
										serverLogic:acceptPlayerOutputEvent(selfPos);
										ModuleBianlunServerLogic.WaitTimeout(0.5);
										serverLogic:network_server_notifyPlayerShowOutputCards();
										--	记录玩家亮牌
										serverLogic:acceptPlayerShowEvent(selfPos);

										return ModuleBianlunSkill.HandleHeroSkill_sunquan(selfPos, "NotifyOtherShowCard");
								else 	
										serverLogic:refusePlayerOutputEvent(selfPos, "请亮一张驳牌");
								end
							else

								serverLogic:refusePlayerOutputEvent(selfPos, "请亮一张驳牌");
							end
						end
				end
			end

			serverLogic:setOutputPosition(currentOutputPosition);

	elseif 	state == "NotifyOtherShowCard" 	then

			ModuleBianlunSkill.Log("通知对方亮辩牌或弃牌");

			serverLogic:network_server_notifyPlayerTip(otherPos, "请亮一张辩牌或者弃掉两张手牌");
			serverLogic:network_server_notifyPlayerTip(selfPos,  "等待对方亮牌或弃牌");

			--	设定对方出牌
			serverLogic:setOutputPosition(otherPos);

			return ModuleBianlunSkill.HandleHeroSkill_sunquan(selfPos, "WaitOtherShowCard");
	elseif	state == "WaitOtherShowCard"	then
			local 	waitTime 	= ModuleBianlunSkill.HeroSkillOperationWaitTime;

			--	AI 流程
			if 	ModuleBianlunSkill.HeroSkillAIControl == true then
				do
							local 	size = serverLogic:getPlayerHandCardSize(otherPos);
							local 	bianCard = nil;
							for   	i = 1, size 	do
									local 	card = serverLogic:getPlayerHandCard(otherPos, i - 1);
									if 	serverLogic:isLunCard(card) == false and serverLogic:isBoCard(card) == false then
										ModuleBianlunSkill.Log("Fined the bian Card!");
										bianCard = card;
										--	Finded
										do  break end
									end
							end

							if 	bianCard == nil then
							    --	搜索失败弃牌2张
							    ModuleBianlunSkill.Log("无辩牌，弃两张牌");
							    serverLogic:clearPlayerOutputCard(otherPos);
								for 	i = 1, 2	do 
										local 	card 	= serverLogic:getPlayerHandCard(otherPos, i -1);
										ModuleBianlunServerLogic.Log("\n@弃牌: "..card:dumpCard().."\n");
										serverLogic:appendPlayerOutputCard(otherPos, card);
								end

								serverLogic:acceptPlayerOutputEvent(otherPos);
								ModuleBianlunServerLogic.WaitTimeout(0.5);
								serverLogic:network_server_notifyPlayerShowOutputCards();

								--	己方回牌
								serverLogic:refusePlayerShowGiveupEvent(selfPos);

							else
								--	搜索成功亮辩牌
								ModuleBianlunSkill.Log("有辩牌");
								
								serverLogic:clearPlayerOutputCard(otherPos);
								serverLogic:appendPlayerOutputCard(otherPos, bianCard);

								--	对方出牌
								serverLogic:acceptPlayerOutputEvent(otherPos);
								ModuleBianlunServerLogic.WaitTimeout(0.5);
								serverLogic:network_server_notifyPlayerShowOutputCards();
								--	对方亮牌
								serverLogic:acceptPlayerShowEvent(otherPos);


								--	己方弃牌,对方回牌
								serverLogic:acceptPlayerShowGiveupEvent(selfPos);
								serverLogic:refusePlayerShowGiveupEvent(otherPos);
							end	

					ModuleBianlunServerLogic.WaitTimeout(1);

					serverLogic:network_server_notifyPlayerHideOutputCards();

					--	重置原先出牌位置
					local 	orignalOutputPosition = ModuleBianlunServerLogic.GetCurrentOutputPosition();
					if 		ModuleBianlunServerLogic.GetCurrentOutputPosition() ~= nil  	then

							ModuleBianlunSkill.Log("恢复原先的出牌位置:"..tostring(orignalOutputPosition));
							serverLogic:setOutputPosition(orignalOutputPosition);
					end							
				end		
				return;				
			end

			--	非AI流程
			while 	true 	do 
					local 	_state, _pos, _type = ModuleBianlunServerLogic.Wait(waitTime);
					if 		_state == "Timeout"			then

							ModuleBianlunSkill.Log("对方亮牌或弃牌超时");

							--	搜索手中辩牌
							local 	size = serverLogic:getPlayerHandCardSize(otherPos);
							local 	bianCard = nil;
							for   	i = 1, size 	do
									local 	card = serverLogic:getPlayerHandCard(otherPos, i - 1);
									if 	serverLogic:isLunCard(card) == false and serverLogic:isBoCard(card) == false then
										ModuleBianlunSkill.Log("Fined the bian Card!");
										bianCard = card;
										--	Finded
										do  break end
									end
							end

--							ModuleBianlunSkill.Log(tostring(bianCard));
--							ModuleBianlunSkill.Log(bianCard:dumpCard());

--							serverLogic:stop();

							if 	bianCard == nil then
							    --	搜索失败弃牌2张
							    ModuleBianlunSkill.Log("无辩牌，弃两张牌");
							    serverLogic:clearPlayerOutputCard(otherPos);
								for 	i = 1, 2	do 
										local 	card 	= serverLogic:getPlayerHandCard(otherPos, i -1);
										ModuleBianlunServerLogic.Log("\n@弃牌: "..card:dumpCard().."\n");
										serverLogic:appendPlayerOutputCard(otherPos, card);
								end

								serverLogic:acceptPlayerOutputEvent(otherPos);
								ModuleBianlunServerLogic.WaitTimeout(0.5);
								serverLogic:network_server_notifyPlayerShowOutputCards();

								--	己方回牌
								serverLogic:refusePlayerShowGiveupEvent(selfPos);

							else
								--	搜索成功亮辩牌
								ModuleBianlunSkill.Log("有辩牌");
								
								serverLogic:clearPlayerOutputCard(otherPos);
								serverLogic:appendPlayerOutputCard(otherPos, bianCard);

								--	对方出牌
								serverLogic:acceptPlayerOutputEvent(otherPos);
								ModuleBianlunServerLogic.WaitTimeout(0.5);
								serverLogic:network_server_notifyPlayerShowOutputCards();
								--	对方亮牌
								serverLogic:acceptPlayerShowEvent(otherPos);


								--	己方弃牌,对方回牌
								serverLogic:acceptPlayerShowGiveupEvent(selfPos);
								serverLogic:refusePlayerShowGiveupEvent(otherPos);
							end

							do 	break  end
					elseif	_state == "MessageArrive"	then

							if 	_pos == otherPos and _type == "Logic"	then
								local 	size = serverLogic:getPlayerOutputCardSize(otherPos);
								if 		size ==  1 then
										local 	card = serverLogic:getPlayerHandCard(otherPos, 0);
										if 		serverLogic:isLunCard(card) == false and serverLogic:isBoCard(card) == false then
												
												--	对方亮辩牌
												serverLogic:acceptPlayerOutputEvent(otherPos);
												ModuleBianlunServerLogic.WaitTimeout(0.5);
												serverLogic:network_server_notifyPlayerShowOutputCards();

												--	接受对方亮牌
												serverLogic:acceptPlayerShowEvent(otherPos);

												--	己方弃驳牌,对方回牌
												serverLogic:acceptPlayerShowGiveupEvent(selfPos);
												serverLogic:refusePlayerShowGiveupEvent(otherPos);

												do break end

										else
												serverLogic:refusePlayerShowEvent(otherPos, "请亮一张辩牌");
										end
								elseif 	size ==  2 then

										--	对方弃牌
										serverLogic:acceptPlayerOutputEvent(otherPos);
										ModuleBianlunServerLogic.WaitTimeout(0.5);
										serverLogic:network_server_notifyPlayerShowOutputCards();

										--	己方亮牌还原
--										serverLogic:acceptPlayerShowGiveupEvent(otherPos);
										serverLogic:refusePlayerShowGiveupEvent(selfPos);

										do  break end
								end
							end
					else
					end
			end 

			ModuleBianlunServerLogic.WaitTimeout(1);

			serverLogic:network_server_notifyPlayerHideOutputCards();

			--	重置原先出牌位置
			local 	orignalOutputPosition = ModuleBianlunServerLogic.GetCurrentOutputPosition();
			if 		ModuleBianlunServerLogic.GetCurrentOutputPosition() ~= nil  	then

					ModuleBianlunSkill.Log("恢复原先的出牌位置:"..tostring(orignalOutputPosition));
					serverLogic:setOutputPosition(orignalOutputPosition);
			end
	end

end

function ModuleBianlunSkill.HandleHeroSkill_simayi( pos, state )
	-- body

--[[
	/**
	***		英雄--司马懿
	***		技能--沉谨
	**/
--]]

	local 	serverLogic = CModuleBianlunServerLogic:sharedServerLogic();
	local 	selfPos 	= pos;
	local   otherPos 	= 1 - pos;	

	if 		state == "PreFaPai" 	then
			ModuleBianlunSkill.Log("英雄--司马懿, 沉谨技能触发");

			local 	handcardsize = ModuleBianlunServerLogic.GetPlayerHandCardSize(selfPos);

			--		等级成长处理
			local 	level 		 = 100;
			local 	time 		 = math.floor(level/10);
			local 	inc 		 = time * 1;
			if 		inc 		 > 2 		then
					inc 		 = 2
			end				

			if 		handcardsize + inc >=  6 then
					handcardsize = 6;
			else
					handcardsize = handcardsize + inc;
			end

			ModuleBianlunSkill.Log("沉谨技能促使手中牌变更为"..tostring(handcardsize));

			ModuleBianlunServerLogic.SetPlayerHandCardSize(selfPos, handcardsize);

			serverLogic:network_server_broadCastPlayerHeroSkillSoundEffect(selfPos, "司马懿", "沉谨");
	end
end

function ModuleBianlunSkill.HandleHeroSkill_zhouyu( pos, state )
	-- body

--[[
	/**
	***		英雄--周瑜
	***		技能--合论、诡辩
	**/
--]]

	local 	serverLogic = CModuleBianlunServerLogic:sharedServerLogic();
	local 	selfPos 	= pos;
	local   otherPos 	= 1 - pos;		

	if 		state 	== 	"JustOperation"		then

			--	提醒玩家使用合论技能
			local 	handcardsize = serverLogic:getPlayerHandCardSize(selfPos);
			local 	bHaveLunCard = false;

			for 	i = 1, handcardsize do 
					local 	card = serverLogic:getPlayerHandCard(selfPos, i - 1);

					if 		serverLogic:isLunCard(card) == true then
							bHaveLunCard = true;
							do  break end
					end
			end
--[[
			if 	bHaveLunCard == true then
				serverLogic:network_server_notifyPlayerSkillActive(pos, 1);
			end

			--	提醒玩家使用诡辩技能
			if 	ModuleBianlunServerLogic.HeroSkill_zhouyu_guibian_time[selfPos + 1] < 2 then
				serverLogic:network_server_notifyPlayerSkillActive(pos, 2);
			end
--]]
			return ModuleBianlunSkill.HandleHeroSkill_zhouyu(selfPos, "ActiveSkill");
	elseif 	state == "ActiveSkill"			then

			local 	waitTime 	= ModuleBianlunSkill.HeroSkillWaitTime;
			print("ActiveSkill");
			--	AI流程
			if 	ModuleBianlunSkill.HeroSkillAIControl == true then

				local 	skillIndex 		= math.random(1, 2);
				local  	handcardsize 	= serverLogic:getPlayerHandCardSize(selfPos);

				for 	i = 1, handcardsize do 
						local 	card = serverLogic:getPlayerHandCard(selfPos, i - 1);

						if 		serverLogic:isLunCard(card) == true then
								bHaveLunCard = true;
								do  break end
						end
				end

				print("1");
				if 	bHaveLunCard == true then
					--	 合论技能
					if 	skillIndex == 1 then
						return ModuleBianlunSkill.HandleHeroSkill_zhouyu(selfPos, "Skill1_Trigger");
					else
						--	继续下一技能
					end
				end
				print("2");
				--	提醒玩家使用诡辩技能
				if 	ModuleBianlunServerLogic.HeroSkill_zhouyu_guibian_time[selfPos + 1] < 3 then
					if 	skillIndex == 2 then
						return ModuleBianlunSkill.HandleHeroSkill_zhouyu(selfPos, "Skill2_Trigger");
					else
						--	技能发动条件不足
						return;
					end
				end			
				print("3");	

			end

			--	非AI流程
			while 	true 	do
					local 	_state, _pos, _type, _index = ModuleBianlunServerLogic.Wait(waitTime);

					ModuleBianlunSkill.Log(tostring(_state)..tostring(_pos)..tostring(_type)..tostring(_index));

					if 		_state == 	"Timeout"		then
							ModuleBianlunSkill.Log("英雄--周瑜, 技能发动超时");
							do  break end
					elseif	_state == "MessageArrive"	then

							if 		_pos == selfPos then
									if 		_type == "Skill" 	then
											if  	_index == 1 then
													ModuleBianlunSkill.Log("技能一消息到来");

													return ModuleBianlunSkill.HandleHeroSkill_zhouyu(selfPos, "Skill1_Trigger");
											elseif	_index == 2 then
													ModuleBianlunSkill.Log("技能二消息到来");
													return ModuleBianlunSkill.HandleHeroSkill_zhouyu(selfPos, "Skill2_Trigger");
											end
									elseif 	_type == "Logic" 	then

											ModuleBianlunSkill.Log("英雄--周瑜逻辑操作，结束技能逻辑");
											do break end
									end
							end
					end
			end
	elseif 	state == "Skill1_Trigger"		then
			
			ModuleBianlunSkill.Log("英雄--周瑜, 合论技能发动");

			serverLogic:network_server_broadCastPlayerHeroSkillSoundEffect(selfPos, "周瑜", "合论");

			serverLogic:network_server_notifyPlayerTip(selfPos, "请选择至多3张论牌打出");
			local 	waitTime = 	ModuleBianlunSkill.HeroSkillOperationWaitTime;

			--	AI流程
			if 	ModuleBianlunSkill.HeroSkillAIControl == true then
				local 	handcardsize 	= serverLogic:getPlayerHandCardSize(selfPos);
				local 	lunSum 			= 0;
				for 	i = 1, handcardsize do 
						local 	card = serverLogic:getPlayerHandCard(selfPos, i - 1);

						if 		serverLogic:isLunCard(card) == true then
								lunSum = lunSum + 1;
						end
				end

				local 	random 	= math.random(1, lunSum);
				for 	i = 1, random do
						local 	card 	= serverLogic:getPlayerHandCard(selfPos, i - 1);
						if 		serverLogic:isLunCard(card) == true then
								serverLogic:appendPlayerOutputCard(selfPos,	card);
						end
				end

				serverLogic:acceptPlayerOutputEvent(selfPos);
				serverLogic:network_server_notifyPlayerTip(otherPos, "请选择等量的驳牌打出或弃掉等量的其他类牌");
				return "Outputed";

			end
			--	非AI流程
			while 	true	 do
				local   _state, _pos, _type = ModuleBianlunServerLogic.Wait(waitTime);

				if 		_state == "Timeout"			then
						
						ModuleBianlunSkill.Log("英雄--周瑜, 合论技能发动超时");

						do  break end
				elseif	_state == "MessageArrive"	then
						if 	_pos == selfPos and _type == "Logic" 	then
							ModuleBianlunSkill.Log("英雄--周瑜, 合论技能后续操作消息到来");

							local 	outputsize = serverLogic:getPlayerOutputCardSize(selfPos);
							if 		outputsize > 3  or outputsize < 1 then
									serverLogic:network_server_notifyPlayerTip(selfPos, "请选择至多3张论牌打出");
							else
									local 	output = serverLogic:getPlayerOutputCardList(selfPos);
									local 	luncard= serverLogic:getLunCard();
									if 		algorithm_module_bianlun_zhouyu_checksametypecard(output, luncard) == true then

											serverLogic:acceptPlayerOutputEvent(selfPos);

											serverLogic:network_server_notifyPlayerTip(otherPos, "请选择等量的驳牌打出或弃掉等量的其他类牌");

											return "Outputed";
									end
							end
						end
				end
			end

	elseif 	state == "Skill2_Trigger"		then
			ModuleBianlunSkill.Log("英雄--周瑜, 诡辩技能发动");

			serverLogic:network_server_broadCastPlayerHeroSkillSoundEffect(selfPos, "周瑜", "诡辩");

			serverLogic:network_server_notifyPlayerTip(selfPos, "请选择想要变为辩牌的论牌或驳牌，可随意搭配");

			local 	waitTime = 	ModuleBianlunSkill.HeroSkillOperationWaitTime;

			--	AI流程
			if 	ModuleBianlunSkill.HeroSkillAIControl == true then
				local 	handcardsize 	= serverLogic:getPlayerHandCardSize(selfPos);
				local 	notBianNum 		= 0;
				for 	i = 1, handcardsize do 
						local 	card = serverLogic:getPlayerHandCard(selfPos, i - 1);

						if 		serverLogic:isLunCard(card) == true or serverLogic:isBoCard(card) == true then
								notBianNum = notBianNum + 1;
						end
				end

				local 	random 	= math.random(1, notBianNum);

				for 	i = 1, handcardsize do
						local 	card 	= serverLogic:getPlayerHandCard(selfPos, i - 1);
						if 		serverLogic:isLunCard(card) == true or serverLogic:isBoCard(card) == true then
								serverLogic:appendPlayerOutputCard(selfPos,	card); 		print("Append:"..tostring(card:dumpCard()));
								random = random - 1;
								if 	random == 0 then
									do break end
								end
						end
				end				

                --	获得辩牌值
				local 	bianValue1 = serverLogic:getFirstBianValue();
				local 	bianValue2 = serverLogic:getSecondBianValue();
				local 	outputsize = serverLogic:getPlayerOutputCardSize(selfPos);							--	print(tostring(outputsize));

				for 	i = 1, outputsize do 
						local 	card  = serverLogic:getPlayerOutputCard(selfPos, i - 1);					--	print(card:dumpCard());
						local 	index = serverLogic:getPlayerHandCardIndex(selfPos, card);
						if 		index == - 1 then
								ModuleBianlunSkill.Log("Error@Lua, Critical Error, Card Not Exist!");
								return;
						else
								if i %2 == 0	then
									card:setValue(bianValue1);
								else
									card:setValue(bianValue2);
								end

								print(card:dumpCard());

								serverLogic:setPlayerHandCard(selfPos, index, card);
						end
				end

				serverLogic:refusePlayerOutputEvent(selfPos, "");
				serverLogic:network_server_notifyRemainPlayerHandCards(selfPos);
				ModuleBianlunServerLogic.HeroSkill_zhouyu_guibian_time[selfPos + 1] = ModuleBianlunServerLogic.HeroSkill_zhouyu_guibian_time[selfPos + 1] + 1;				

			end

			--	非AI流程
			while 	true	 do
				local   _state, _pos, _type = ModuleBianlunServerLogic.Wait(waitTime);

				if 		_state == "Timeout"			then
						
						ModuleBianlunSkill.Log("英雄--周瑜, 诡辩技能发动超时");

						do  break end
				elseif	_state == "MessageArrive"	then
						if 	_pos == selfPos and _type == "Logic" 	then
							ModuleBianlunSkill.Log("英雄--周瑜, 诡辩技能后续操作消息到来");

							local 	outputsize = serverLogic:getPlayerOutputCardSize(selfPos);
							if 		outputsize == 0 then
									serverLogic:refusePlayerOutputEvent(selfPos, "请选择至少一张论牌或驳牌进行变更");
							else
									local 	output = serverLogic:getPlayerOutputCardList(selfPos);
									local 	luncard= serverLogic:getLunCard();
									local 	bocard = serverLogic:getBoCard();

									--	获得辩牌值
									local 	bianValue1 = serverLogic:getFirstBianValue();
									local 	bianValue2 = serverLogic:getSecondBianValue();


									if 		algorithm_module_bianlun_zhouyu_checkalllunbocard(output, luncard, bocard) == true then

											for 	i = 1, outputsize do 
													local 	card  = serverLogic:getPlayerOutputCard(selfPos, i - 1);
													local 	index = serverLogic:getPlayerHandCardIndex(selfPos, card);
													if 		index == - 1 then
															ModuleBianlunSkill.Log("Error@Lua, Critical Error, Card Not Exist!");
															return;
													else
															if i %2 == 0	then
																card:setValue(bianValue1);
															else
																card:setValue(bianValue2);
															end
															serverLogic:setPlayerHandCard(selfPos, index, card);
													end
											end

											serverLogic:refusePlayerOutputEvent(selfPos, "");

											serverLogic:network_server_notifyRemainPlayerHandCards(selfPos);

											ModuleBianlunServerLogic.HeroSkill_zhouyu_guibian_time[selfPos + 1] = ModuleBianlunServerLogic.HeroSkill_zhouyu_guibian_time[selfPos + 1] + 1;

											do  break end

									else
											serverLogic:refusePlayerOutputEvent(selfPos, "确保欲变换的牌为论牌或驳牌");
									end
							end
						end
				end
			end			
	end
end


function ModuleBianlunSkill.HandleHeroSkill_caocao( pos, state )
	-- body

--[[
	/**
	***		英雄--曹操
	***		技能--威吓、怒责
	**/
--]]

	local 	serverLogic = CModuleBianlunServerLogic:sharedServerLogic();
	local 	selfPos 	= pos;
	local   otherPos 	= 1 - pos;	


	if 		state 	== "JustOperation"	then
			
			--	提醒玩家使用技能
			if 	ModuleBianlunServerLogic.HeroSkill_caocao_nuze_time[selfPos + 1] < 3 then
			--	serverLogic:network_server_notifyPlayerSkillActive(selfPos, 2);
			
				return ModuleBianlunSkill.HandleHeroSkill_caocao(selfPos, "ActiveSkill");
			end
	elseif	state == "ActiveSkill"		then
			local 	waitTime 	= ModuleBianlunSkill.HeroSkillWaitTime;

			--	AI控制流程
			if 	ModuleBianlunSkill.HeroSkillAIControl == true then
				if 	ModuleBianlunAI.HandleSkillTrigger(selfPos) == true then

					local 	handcardsize 	= serverLogic:getPlayerHandCardSize(selfPos);
					local 	bHaveBianCard 	= false;
					for 	i = 1, handcardsize do 
							local 	card 	= serverLogic:getPlayerHandCard(selfPos, i -1);
							if 		serverLogic:isLunCard(card) == false and serverLogic:isBoCard(card) == false then
									bHaveBianCard = true;
									do break end
							end
					end
					if 	bHaveBianCard  == true then
						return ModuleBianlunSkill.HandleHeroSkill_caocao(selfPos, "SkillTrigger");
					else
						return ;
					end
				else
					return;
				end
			end

			--	非AI流程
			while 	true do 
					local 	_state, _pos, _type = ModuleBianlunServerLogic.Wait(waitTime);
					if 		_state == "Timeout"			then
							ModuleBianlunSkill.Log("英雄--曹操, 怒责技能发动超时");
							do  break end
					elseif	_state == "MessageArrive"	then
							if 	_pos == selfPos then

								if 		_type == "Skill"	then
										ModuleBianlunSkill.Log("英雄--曹操, 怒责技能发动");

										return ModuleBianlunSkill.HandleHeroSkill_caocao(selfPos, "SkillTrigger");
								elseif 	_type == "Logic"	then

										--	停止技能逻辑处理
										do break end
								end
							end
					else
					end
			end
	elseif	state == "SkillTrigger"		then
			local 	waitTime 	= ModuleBianlunSkill.HeroSkillOperationWaitTime;

			serverLogic:network_server_broadCastPlayerHeroSkillSoundEffect(selfPos, "曹操", "怒责");

			--	AI 流程
			if 	ModuleBianlunSkill.HeroSkillAIControl == true then

				local 	handcardsize 	= serverLogic:getPlayerHandCardSize(selfPos);
				local 	bianCardNum 	= 0;
				for 	i = 1, handcardsize do 
						local 	card 	= serverLogic:getPlayerHandCard(selfPos, i -1);
						if 		serverLogic:isLunCard(card) == false and serverLogic:isBoCard(card) == false then
								bianCardNum = bianCardNum + 1;
						end
				end

				local 	random = math.random(1, bianCardNum);

				for 	i = 1, handcardsize do
						local  	card 	= serverLogic:getPlayerHandCard(selfPos, i - 1);
						if 		serverLogic:isLunCard(card) == false and serverLogic:isBoCard(card) == false then
								serverLogic:appendPlayerOutputCard(selfPos, card);
								random = random - 1;
								if 	random == 0 then
									do break end
								end
						end
				end

--				print("XXX");
				
				local 	luncard = serverLogic:getLunCard();
				local 	outputSize = serverLogic:getPlayerOutputCardSize(selfPos);
				for 	i = 1, outputSize do
						local 	card = serverLogic:getPlayerOutputCard(selfPos, i - 1);
						local 	index = serverLogic:getPlayerHandCardIndex(selfPos, card);

						card:setValue(luncard:getValue());

						serverLogic:setPlayerHandCard(selfPos, index, card);												
				end

				serverLogic:refusePlayerOutputEvent(selfPos, "");
				serverLogic:network_server_notifyRemainPlayerHandCards(selfPos);
				ModuleBianlunServerLogic.HeroSkill_caocao_nuze_time[selfPos + 1] = ModuleBianlunServerLogic.HeroSkill_caocao_nuze_time[selfPos + 1] + 1;
				return ;

			end

			--	非AI流程
			while 	true do
					local 	_state, _pos, _type = ModuleBianlunServerLogic.Wait(waitTime);
					if 		_state == "Timeout" 		then
							ModuleBianlunServerLogic.Log("英雄--曹操， 怒责技能后续操作超时");
							do break end
					elseif	_state == "MessageArrive"	then
							if 	_pos == selfPos and _type == "Logic"	then

								ModuleBianlunSkill.Log("英雄--曹操， 怒责技能后续操作消息到来");

								local 	outputSize = serverLogic:getPlayerOutputCardSize(selfPos);
								if 		outputSize ~= 0 then

									
										local 	bAllBianCard = true;
										for 	i = 1, outputSize do
												local 	card = serverLogic:getPlayerOutputCard(selfPos, i - 1);
												if 	serverLogic:isLunCard(card) == true or serverLogic:isBoCard(card) == true then
													bAllBianCard = false;
													do break end
												end
										end

									
										if 	bAllBianCard == false then
											serverLogic:refusePlayerOutputEvent(selfPos, "请确保欲改变的牌为辩牌");
										else
											local 	luncard = serverLogic:getLunCard();
											for 	i = 1, outputSize do
													local 	card = serverLogic:getPlayerOutputCard(selfPos, i - 1);
													local 	index = serverLogic:getPlayerHandCardIndex(selfPos, card);

												--	ModuleBianlunSkill.Log(card:dumpCard());
												--	ModuleBianlunSkill.Log(tostring(index));

													card:setValue(luncard:getValue());

													ModuleBianlunSkill.Log(card:dumpCard());

													serverLogic:setPlayerHandCard(selfPos, index, card);												
											end

											serverLogic:refusePlayerOutputEvent(selfPos, "");

											serverLogic:network_server_notifyRemainPlayerHandCards(selfPos);

											ModuleBianlunServerLogic.HeroSkill_caocao_nuze_time[selfPos + 1] = ModuleBianlunServerLogic.HeroSkill_caocao_nuze_time[selfPos + 1] + 1;

											do break end
										end
								else
										serverLogic:refusePlayerOutputEvent(selfPos, "请选择至少一张辩牌");
								end
							end
					end
			end
	elseif	state == "CheckCanHandleZhengBian" 	then

			ModuleBianlunSkill.Log("英雄--曹操, 威吓技能触发");

			serverLogic:network_server_broadCastPlayerHeroSkillSoundEffect(selfPos, "曹操", "威吓");

			return false;		
	else
	end
end

function ModuleBianlunSkill.HandleHeroSkill_guojia( pos, state )
	-- body

--[[
	/**
	***		英雄--郭嘉
	***		技能--先断、临断
	**/
--]]

	local 	serverLogic = CModuleBianlunServerLogic:sharedServerLogic();
	local 	selfPos 	= pos;
	local   otherPos 	= 1 - pos;

	if 		state == "BeforeRoundStart" 	then
			
			--	提醒玩家使用先断技能
			serverLogic:network_server_notifyPlayerSkillActive(selfPos, 1);

			--	Allow To Operate
			serverLogic:setOutputPosition(selfPos);

			return ModuleBianlunSkill.HandleHeroSkill_guojia(selfPos, "ActiveSkill");
	elseif	state == "ActiveSkill"			then

			local 	waitTime = ModuleBianlunSkill.HeroSkillRoundWaitTime;

			serverLogic:network_server_notifyPlayerTip(selfPos,  "选择是否发动先断技能");
			serverLogic:network_server_notifyPlayerTip(otherPos, "等待对方发动先断技能");

			--	AI 控制流程
		--	print(tostring(ModuleBianlunSkill.HeroSkillAIControl));
			if 	ModuleBianlunSkill.HeroSkillAIControl == true then
				--	AI控制主动技能释放
				if 	ModuleBianlunAI.HandleSkillTrigger(selfPos) == true then
					ModuleBianlunSkill.Log("AI, 郭嘉发动技能先断");
					return 	ModuleBianlunSkill.HandleHeroSkill_guojia(selfPos, "SkillTrigger");
				else
					ModuleBianlunSkill.Log("AI, 郭嘉放弃发动技能先断");
					return;
				end

			end

			--	非AI控制流程 
			while 	true  	do 
					local 	_state, _pos, _type = ModuleBianlunServerLogic.Wait(waitTime);
					if 		_state == "Timeout"			then
							ModuleBianlunSkill.Log("英雄--郭嘉, 先断技能发动超时");
							do  break end
					elseif 	_state == "MessageArrive"	then
							if 		_pos == selfPos and _type == "Skill" 	then
									ModuleBianlunSkill.Log("英雄--郭嘉, 先断技能发动");
									return ModuleBianlunSkill.HandleHeroSkill_guojia(selfPos, "SkillTrigger");
							end 
					else
					end
			end

	elseif 	state == "SkillTrigger" 		then
			local 	waitTime = ModuleBianlunSkill.HeroSkillOperationWaitTime;

			serverLogic:network_server_notifyPlayerTip(selfPos,  "请选择至少一张论牌作为亮牌");
			serverLogic:network_server_notifyPlayerTip(otherPos, "等待对方亮牌");

			serverLogic:network_server_broadCastPlayerHeroSkillSoundEffect(selfPos, "郭嘉", "先断");

			--	AI 控制流程
			if 	ModuleBianlunSkill.HeroSkillAIControl == true then
				--	放弃N张论牌
				local 	handCardSize 	= serverLogic:getPlayerHandCardSize(selfPos);
				local 	lunCard 		= serverLogic:getLunCard();
				local 	card 			= nil;
				local 	lunCardNum 		= 0;
				for 	i = 1, handCardSize do
						card 	= serverLogic:getPlayerHandCard(selfPos, i - 1);
						if 		card:getValue() == lunCard:getValue() then
								lunCardNum = lunCardNum + 1;
						end
				end

				print(tostring(lunCardNum));
				
				if 		lunCardNum == 0 then
						--	无论牌
						return ;
				elseif 	lunCardNum == 1 then
						--	只有一张论牌
						return ;
				else
						local 	outputNumberBackup 	= 0;
						local 	outputNumber 		= math.random(2, lunCardNum);					--	print("己方弃牌数量: "..tostring(outputNumber));
						outputNumberBackup 			= outputNumber;
						for 	i = 1, handCardSize do 
								card  	= serverLogic:getPlayerHandCard(selfPos, i - 1);
								if 	card:getValue() == lunCard:getValue() then
									serverLogic:appendPlayerOutputCard(selfPos, card);
									outputNumber = outputNumber - 1;
								end
								if 	outputNumber == 0 then
									do break end
								end
						end

						--
						--	允许出牌
						serverLogic:acceptPlayerOutputEvent(selfPos);
						ModuleBianlunServerLogic.WaitTimeout(0.5);
						serverLogic:network_server_notifyPlayerShowOutputCards();	--	亮牌

						--	记录亮牌
						serverLogic:acceptPlayerShowEvent(selfPos);								
												
						serverLogic:network_server_notifyPlayerTip(selfPos, "等待对方弃牌");
						serverLogic:network_server_notifyPlayerTip(otherPos,"请放弃"..tostring(outputNumberBackup - 1).."张手牌"); 	--	stop();
						return ModuleBianlunSkill.HandleHeroSkill_guojia(selfPos, "OtherGiveUp");	
				end
			end

			--	非AI控制流程
			while 	true 	do
					local 	_state, _pos, _type = ModuleBianlunServerLogic.Wait(waitTime);
					if 		_state ==  "Timeout" 		then
							ModuleBianlunSkill.Log("英雄--郭嘉, 先断技能后续操作消息超时");
							do 	break end
					elseif 	_state ==  "MessageArrive"	then
							if 	_pos == selfPos and _type == "Logic" 	then
								ModuleBianlunSkill.Log("英雄--郭嘉,先断技能后续操作消息到来");

								local 	outputsize = serverLogic:getPlayerOutputCardSize(selfPos);
								if 		outputsize == 0 then
										serverLogic:refusePlayerOutputEvent(selfPos, "请选择至少一张论牌");
								else
										local 	output 	= serverLogic:getPlayerOutputCardList(selfPos);
										local 	luncard = serverLogic:getLunCard();
										if 		algorithm_module_bianlun_zhouyu_checksametypecard(output, luncard)  == true then
												
												--	允许出牌
												serverLogic:acceptPlayerOutputEvent(selfPos);
												ModuleBianlunServerLogic.WaitTimeout(0.5);
												serverLogic:network_server_notifyPlayerShowOutputCards();	--	亮牌

												--	记录亮牌
												serverLogic:acceptPlayerShowEvent(selfPos);											
												
												if 		outputsize == 1 then

														serverLogic:refusePlayerShowGiveupEvent(selfPos);

														--	对方无需弃牌,转走正常流程
														do  break end

												else
														serverLogic:network_server_notifyPlayerTip(selfPos, "等待对方弃牌");
														serverLogic:network_server_notifyPlayerTip(otherPos,"请放弃"..tostring(outputsize - 1).."张手牌");
														return ModuleBianlunSkill.HandleHeroSkill_guojia(selfPos, "OtherGiveUp");
												end

												
										else
												serverLogic:refusePlayerOutputEvent(selfPos, "请确保选中的牌都为论牌");
										end
								end
							end
					else
					end
			end
	elseif 	state == "OtherGiveUp" 	then
			local 	waitTime = ModuleBianlunSkill.HeroSkillOperationWaitTime;

			print("对方弃牌");

			--	Allow to Operate
			serverLogic:setOutputPosition(otherPos);

			--	AI 控制流程
			if 	ModuleBianlunSkill.HeroSkillAIControl == true then
				local selfOutputSize = serverLogic:getPlayerPreOutputCardSize(selfPos);

				ModuleBianlunSkill.Log(tostring(selfOutputSize));

				--	对方弃牌
				ModuleBianlunServerLogic.OutputTimeOut(otherPos, selfOutputSize - 1);
				ModuleBianlunServerLogic.WaitTimeout(0.5);						--	动画结束
				serverLogic:network_server_notifyPlayerShowOutputCards();		--	显示弃牌
				ModuleBianlunServerLogic.WaitTimeout(0.5);						--	显示弃牌
				--	己方回牌
				serverLogic:refusePlayerShowGiveupEvent(selfPos);	

				return;			
			end

			--	非AI控制流程
			while	true 	do
					local 	_state, _pos, _type = ModuleBianlunServerLogic.Wait(waitTime);
					if 		_state == "Timeout"			then
							ModuleBianlunSkill.Log("英雄--郭嘉， 技能先断， 对方弃牌超时");

							local selfOutputSize = serverLogic:getPlayerPreOutputCardSize(selfPos);

							ModuleBianlunSkill.Log(tostring(selfOutputSize));

							--	对方弃牌
							ModuleBianlunServerLogic.OutputTimeOut(otherPos, selfOutputSize - 1);
							ModuleBianlunServerLogic.WaitTimeout(0.5);						--	动画结束
							serverLogic:network_server_notifyPlayerShowOutputCards();		--	显示弃牌
							ModuleBianlunServerLogic.WaitTimeout(0.5);						--	显示弃牌
							--	己方回牌
							serverLogic:refusePlayerShowGiveupEvent(selfPos);

							do  break end
					elseif	_state == "MessageArrive"	then

							if 	_pos == otherPos and _type == "Logic" 	then
								local 	otherOutputSize= serverLogic:getPlayerPreOutputCardSize(otherPos);
								local 	selfOutputSize = serverLogic:getPlayerPreOutputCardSize(selfPos);

								if 	  	otherOutputSize == selfOutputSize - 1 then

										--	接受对方弃牌
									  	serverLogic:acceptPlayerOutputEvent(otherPos);
									  	ModuleBianlunServerLogic.WaitTimeout(0.5);
									  	serverLogic:network_server_notifyPlayerShowOutputCards();
									  	ModuleBianlunServerLogic.WaitTimeout(0.5);

									  	--	己方亮牌恢复
									  	serverLogic:refusePlayerShowGiveupEvent(selfPos);
									  	do  break end
								else
										serverLogic:refusePlayerOutputEvent(otherPos,"请放弃"..tostring(selfOutputSize - 1).."张手牌");
								end
							end
					end
			end
	elseif 	state == "AfterCompareWithWinner" 	then

			ModuleBianlunServerLogic.Log("英雄--郭嘉， 临断技能触发");

			serverLogic:network_server_broadCastPlayerHeroSkillSoundEffect(selfPos, "郭嘉", "临断");

			local 	nCheckNum = 1;
			local 	nCheckedNumber  = 0;
			serverLogic:network_server_notifyPlayerCheckOtherHandCard(selfPos, nCheckNum);	--	通知允许查看

			serverLogic:network_server_notifyPlayerTip(selfPos, "请从对方手中牌中选择一张欲查看的牌");
			serverLogic:network_server_notifyPlayerTip(otherPos, "等待对方选择欲查看的牌");

			--	AI 控制流程
			if 		ModuleBianlunSkill.HeroSkillAIControl == true then

					serverLogic:doTurnClean();

					local 	handCardSize 	= serverLogic:getPlayerHandCardSize(otherPos);
					local 	random 			= math.random(1, handCardSize);

					local 	card 			= serverLogic:getPlayerHandCard(otherPos, random - 1);

					serverLogic:appendPlayerOutputCard(otherPos, card);

					serverLogic:acceptPlayerOutputEvent(otherPos);
					ModuleBianlunServerLogic.WaitTimeout(0.5);
					serverLogic:network_server_notifyPlayerShowOutputCards();

					serverLogic:acceptPlayerShowEvent(otherPos);

					nCheckedNumber  = nCheckedNumber + 1;

					if 	nCheckedNumber == nCheckNum then

						--	隐藏查看牌
						ModuleBianlunServerLogic.WaitTimeout(0.5);
						serverLogic:clearPlayerOutputCard(otherPos);
						serverLogic:network_server_notifyPlayerHideOutputCards()

						--	查看牌回复
						serverLogic:refusePlayerShowGiveupEvent(otherPos);
						serverLogic:network_server_notifyPlayerCheckOtherHandCard(selfPos, 0);

					end							
			end

			--	非AI控制流程
			local 	waitTime = ModuleBianlunSkill.HeroSkillOperationWaitTime;
			
			while 	true   do
					local 	_state, _pos, _type, _tag = ModuleBianlunServerLogic.Wait(waitTime);

					ModuleBianlunSkill.Log(tostring(_state)..tostring(_pos)..tostring(_type)..tostring(_tag));

					if 		_state == "Timeout"			then
							ModuleBianlunSkill.Log("英雄--郭嘉, 临断技能后续操作超时");
							do break end
					elseif 	_state == "MessageArrive"	then
							if 	_pos == selfPos and _type == "CheckCard" 	then
								ModuleBianlunSkill.Log("查看对方牌消息到来, 查看牌Tag: "..tostring(_tag));

								--	清理掉之前出的牌
							--	ModuleBianlunSkill.Log("1");
								serverLogic:doTurnClean();


								--	添加欲查看的牌
							--	ModuleBianlunSkill.Log("2");
								local 	card 				= nil;
								local 	otherHandCardSize 	= serverLogic:getPlayerHandCardSize(otherPos);
								for 	i = 1, otherHandCardSize do 
										card =  serverLogic:getPlayerHandCard(otherPos, i - 1);
										if 		card:getTag() == _tag then

												--	搜索到欲查看的牌
												do  break end
										end
										card = nil;
								end
							--	ModuleBianlunSkill.Log("3");
								if 		card == nil 	then
										ModuleBianlunSkill.Log("Error@Lua, 欲查看的牌不存在！");
								else

										serverLogic:appendPlayerOutputCard(otherPos, card);

										serverLogic:acceptPlayerOutputEvent(otherPos);
										ModuleBianlunServerLogic.WaitTimeout(0.5);
										serverLogic:network_server_notifyPlayerShowOutputCards();

										serverLogic:acceptPlayerShowEvent(otherPos);

										nCheckedNumber  = nCheckedNumber + 1;

										if 	nCheckedNumber == nCheckNum then
											
											--	查看次数足够
											do break end
										end
								end
							end
					else
					end	
			end

			if 	nCheckedNumber == nCheckNum then

				--	隐藏查看牌
				ModuleBianlunServerLogic.WaitTimeout(0.5);
				serverLogic:clearPlayerOutputCard(otherPos);
				serverLogic:network_server_notifyPlayerHideOutputCards()

				--	查看牌回复
				serverLogic:refusePlayerShowGiveupEvent(otherPos);
				serverLogic:network_server_notifyPlayerCheckOtherHandCard(selfPos, 0);

			end

	else
	end
end


------------------------------------------------------------------------------------------------------------------------------------

--	ModuleBianlunSkill Exported Function

function ModuleBianlunSkill.BeforeRoundStart( pos )
	-- body

	local 	serverLogic = CModuleBianlunServerLogic:sharedServerLogic();
	local 	heroName 	= serverLogic:getPlayerName(pos);

	if 		heroName 	== "郭嘉" 	then
			ModuleBianlunSkill.HandleHeroSkill_guojia					(pos, "BeforeRoundStart");
	end
end

function ModuleBianlunSkill.BeforeOperation( pos )
	-- body

	local 	serverLogic = CModuleBianlunServerLogic:sharedServerLogic();
	local 	heroName 	= serverLogic:getPlayerName(pos);

	if 		heroName 	== "甄宓(1)"	then
			return 	ModuleBianlunSkill.HandleHeroSkill_zhenmi_yuan		(pos, "JustOperation");
	elseif 	heroName 	== "甄宓（2）" 	then
			return 	ModuleBianlunSkill.HandleHeroSkill_zhenmi_wei		(pos, "JustOperation");
	elseif 	heroName 	== "周瑜"	then
			return  ModuleBianlunSkill.HandleHeroSkill_zhouyu			(pos, "JustOperation");
	elseif 	heroName 	== "曹操" 	then
			return 	ModuleBianlunSkill.HandleHeroSkill_caocao 			(pos, "JustOperation");
	end
	return ;
end

function ModuleBianlunSkill.AfterCompareWithLosserBeforeConfirm( pos )
	-- body

	local 	serverLogic = CModuleBianlunServerLogic:sharedServerLogic();
	local 	heroName 	= serverLogic:getPlayerName(pos);

	if 		heroName 	== "貂蝉"	then
			return 		ModuleBianlunSkill.HandleHeroSkill_diaochan		(pos, "AfterCompareWithLosserBeforeConfirm");
	elseif 	heroName 	== "鲁肃"	then
			return 		ModuleBianlunSkill.HandleHeroSkill_lusu			(pos, "AfterCompareWithLosserBeforeConfirm");
	elseif 	heroName 	== "吕蒙"	then
			return 		ModuleBianlunSkill.HandleHeroSkill_lvmeng		(pos, "AfterCompareWithLosserBeforeConfirm");
	end

	return false;
end

function ModuleBianlunSkill.BeforeDecideChangeLunBo( pos )
	-- body

	local 	serverLogic = CModuleBianlunServerLogic:sharedServerLogic();
	local 	heroName 	= serverLogic:getPlayerName(pos);

	if 		heroName 	== "贾诩"	then
			return 		ModuleBianlunSkill.HandleHeroSkill_jiaxu 		(pos, "BeforeDecideChangeLunBo");
	end

	return false;
end

function ModuleBianlunSkill.DecideWinnerWithBianDraw( pos )
	-- body

	local 	serverLogic = CModuleBianlunServerLogic:sharedServerLogic();
	local 	heroName 	= serverLogic:getPlayerName(pos);	

	if 		heroName 	== "贾诩" 	then
			return 		ModuleBianlunSkill.HandleHeroSkill_jiaxu 		(pos, "DecideWinnerWithBianDraw");
	end
	return 	nil;
end

function ModuleBianlunSkill.AfterShowOutputCard( pos )
	-- body

	local 	serverLogic = CModuleBianlunServerLogic:sharedServerLogic();
	local 	heroName 	= serverLogic:getPlayerName(pos);	

	if 		heroName == "田丰" then
			print("田丰 @ AfterShowOutputCard");
			return 		ModuleBianlunSkill.HandleHeroSkill_tianfeng 	(pos, "AfterShowOutputCard");
	end
end

function ModuleBianlunSkill.AfterCompareWithWinner( pos )
	-- body

	local 	serverLogic = CModuleBianlunServerLogic:sharedServerLogic();
	local 	heroName 	= serverLogic:getPlayerName(pos);

	if 		heroName 	== "陆逊" 	then
			return 		ModuleBianlunSkill.HandleHeroSkill_luxun		(pos, "AfterCompareWithWinner");
	elseif  heroName 	== "诸葛亮"	then
			ModuleBianlunSkill.HandleHeroSkill_zhugeliang				(pos, "AfterCompareWithWinner");
	elseif 	heroName 	== "郭嘉"	then
			ModuleBianlunSkill.HandleHeroSkill_guojia 					(pos, "AfterCompareWithWinner");
	end
	return false;
end

function ModuleBianlunSkill.AfterCompareWithLosser( pos )
	-- body

	local 	serverLogic = CModuleBianlunServerLogic:sharedServerLogic();
	local 	heroName 	= serverLogic:getPlayerName(pos);

	if 		heroName 	== "诸葛亮" 	then
			return 		ModuleBianlunSkill.HandleHeroSkill_zhugeliang	(pos, "AfterCompareWithLosser");
	elseif	heroName 	== "陆逊"		then
			ModuleBianlunSkill.HandleHeroSkill_luxun					(pos, 	"AfterCompareWithLosser");
	elseif	heroName 	== "孙权" 		then
			ModuleBianlunSkill.HandleHeroSkill_sunquan					(pos, "AfterCompareWithLosser");
	end

	return false;
end

function ModuleBianlunSkill.PreFaPai( pos )
	-- body

	local 	serverLogic = CModuleBianlunServerLogic:sharedServerLogic();
	local 	heroName 	= serverLogic:getPlayerName(pos);

	if 		heroName 	== "司马懿" 	then
			ModuleBianlunSkill.HandleHeroSkill_simayi					(pos, "PreFaPai");
	end	
end

function ModuleBianlunSkill.CheckCanHandleZhengBian( pos )
	-- body

	local 	serverLogic = CModuleBianlunServerLogic:sharedServerLogic();
	local 	heroName 	= serverLogic:getPlayerName(pos);

	if 		heroName  == "曹操"		then
			return ModuleBianlunSkill.HandleHeroSkill_caocao			(pos, "CheckCanHandleZhengBian");
	end	
	return true;
end

--------------------------------------------------------------------------------------------------------------------
--	自动出牌机制修改
function ModuleBianlunSkill.GetPlayerLevel( ... )
	-- body
end