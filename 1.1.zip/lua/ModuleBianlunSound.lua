--	Date:	2013/11/1
--	Author:	zhaozl
--	Biref:	ModuleBian Sound Configuration

require "AudioEngine"

local 	CommonSkillEffectFileExtension 	= ".mp3";
local   HeroSkillEffectFileExtension 	= ".mp3";
local 	Nan = "_nan";
local 	Nv  = "_nv";

ModuleBianlunSound = {

	CommonSkillEffectMap = {
		["男"]		= {
			["天"]	=	"tian"..Nv..CommonSkillEffectFileExtension; 
			["地"]	=	"di"..Nv..CommonSkillEffectFileExtension;
			["人"]	=	"ren"..Nv..CommonSkillEffectFileExtension;
			["理"]	=	"li"..Nv..CommonSkillEffectFileExtension;
		},
		["女"]		= {
			["天"]	=	"tian"..Nv..CommonSkillEffectFileExtension; 
			["地"]	=	"di"..Nv..CommonSkillEffectFileExtension;
			["人"]	=	"ren"..Nv..CommonSkillEffectFileExtension;
			["理"]	=	"li"..Nv..CommonSkillEffectFileExtension;			
		},
	};

	HeroSkillEffectMap = {
		
		["貂蝉"] = {["挑唆"] = "diaochan_tiaosuo"..HeroSkillEffectFileExtension, 	},
		["鲁肃"] = {["明论"] = "lusu_mingjian"..HeroSkillEffectFileExtension, 		},	
		["吕蒙"] = {["鉴论"] = "lvmeng_jianlun"..HeroSkillEffectFileExtension, 		},
		["陆逊"] = {["说服"] = "luxun_shuifu"..HeroSkillEffectFileExtension, 		},		
		["孙权"] = {["续问"] = "sunquan_xuwen"..HeroSkillEffectFileExtension, 		},
		["田丰"] = {["直谏"] = "tianfeng_zhijian"..HeroSkillEffectFileExtension,	},

		["司马懿"] = {["沉谨"] = "simayi_chenjin"..HeroSkillEffectFileExtension,	},
		
		["甄宓"] = {["识时"] 	= "zhenmi_shishi"..HeroSkillEffectFileExtension,	["灵蛇髻"] 	= "zhenmi_lingsheji"..HeroSkillEffectFileExtension,	},
		["周瑜"] = {["合论"] 	= "zhouyu_helun"..HeroSkillEffectFileExtension, 	["诡辩"]	= "zhouyu_guibian"..HeroSkillEffectFileExtension	},
		["曹操"] = {["威吓"] 	= "caocao_weihe"..HeroSkillEffectFileExtension,		["怒责"] 	= "caocao_nuze"..HeroSkillEffectFileExtension		},
		["郭嘉"] = {["先断"] 	= "guojia_xianduan"..HeroSkillEffectFileExtension,	["临断"] 	= "guojia_linduan"..HeroSkillEffectFileExtension	},
		["贾诩"] = {["诡诈"] 	= "jiaxu_guizha"..HeroSkillEffectFileExtension, 	["教唆"] 	= "jiaxu_jiaosuo"..HeroSkillEffectFileExtension		},
		
		["诸葛亮"] = {["巧舌"] = "zhugeliang_qiaoshe"..HeroSkillEffectFileExtension, ["激将法"] = "zhugeliang_jijiangfa"..HeroSkillEffectFileExtension	},
	};


	--	BackGround
	BackGroundMusic = "bianlun_background.mp3";
};

------------------------------------------------------------------------------------------------------------------
local function GetRelativePath( ... )
	-- body

	return "Bianlun/Sound/";
end

local function CommonSkillEffectRelativePath( gender,  state )
	-- body
	local  relativePath = GetRelativePath();

	relativePath =  relativePath..ModuleBianlunSound.CommonSkillEffectMap[gender][state];
	return relativePath;
end

local function HeroSkillEffectRelativePath( name,  skill )
	-- body
	local relativePath = GetRelativePath();
	relativePath = relativePath..ModuleBianlunSound.HeroSkillEffectMap[name][skill];
	return relativePath;
end


local function RelativePath( name )
	-- body
	local  relativePath = GetRelativePath();
	relativePath =  relativePath..name;

	return relativePath;
end

------------------------------------------------------------------------------------------------------------------

function ModuleBianlunSound.Log( msg )
	-- body
--[[
	local preFix = "++ ModuleBianlunSound ++\n";
	local newMsg = tostring(preFix)..tostring(msg);

	print(newMsg);
--]]

	print(msg);
end

------------------------------------------------------------------------------------------------------------------

--	Effect

function ModuleBianlunSound.PlayCommonSkillEffect( gender, state )
	-- body						  
	return AudioEngine.playEffect( CommonSkillEffectRelativePath(gender, state), false );
end

function ModuleBianlunSound.PlayHeroSkillEffect( name, skill )
	-- body
	return AudioEngine.playEffect(HeroSkillEffectRelativePath(name, skill));
end


function ModuleBianlunSound.StopAllEffect( )
	-- body
	AudioEngine.stopAllEffects();
end


--	Background

function ModuleBianlunSound.PlayBackgroundMusic( name )
	-- body

	name = name or ModuleBianlunSound.BackGroundMusic;

	AudioEngine.playMusic(RelativePath(name), true);
end


function ModuleBianlunSound.StopBackgroundMusic( bRelease )
	-- body
	bRelease = bRelease or true;
	AudioEngine.stopMusic(bRelease);
end


--	PreLoad Dantiao Sound Effect & Background

function ModuleBianlunSound.PreloadAllEffect(  )
	-- body

--	ModuleBianlunSound.Log("------------------------------------------------------------------------------------------------------------------");

--	ModuleBianlunSound.Log("预加载背景音效:");	
	AudioEngine.preloadEffect( RelativePath( ModuleBianlunSound.BackGroundMusic ) );


--	ModuleBianlunSound.Log("预加载通用技能音效：")
	for v in pairs(ModuleBianlunSound.CommonSkillEffectMap) do 
		for k in pairs(ModuleBianlunSound.CommonSkillEffectMap[v]) do 
				AudioEngine.preloadEffect( CommonSkillEffectRelativePath(v, k ) );
--				ModuleBianlunSound.Log("加载CommonSkillEffect : "..CommonSkillEffectRelativePath(v, k));
		end
	end

--	ModuleBianlunSound.Log("预加载英雄技能音效：");
	for v in pairs(ModuleBianlunSound.HeroSkillEffectMap) do 
		for k in pairs(ModuleBianlunSound.HeroSkillEffectMap[v]) do 
			AudioEngine.preloadEffect( HeroSkillEffectRelativePath(v, k));
--			ModuleBianlunSound.Log("加载HeroSkillEffect ："..HeroSkillEffectRelativePath(v, k));
		end 
	end 

--	ModuleBianlunSound.Log("------------------------------------------------------------------------------------------------------------------");
end


function ModuleBianlunSound.UnloadAllEffect( ... )
	-- body

--	ModuleBianlunSound.Log("------------------------------------------------------------------------------------------------------------------");

	--	停止背景音乐、音效 
	AudioEngine.stopMusic(true);
	AudioEngine.stopAllEffects();

	AudioEngine.unloadEffect( RelativePath( ModuleBianlunSound.BackGroundMusic ) );


--	ModuleBianlunSound.Log("预加载通用技能音效：")
	for v in pairs(ModuleBianlunSound.CommonSkillEffectMap) do 
		for k in pairs(ModuleBianlunSound.CommonSkillEffectMap[v]) do 
				AudioEngine.unloadEffect( CommonSkillEffectRelativePath(v, k ) );
--				ModuleBianlunSound.Log("卸载CommonSkillEffect : "..CommonSkillEffectRelativePath(v, k));
		end
	end

--	ModuleBianlunSound.Log("预加载英雄技能音效：");
	for v in pairs(ModuleBianlunSound.HeroSkillEffectMap) do 
		for k in pairs(ModuleBianlunSound.HeroSkillEffectMap[v]) do 
			AudioEngine.unloadEffect( HeroSkillEffectRelativePath(v, k));
--			ModuleBianlunSound.Log("卸载HeroSkillEffect ："..HeroSkillEffectRelativePath(v, k));
		end 
	end 

--	ModuleBianlunSound.Log("------------------------------------------------------------------------------------------------------------------");

end