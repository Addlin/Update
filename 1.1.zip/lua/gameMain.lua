config = {}
--[[
require "lua/playerConfig" 	--模拟的服务端发来的数据

require "lua/generalConfig"  -- 武将配置数据
require "lua/soldierConfig"	 -- 士兵配置数据
require "lua/itemConfig"	 -- 物品配置数据

-- 通用的
require "lua/utils"			 	-- 辅助函数
require "lua/Resource"          -- 资源
require "lua/CommonUI"      	-- 通用信息提示框

-- 以下为子模块
require "lua/LandingInterface"	-- 登陆界面
require "lua/battleModule"  	-- 作战模块
require "lua/battleSkills"		-- 作战技能配置和逻辑
require "lua/battleResultUI"    -- 作战结果UI
require "lua/interfacescene"  	-- 主界面
require "lua/CampScene"			-- 营地
require "lua/CardsScene"		-- 卡牌
require "lua/BattleUIScene"		-- 掠夺
require "lua/TaskScene"			-- 任务
require "lua/SocialScene"		-- 社交
require "lua/guanka"			-- 关卡
require "lua/selectStateUI"     -- 选择国家
require "lua/MallScene"			-- 商城
require "lua/worldMapUI"		-- 大地图
require "lua/playerUI"			-- 玩家信息
require "lua/gunkaConfigs"		-- 关卡配置信息
require "lua/activementUI"		-- 成就 
require "lua/checkNetworkUI"	-- 判断网络连接
require "lua/playerInfoUI"      -- 玩家信息
require "lua/playerLevelupUI"   -- 玩家升级
require "lua/propertyUI"		-- 道具信息
require "lua/helperUI"			-- 小助手
require "lua/armyUI"            -- 军队

require "lua/CommonDialog"		--	营建、城建通用对话框
require "lua/InterfaceConfig"	--	城建配置

require "lua/CampSceneDB"		--	营建配置
require "lua/CampSceneServerLogic"

require "lua/BattleCallback"
require "lua/ArgueCallback"
require "lua/ChallengeCallback"

require "AudioEngine"			--	音效
require "lua/ModuleResult"		--	单挑、辩论模块结算

require "lua/ModuleBianlun"
require "lua/ModuleDantiao"

require "Opengl"
require "lua/PrimitivesUtility"	--	图元绘制辅助工具

--]]

require "lua/ModuleBianlun"		--	测试


function ProcessGame( ... )
	-- body
	
	--	服务器通信测试
	cc.Director:getInstance():replaceScene(ModuleBianlun.CreateModuleBianlun());
end